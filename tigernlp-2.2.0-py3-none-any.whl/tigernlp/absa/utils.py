from pyabsa.functional import ATEPCConfigManager, ATEPCModelList


def get_sample_config():
    """Get sample parameter config required for model training

    Returns
    -------
    pyabsa.functional.config.atepc_config_manager.ATEPCConfigManager
        Sample parameter configuration, User can make changes as per requiremnt and pass to train
    """
    config = ATEPCConfigManager.get_atepc_config_english()
    return config


def get_ATEPC_modellist():
    """Get list of available pre-trained ABSA models

    Returns
    -------
    dict
        Dictionary containing name of model and model
    """
    ATEPC_modellist = {
        "BERT_BASE_ATEPC" : ATEPCModelList.BERT_BASE_ATEPC,
        "FAST_LCF_ATEPC" : ATEPCModelList.FAST_LCF_ATEPC,
        "FAST_LCFS_ATEPC" : ATEPCModelList.FAST_LCFS_ATEPC,
        "LCF_ATEPC" : ATEPCModelList.LCF_ATEPC,
        "LCF_ATEPC_LARGE" : ATEPCModelList.LCF_ATEPC_LARGE,
        "LCFS_ATEPC" : ATEPCModelList.LCFS_ATEPC,
        "LCFS_ATEPC_LARGE" : ATEPCModelList.LCFS_ATEPC_LARGE
    }
    return ATEPC_modellist

from sentence_transformers import SentenceTransformer


class SentenceEmbedding:
    r"""Sentence embedding utility class for NLP models.

    Generates sentence embedding vectors using hugging-face sentence-transformer pipeline

    Examples
    --------
    >>> from tigernlp.embeddings.api import SentenceEmbedding
    >>> se = SentenceEmbedding()
    >>> mini_lm_model = se.sentence_transformer_model(embedding_model="all-MiniLM-L6-v2")
    >>> sequence = ["I work at Tiger Analytics", "My name is ABC"]
    >>> sequence_embedding = se.embedding_vector(mini_lm_model, sequence)
    """

    def __init__(self):
        """SentenceEmbedding class initialization"""
        pass

    def embedding_vector(self, model_object=None, sentences=list(), convert_to_tensor=True):
        """Function to convert sentences into sentence embedding vectors using sentence transformer embedding model

        Parameters
        ----------
        model_object : sentence transformer model object, optional
            hugging face sentence transformer model object to be used for sentence embedding, by default None
            if None, will create default ``sentence_transformer_model`` object
        sentences : str, optional
            list of sentences to embedd, by default list()
        convert_to_tensor: bool, optional
            whether to convert the created embeddings to tensor
        Returns
        -------
        tensor
            sentence embedding vector using the sentence transformer model
        """
        if model_object is None:
            model_object = self.sentence_transformer_model()

        sentence_embedding = model_object.encode(sentences, convert_to_tensor=convert_to_tensor, show_progress_bar=True)

        return sentence_embedding

    def sentence_transformer_model(self, embedding_model="all-MiniLM-L6-v2"):
        """Function to create sentence transfomrer model object

        Parameters
        ----------
        embedding_model : str, optional
            pre-trained model for the sentence transformer model, by default "all-MiniLM-L6-v2".

            Refer https://huggingface.co/sentence-transformers for the list of supported models

        Returns
        -------
        model object
            SentenceTransformer model object
        """
        model_object = SentenceTransformer(embedding_model)

        return model_object

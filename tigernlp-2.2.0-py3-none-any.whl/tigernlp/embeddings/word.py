import errno
import io
import numpy as np
import os
import pandas as pd
import random
import requests
import tensorflow as tf
import tensorflow_hub as hub
import zipfile
from dotmap import DotMap
from gensim.models import FastText, word2vec
from sklearn.feature_extraction.text import CountVectorizer

from tigernlp.text_processing.api import TextProcessor


class WordEmbedding:
    """Word embedding utility class for NLP models.

    Generates word embedding vectors and similarity indexes for NLP models.

    User can use any embeddings from Word2Vec, FastText, bag of words, ElMo, Glove


    Examples
    --------
    >>> # Words to feature vector using Word2Vec
    >>> text = ["I work at Tiger Analytics", "My name is ABC"]
    >>> data_words = [["I", "work", "at", "Tiger", "Analytics"], ["My", "name", "is", "ABC"]]
    >>> feature_array = we.Word2Vec(text, data_words)
    >>> # if data words are not present
    >>> feature_array = we.Word2Vec(text, tokenizer='spacy')
    >>> # Words to feature vector using FastText
    >>> feature_array = we.fast_text(df, tokenizer='spacy')
    >>> # Words to feature vector using bag of words
    >>> feature_array = we.bog(df)
    >>> # Words to feature vector using glove
    >>> feature_array = we.glove(text, glove_model_path="./data/nlp_models/glove/glove.6B/glove.6B.100d.txt")
    >>> # Words to feature vector using ElMo
    >>> feature_array = we.elmo(text)
    """

    def __init__(self):
        """WordEmbedding class initialization"""
        pass

    def bog(self, input_text):
        """Function to get bag of words embbeding feature vectors for given text

        Parameters
        ----------
        input_text : List[str]
            List containing cleaned text

        Returns
        -------
        np.array
            Word2vec word embbeding feature vector for given text
        """
        coun_vect = CountVectorizer(binary=True)
        count_matrix = coun_vect.fit_transform(input_text)
        count_array = count_matrix.toarray()
        return count_array.astype(np.float32)

    def Word2Vec(
        self,
        input_text,
        data_words=None,
        tokenizer="spacy",
        feature_size=300,
        window_context=5,
        min_word_count=1,
        n_iteration=5,
    ):
        """Function to get Word2vec word embbeding feature vectors

        Parameters
        ----------
        input_text : List[str]
            List containing cleaned text
        data_words : list, optional
            list of data words/tokenized text list for input text, by default None
        tokenizer : str, optional
            tokenizer to generate text tokens if data_words is None, by default "spacy"
        feature_size : int, optional
            dimensionality of the word vectors, by default 300
        window_context : int, optional
            number of words before and after a given word are included as context words for the given word, by default 5
        min_word_count : int, optional
            minimun word count to consider the word, by default 1
        n_iteration : int, optional
            number of iterations, by default 5

        Returns
        -------
        List[np.array]
            Word2vec word embbeding feature vector of given size
        """
        text_col = "text"
        df = pd.DataFrame(input_text)
        df.columns = [text_col]
        # fill na's in the text column
        df[text_col] = df[text_col].fillna("")

        np.random.seed(42)
        random.seed(42)

        if data_words is None:
            tp = TextProcessor(df)
            tp.get_tokens(col_in="text", col_out="tokens", tokenizer=tokenizer)
            data_words = df["tokens"].to_list()

        tokenized_corpus = data_words

        w2v_model = word2vec.Word2Vec(
            tokenized_corpus,
            vector_size=feature_size,
            window=window_context,
            min_count=min_word_count,
            epochs=n_iteration,
            seed=42,
            workers=1,
        )

        w2v_feature_array = self.wordembedding_vectorize(tokenized_corpus, model=w2v_model)

        return w2v_feature_array

    def fast_text(
        self,
        input_text,
        data_words=None,
        tokenizer="spacy",
        feature_size=300,
        window_context=5,
        min_word_count=1,
        n_iteration=5,
    ):
        """Function to get fasttext word embbeding feature vector

        Parameters
        ----------
        input_text : List[str]
            List containing cleaned text
        data_words : list, optional
            List of data words/tokens list for input text, by default None
        tokenizer : str, optional
            tokenizer to generate text tokens if data_words is None, by default "spacy"
        feature_size : int, optional
            Length of feature vector, by default 300
        window_context : int, optional
            number of words before and after a given word are included as context words of the given word, by default 5
        min_word_count : int, optional
            minimun word count to consider the word, by default 1
        n_iteration : int, optional
            Number of iterations, by default 5

        Returns
        -------
        List[np.array]
            fasttext word embbeding feature vector of given size.
        """
        text_col = "text"
        df = pd.DataFrame(input_text)
        df.columns = [text_col]
        # fill na's in the text column
        df[text_col] = df[text_col].fillna("")

        if data_words is None:
            tp = TextProcessor(df)
            tp.get_tokens(col_in="text", col_out="tokens", tokenizer=tokenizer)
            data_words = df["tokens"].to_list()

        tokenized_corpus = data_words

        fasttext_model = FastText(
            tokenized_corpus,
            vector_size=feature_size,
            window=window_context,
            min_count=min_word_count,
            epochs=n_iteration,
            workers=1,
        )

        fasttext_feature_array = self.wordembedding_vectorize(tokenized_corpus, model=fasttext_model)
        return fasttext_feature_array

    def glove(self, input_text, glove_model_path=None, data_words=None, tokenizer="spacy"):
        """Function to get GloVe word embbeding feature vector

        Parameters
        ----------
        input_text : List[str]
            List containing cleaned text
        glove_model_path : str
            Path to GloVe model .txt file
        data_words : _list, optional
            List of data words/tokens list for input text, by default None
        tokenizer : str, optional
            tokenizer to generate text tokens if data_words is None, by default "spacy"

        Returns
        -------
        List[np.array]
            GloVe word embbeding feature vector.

        Raises
        ------
        FileNotFoundError
            Raised if GloVe model text file not found at provided path.
        """
        text_col = "text"
        df = pd.DataFrame(input_text)
        df.columns = [text_col]
        # fill na's in the text column
        df[text_col] = df[text_col].fillna("")

        if data_words is None:
            tp = TextProcessor(df)
            tp.get_tokens(col_in="text", col_out="tokens", tokenizer=tokenizer)
            data_words = df["tokens"].to_list()

        tokenized_corpus = data_words
        if glove_model_path is None:
            glove_model_path = "./data/nlp_models/glove/glove.6B/glove.6B.100d.txt"
            if not os.path.isfile(glove_model_path):
                zip_file_url = "https://nlp.stanford.edu/data/glove.6B.zip"
                r = requests.get(zip_file_url)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall("./data/nlp_models/glove/glove.6B")

        if not os.path.isfile(glove_model_path):
            raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), glove_model_path)

        embeddings_dict = {}
        with open(glove_model_path, "r", encoding="utf-8") as f:
            for line in f:
                values = line.split()
                word = values[0]
                vector = np.asarray(values[1:], "float32")
                embeddings_dict[word] = vector

        glove_model = DotMap()
        glove_model.glove_model = None
        glove_model.wv = embeddings_dict
        glove_model.vector_size = len(vector)

        glove_feature_array = self.wordembedding_vectorize(tokenized_corpus, model=glove_model)
        return glove_feature_array

    def wordembedding_vectorize(self, list_of_docs, model):
        """Converts words into word embedding vectors using the Word Embedding model

        Parameters
        ----------
        list_of_docs : list
            List of documents to convert into embedding vectors
        model : model object
            Gensim's Word Embedding model instance

        Returns
        -------
        list
            List of document in the form of embedding vectors
        """
        features = []

        for tokens in list_of_docs:
            zero_vector = np.zeros(model.vector_size, dtype="float32")
            vectors = []
            for token in tokens:
                if token in model.wv:
                    try:
                        vectors.append(model.wv[token])
                    except KeyError:
                        continue
            if vectors:
                vectors = np.asarray(vectors)
                avg_vec = vectors.mean(axis=0)
                features.append(avg_vec)
            else:
                features.append(zero_vector)
        return features

    def elmo(self, input_text, embeddings="default"):
        """Compute ELMo representations using a pre-trained model `https://tfhub.dev/google/elmo/2`

        Parameters
        ----------
        input_text : List[str]
            List containing cleaned text to embedd.
        embeddings : str, optional
            Type of embeddings want in return
            `word_emb`: the character-based word representations with shape [batch_size, max_length, 512]
            `lstm_outputs1`: the first LSTM hidden state with shape [batch_size, max_length, 1024]
            `lstm_outputs2`: the second LSTM hidden state with shape [batch_size, max_length, 1024]
            `elmo`: the weighted sum of the 3 layers. This tensor has shape [batch_size, max_length, 1024], by default 'default'
            `default`: a fixed mean-pooling of all contextualized word representations with shape [batch_size, 1024]

        Returns
        -------
        `tensorflow.python.framework.ops.EagerTensor`
            ELMo representations using a pre-trained `https://tfhub.dev/google/elmo/2` model with shape according to embeddings parameter.
        """
        elmo = hub.load("https://tfhub.dev/google/elmo/2")
        return elmo.signatures["default"](tf.constant(input_text))[embeddings]

import os
from camelot import read_pdf
from typing import Union

from tigernlp.core.utils import MyLogger


class Camelot:
    """Class to extract table from a given pdf.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.doc_parsing.api import Camelot
    >>> c = Camelot()
    >>> data = c.extract(input_file_path = "path\\to\\file")
    >>> data
    """

    def __init__(self, log_level: str = "INFO", log_file_path: str = None, verbose: bool = True):
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def extract(
        self,
        input_file_path: str,
        output_format: str = "df",
        json_orientation: str = "columns",
        pages: Union[str, int] = "all",
        stream: bool = False,
        password: str = None,
    ):
        """Extracts table for the pdf given in ``input_file_path`` parameter.

        Parameters
        ----------
        input_file_path : str
            Relative or Absolute path of the file.

        output_format : str, optional
            Format of the output. Accepted values are either "df" (dataframe) or "json", by default "df"

        json_orientation : str, optional
            If ``output_format='json'``, select orientation that will be used by pandas to generate the json string. Refer https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_json.html for detailed information on this parameter, by default its "columns".

        pages : Union[str, int], optional
            An optional value specifying pages to extract from. It is a parameter used by camelot., by default "all". For example::

                '1-2,3', 'all'

        stream : bool, optional
            Force PDF to be extracted using stream-mode extraction (if there are no ruling lines separating each cell, as in a PDF of an Excel).It is a parameter used by camelot., by default False, i.e., camelot uses lattice method of extracting tables.

        password : str, optional
            Password to decrypt document. It is a parameter used by camelot, by default None

        Returns
        -------
        list
            List of tables in ``output_format``

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.
        """
        # Data Validation
        if not os.path.exists(input_file_path):
            raise ValueError(f"Given {input_file_path} is not available.")
        elif output_format not in ["df", "json"]:
            raise ValueError("supported output formats are 'df' or 'json'")

        if isinstance(pages, int):
            pages = str(pages)

        # Set flavor param for camelot
        if stream:
            flavor = "stream"
        else:
            flavor = "lattice"  # Default value for camelot

        list_tables = read_pdf(
            input_file_path,
            pages=pages,
            password=password,
            flavor=flavor,
        )
        list_tables = [table.df for table in list_tables if not table.df.empty]
        self.logger.info(f"Number of tables extracted : {len(list_tables)}")

        if output_format == "json":
            list_tables = [table.to_json(orient=json_orientation) for table in list_tables]

        return list_tables

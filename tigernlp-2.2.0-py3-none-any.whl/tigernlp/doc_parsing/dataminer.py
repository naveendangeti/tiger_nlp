from tigernlp.core.utils import MyLogger

from .image_extraction.pdf_miner import PdfMiner_Image
from .image_extraction.pymupdf import PyMuPdf_Image
from .image_extraction.pypdf2 import PyPdf2_Image
from .table_extraction.camelot import Camelot
from .table_extraction.tabula import Tabula
from .text_extraction.pdf_miner import PdfMiner
from .text_extraction.pdf_plumber import PdfPlumber

# from .text_extraction.pdftotext import PDFtoText
from .text_extraction.pymupdf import PyMuPdf
from .text_extraction.pypdf2 import PyPdf2
from .text_extraction.pypdfium import PyPDFium


class DataMiner:
    """DataMiner class to extract text, tables, images from given douments.

    Example
    -------
    >>> from tigernlp.data_miner.api import DataMiner
    >>> DM = DataMiner()
    >>> data = DM.extract(input_file_path = "path\\to\\file")
    >>> data
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """Data Miner class initialization"""

        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def extract(
        self,
        input_file_path=None,
        extract_text=True,
        extract_text_method="pypdfium",
        extract_table=False,
        extract_table_method="camelot",
        extract_image=False,
        extract_image_method="pymupdf_image",
        output_format="dict",
    ):
        """
        DataMiner extract function to extract text, tables, images from given douments.

        Parameters
        ----------
        input_file_path : str
            Relative or Absolute path of the file. by default "None"
        extract_text : bool
            True if text is to extracted form the files. default True
        extract_text_method : str, optional
            type of method to extract text, by default "pypdfium"
            available options are pypdfium, pdf_miner, pdf_plumber, pymupdf, pypdf2
        extract_table : bool
            True if tables is to extracted form the files. default False
        extract_table_method : str, optional
            type of method to extract table, by default "camelot"
            options are camelot, tabula
        extract_image : bool
            True if image is to extracted form the files. default False
        extract_image_method : str, optional
            type of method to extract images, by default "pymupdf_image"
            options are pdf_miner_image, pymupdf_image, pypdf2_image
        output_format : str
            format of the output. Accepted values are "dict" or "json"


        Returns
        -------
        data: Union[dict,json,text file]
            Extracted text in "output_format"
            The extracted data can be obtained in two formats:
            1. python dictionary : The pages would be the keys and the extracted text would be the value for each key
            2. json : the extracted text would be displayed as json object
        """

        output = {}

        self.extract_text_method = extract_text_method
        self.extract_table_method = extract_table_method
        self.extract_image_method = extract_image_method
        self.input_file_path = input_file_path
        self.output_format = output_format

        if extract_text:
            try:
                self.logger.info(f"Extracting text using {self.extract_text_method} method")

                data_text = self.__get_text()
                output["text"] = data_text
            except Exception as e:
                self.logger.error(f"{e}")

        if extract_image:
            try:
                self.logger.info(f"Extracting image using {self.extract_image_method} method")

                data_image = self.__get_image()
                output["image"] = data_image
            except Exception as e:
                self.logger.error(f"{e}")

        if extract_table:
            try:
                self.logger.info(f"Extracting table using {self.extract_table_method} method")

                data_table = self.__get_table()
                output["table"] = data_table
            except Exception as e:
                self.logger.error(f"{e}")

        return output

    def __get_table(self):

        try:
            if self.extract_table_method == "camelot":
                dm = Camelot()
            elif self.extract_table_method == "tabula":
                dm = Tabula()
            else:
                raise ValueError("Available options to extract table are camelot and tabula")

            if self.output_format == "dict":
                table_format = "df"
            else:
                table_format = "json"

            data = dm.extract(input_file_path=self.input_file_path, output_format=table_format)

            return data
        except Exception as e:
            self.logger.error(
                f"Error during Table extraction using {self.extract_table_method} {e}"
            )

    def __get_image(self):
        try:
            if self.extract_image_method == "pymupdf_image":
                dm = PyMuPdf_Image()
            elif self.extract_image_method == "pdf_miner_image":
                dm = PdfMiner_Image()
            elif self.extract_image_method == "pypdf2_image":
                dm = PyPdf2_Image()
            else:
                raise ValueError(
                    "Available options are pymupdf_image, pdf_miner_image and pypdf2_image"
                )

            data = dm.extract(
                input_file_path=self.input_file_path, output_format=self.output_format
            )

            return data

        except Exception as e:
            self.logger.error(
                f"Error during Image extraction using {self.extract_image_method} {e}"
            )

    def __get_text(self):
        try:
            if self.extract_text_method == "pdf_miner":
                dm = PdfMiner()
            elif self.extract_text_method == "pdf_plumber":
                dm = PdfPlumber()
            # elif self.extract_text_method == "pdftotext":
            #     dm = PDFtoText()
            elif self.extract_text_method == "pymupdf":
                dm = PyMuPdf()
            elif self.extract_text_method == "pypdfium":
                dm = PyPDFium()
            elif self.extract_text_method == "pypdf2":
                dm = PyPdf2()
            else:
                raise ValueError(
                    "Available options are pdf_miner, pdf_plumber, pymupdf, pypdfium and pypdf2"
                )

            data = dm.extract(
                input_file_path=self.input_file_path, output_format=self.output_format
            )

            return data
        except Exception as e:
            self.logger.error(f"Error during Text extraction using {self.extract_text_method} {e}")

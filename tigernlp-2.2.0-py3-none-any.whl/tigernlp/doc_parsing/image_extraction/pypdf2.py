import io
import json
import numpy as np
import os
import PyPDF2
from PIL import Image

from tigernlp.core.utils import MyLogger


class PyPdf2_Image:
    """PyPdf2_Image class to extract  images from given douments.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.doc_parsing.api import PyPdf2_Image
    >>> DM = PyPdf2_Image()
    >>> data = DM.extract(input_file_path = "path\\to\\file")
    >>> data
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """PDFminer_Image class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def extract(self, input_file_path: str = None, output_format: str = "pil"):
        """
        Function to extract image from given douments.

        Parameters
        ----------
        input_file_path : str
            Relative or Absolute path of the file. Default is "None"

        output_format : str, optional
            Format of the output. Accepted values are "pil" or "json"

        Returns
        -------
        data: json/dict
            dict of keys as document name and values as dict containg image, or as json object.

        """
        try:
            if input_file_path is None:
                raise ValueError("file_path were passed None. Please provide the path.")

            if not os.path.exists(input_file_path):
                raise ValueError(f"Given {input_file_path} is not available.")

            if output_format == "json":
                self.return_format = "json"
            else:
                self.return_format = "pil"

            data = self.__get_image(input_file_path=input_file_path)
            return data
        except Exception as e:
            self.logger.error(f"The following error occurred while extracting images from PyPdf2_Image class {e}")

    def __get_image(self, input_file_path) -> dict:
        """Extracts text of a give file in the path variable.

        Parameters
        ----------
        input_file_path: str
            path of a file

        Returns
        -------
        data_image: pil/json
            all the images in the file."""

        try:
            data_image_json = {}
            data_image_pil = {}
            data_image_bytes = {}
            PDFfile = open(input_file_path, "rb")
            reader = PyPDF2.PdfReader(PDFfile)
            page_index = 1
            for page in reader.pages:
                image_index = 1
                for image in page.images:
                    image_bytes = image.data
                    image = Image.open(io.BytesIO(image_bytes))
                    image_json = json.dumps(np.array(image).tolist())
                    image_pil = Image.fromarray(np.array(json.loads(image_json), dtype="uint8"))
                    data_image_bytes[f"page_{page_index}_image_{image_index}.png"] = image_bytes
                    data_image_json[f"page_{page_index}_image_{image_index}.png"] = image_json
                    data_image_pil[f"page_{page_index}_image_{image_index}.png"] = image_pil
                    image_index += 1
                page_index += 1
            if self.return_format == "bytes":
                return data_image_bytes
            if self.return_format == "json":
                return data_image_json
            if self.return_format == "pil":
                return data_image_pil
        except Exception as exc:
            self.logger.error(f"PyPdf2_Image extraction failure: {exc}")

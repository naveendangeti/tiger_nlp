import spacy
import subprocess

from tigernlp.core.utils import MyLogger

logger = MyLogger(level="WARNING", log_file_path=None, verbose=True).logger


def generate_index_labels(text: str, entities: list, tags: list, nlp: spacy.language.Language):
    """For a given text, this function returns the tuple of start_index, end_index of the entity present in the text and label of the entity.

    Parameters
    ----------
    text : str
        Sentence that is used for generating the index and tags. Example - "Barack Obama was born in Hawaii."
    entities : list
        List of entities which is present in the text. Example - ["Barack Obama", "Hawaii"]
    tags : list
        List of tags which is corresponding to the entities. Eaxmple - ["PER", "LOC"]
    nlp : spacy.language.Language
        Spacy language model. Example - spacy.load('en_core_web_sm')
    logger : MyLogger
        Logger object to log the information, warning and errors

    Returns
    -------
    list of tuple
        Each tuple in list includes start_index,end_index and tag of an entity.Here start_index is inclusive in the entity and end_index is exclusive

    Raises
    ------
    TypeError
        when entities, text, tags are not in correct format
    Exception
        when any other error occur during the index generation

    Examples
    --------
    >>> from tigernlp.custom_spacy.api import generate_index_labels
    >>> text = "Barack Obama was born in Hawaii."
    >>> entities = ["Barack Obama", "Hawaii"]
    >>> tags = ["PER", "LOC"]
    >>> nlp = spacy.load('en_core_web_sm')
    >>> logger = MyLogger()
    >>> generate_index_labels(text, entities, tags, nlp, logger)
    >>> [(0, 12, 'PER'), (24, 30, 'LOC')]


    """
    try:
        if not (isinstance(entities, list)):
            raise TypeError(f"Bad ip. {entities} is of incorrect datatype")

        elif not (isinstance(text, str)):
            raise TypeError(f"Bad ip. {text} is of incorrect datatype")

        elif not (isinstance(tags, list)):
            raise TypeError(f"Bad ip. {tags} is of incorrect datatype")

        parsed_sentence = nlp(text)
        index_tag = []
        for entity, tag in zip(entities, tags):
            entities_tokens = entity.split()
            complete_length = len(entity)
            start_index = -1
            end_index = -1
            for token in parsed_sentence:
                if entities_tokens[0] == token.text:
                    start_index = token.idx
                    flag = False
                    for index in index_tag:
                        complete_length1 = index[1] - index[0]
                        if start_index >= index[0] and start_index <= index[1]:
                            if complete_length <= complete_length1:
                                flag = True
                                break
                    if flag:
                        start_index = -1
                        continue
                if entities_tokens[-1] == token.text:
                    end_index = token.idx + len(token.text)
                    flag = False
                    for index in index_tag:
                        complete_length1 = index[1] - index[0]
                        if end_index >= index[0] and end_index <= index[1]:
                            if complete_length <= complete_length1:
                                flag = True
                                break
                    if flag:
                        end_index = -1
                        continue
                    if complete_length == (end_index - start_index):
                        index_tag.append((start_index, end_index, tag))

        remove_index = []
        for idx, index in enumerate(index_tag):
            complete_length = index[1] - index[0]
            if (index[0] == -1) or (index[1] == -1):
                remove_index.append(idx)
                continue
            for index1 in index_tag:
                complete_length1 = index1[1] - index1[0]
                if index1[0] > index[0] and index1[1] <= index[1]:
                    remove_index.append(idx)
                    continue
                if index1[0] >= index[0] and index1[1] < index[1]:
                    remove_index.append(idx)
                    continue

        index_tags = []
        for idx in range(len(index_tag)):
            if idx not in remove_index:
                index_tags.append(index_tag[idx])

        return list(set(index_tags))
    except Exception as e:
        logger.error(f"An Error occurred during fetching index value for entity.The error message is: {e}")
        raise ValueError(f"An Error occurred during fetching index value for entity.The error message is: {e}")


def run_cli(cli_command: str, cwd: str = None, logger=None, verbose: bool = False):
    """
    Runs a command line interface (CLI) command using the subprocess module. This function is used to run any command that can be run from the command line.The command's output and error messages are logged using the provided loggeror printed to the console if verbose is True.

    Parameters
    ----------
    cli_command : str
        A string containing the command to be run in the command line.
    cwd : str, optional
        The current working directory to run the command in.
        If not provided, the command will be run in the current working directory.
    logger : logger object, optional
        A logger object to log the command's output and error messages.
        If not provided, the output will not be logged.
    verbose : bool, optional
        If True, the command's output and error messages will be printed to the console.
        If False or not provided, the output will only be logged if a logger is provided.

    Raises
    ------
    subprocess.CalledProcessError
        If the command returns a non-zero exit code, indicating an error occurred.

    Examples
    --------
    >>> from tigernlp.custom_spacy.api import run_cli
    >>> run_cli("echo 'Hello World!'", verbose=True)
    >>> This will print the output "Hello World!" on the console.
    >>> logger = MyLogger(level="INFO", log_file_path="mylogs.log", verbose=True)
    >>> run_cli("ls -al", cwd="/home/user/", logger=logger)

    This will run the command ls -al in the directory /home/user/ and the output will be logged in the file mylogs.log and also printed on the console.
    """

    with subprocess.Popen(
        cli_command,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True,
        bufsize=1,
        universal_newlines=True,
    ) as p:
        for line in p.stdout:
            if logger:
                logger.info(line)
            elif verbose:
                print(line)

    if p.returncode != 0:
        raise subprocess.CalledProcessError(p.returncode, p.args)

import configparser
import os

from tigernlp.core.api import spacy_download_validate
from tigernlp.core.utils import MyLogger

from .evaluate import SpacyEvaluate
from .utils import run_cli


class SpacyTrainer:
    """The SpacyTrainer class is a utility class that provides functionalities for training spaCy models.
    It has the following methods:

        1. generate_config: generates a spaCy configuration file for a given pipeline and optimization method.

        2. train: trains a spaCy model using specified train and validation data, and saves the trained model to the specified directory.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        Examples
        ---------
        >>> from tigernlp.custom_spacy.api import SpacyTrainer
        >>> trainer = SpacyTrainer()
        >>> trainer.generate_config(config_save_path = "project_folder/config/config_version.cfg",
        >>>                         model_pipeline = "ner",
        >>>                         optimize = "efficiency",
        >>>                         gpu = False)
        >>> trainer.train(train_path = "project_folder/data/train_data.spacy",
        >>>               validation_path = "project_folder/data/validation_data.spacy",
        >>>               config_path = "project_folder/config/config_version.cfg",
        >>>               model_save_path = "project_folder/outputs/model_version/",
        >>>               test_path = "project_folder/data/test_data.spacy",
        >>>               metrics_json_save_path = "project_folder/outputs/model_version/metrics")
    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """SpacyTrainer class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_config(
        self,
        config_save_path: str,
        model_pipeline: str,
        optimize: str = "efficiency",
        gpu: bool = False,
        pretrained_model_config_path: str = None,
    ):

        """Generates a spaCy configuration file for a given pipeline and optimization method.

        Parameters
        ----------
        config_save_path : str
            The full file path where the generated configuration file will be saved. Example - "project_folder/config/config_version.cfg".
        model_pipeline : str
            The name of the pipeline to be used. Example 'ner', 'tagger', etc.
        optimize : str, optional
            The optimization method to be used. Options "efficiency", "accuracy". Default "efficiency".
        gpu : bool, optional
            Whether to use GPU for processing. Default False.
        pretrained_model_config_path : str, optional
            The config path for the pretrained_model. Should be provided for retraining model. When provided, it will read the config file and fill/update the given parameter and save it in config_save_path. Example - "project_folder/config/config_version_old.cfg". Default None.

        Raises:
        -------
        TypeError
            Raises type error when config_save_path is not a string, or optimize is not a string, or pretrained_model_config_path is not a string.
        ValueError
            Raises value error when optimize is not one of "efficiency" or "accuracy".

        Examples
        --------
        >>> from tigernlp.custom_spacy.api import SpacyTrainer
        >>> trainer = SpacyTrainer()
        >>> trainer.generate_config(config_save_path = "project_folder/config/config_version.cfg",
        >>>                         model_pipeline = "ner",
        >>>                         optimize = "efficiency",
        >>>                         gpu = False)


        """
        try:
            if not isinstance(config_save_path, str):
                raise TypeError(f'Expected "config_save_path" to be a string, got "{type(config_save_path)}"')
            if pretrained_model_config_path is not None:
                if not isinstance(pretrained_model_config_path, str):
                    raise TypeError(f'Expected "pretrained_model_config_path" to be a string, got "{type(pretrained_model_config_path)}"')
            if not isinstance(optimize, str):
                raise TypeError(f'Expected "optimize" to be a string, got "{type(optimize)}"')
            if optimize not in {"efficiency", "accuracy"}:
                raise ValueError(f'Expected "optimize" to be either "efficiency" or "accuracy", got "{optimize}"')

            if not os.path.isdir(os.path.dirname(config_save_path)):
                os.makedirs(os.path.dirname(config_save_path))

            gpu_commad = "--gpu" if gpu else ""

            if pretrained_model_config_path:
                config_gen_command = f"python -m spacy init fill-config {pretrained_model_config_path} {config_save_path} --pretraining"
            else:
                config_gen_command = f"python -m spacy init config --pipeline {model_pipeline} --optimize {optimize} --force {gpu_commad} {os.path.basename(config_save_path)}"
            run_cli(config_gen_command, cwd=os.path.dirname(config_save_path), logger=self.logger)
            self.logger.info("Config generation succesful.")

        except Exception as e:
            self.logger.error(f"An error occurred during generating the config for the model. The error message is: {e}.")
            raise ValueError(f"An error occurred during generating the config for the model. The error message is: {e}.")

    def train(
        self,
        train_path: str,
        validation_path: str,
        config_path: str,
        model_save_path: str,
        test_path: str = None,
        metrics_json_save_path: str = None,
        spans_key: str = None,
    ):
        """Train a spaCy model using specified train and validation data.

        Parameters
        ----------
        train_path : str
            The file path of the train data with name. Example - "project_folder/data/train_data.spacy".
        validation_path : str
            The file path of the validation data with name. Example - "project_folder/data/validation_data.spacy".
        config_path : str
            The file path of the configuration file with name. Example - "project_folder/config/config_version.cfg".
        model_save_path : str
            The directory path where the trained model will be saved. Example - "project_folder/output/model_version".
        test_path : str
            The file path of the test data with name. Example - "project_folder/data/test_data.spacy". Default None.
        metrics_json_save_path : str
            The folder path where the evaluation metrics will be saved in json format. Example - "project_folder/output/model_version/metrics". Default None will not save any metrics.
        spans_key : str
            The key in the input data that contains the spans of text that need to be categorized. Value is either 'sc' for span_cat or None. Default None.

        Raises
        ------
        OSError
            Train data or Validation data or Config file or Test data is not found at given path.
        subprocess.CalledProcessError
            Any error during training cli.

        Examples
        --------
        >>> from tigernlp.custom_spacy.api import SpacyTrainer
        >>> trainer = SpacyTrainer()
        >>> trainer.train(train_path = "project_folder/data/train_data.spacy",
        >>>               validation_path = "project_folder/data/validation_data.spacy",
        >>>               config_path = "project_folder/config/config_version.cfg",
        >>>               model_save_path = "project_folder/outputs/model_version/",
        >>>               test_path = "project_folder/data/test_data.spacy",
        >>>               metrics_json_save_path = "project_folder/outputs/model_version/metrics")


        """
        try:
            if not os.path.isfile(train_path):
                raise OSError(f"Train data not found at {train_path}")
            if not os.path.isfile(validation_path):
                raise OSError(f"Validation data not found at {validation_path}")
            if test_path is not None:
                if not os.path.isfile(test_path):
                    raise OSError(f"Test data not found at {test_path}")
            if not os.path.isfile(config_path):
                raise OSError(f"Config file not found at {config_path}")

            if not os.path.isdir(model_save_path):
                os.makedirs(model_save_path)

            if metrics_json_save_path is not None:
                if not os.path.isdir(metrics_json_save_path):
                    os.makedirs(metrics_json_save_path)
            else:
                self.logger.info("No value for metrics_json_save_path was passed. Model will not be evaluated.")

            self.logger.info(f"Train data path - {train_path}")
            self.logger.info(f"Validation data path - {validation_path}")
            self.logger.info(f"Config path - {config_path}")

            # If 'accuracy' is selected for optimize, vector model can be set in config.cfg
            # Depending on the model, check if it exists, else download
            parser = configparser.ConfigParser()
            _ = parser.read(config_path)
            vector_model = parser.get("paths", "vectors")
            if vector_model != "null":
                vector_model = eval(vector_model)
                ret = spacy_download_validate(vector_model)
                if not ret:
                    raise ValueError(
                        f"Unable to download {vector_model}. Please check the internet connection and the spelling of the model name."
                    )

            train_command = f"python -m spacy train {config_path} --paths.train {train_path}  --paths.dev {validation_path} --output {model_save_path}"  # > {log_full_path}

            run_cli(train_command, logger=self.logger)

            if metrics_json_save_path is not None:
                model_save_path = os.path.join(model_save_path, "model-best")
                spacy_evaluate = SpacyEvaluate()
                spacy_evaluate.evaluate(
                    train_path,
                    model_save_path,
                    os.path.join(metrics_json_save_path, "train.json"),
                    spans_key=spans_key,
                )
                spacy_evaluate.evaluate(
                    validation_path,
                    model_save_path,
                    os.path.join(metrics_json_save_path, "validation.json"),
                    spans_key=spans_key,
                )
                if test_path is not None:
                    spacy_evaluate.evaluate(
                        test_path,
                        model_save_path,
                        os.path.join(metrics_json_save_path, "test.json"),
                        spans_key=spans_key,
                    )
        except Exception as e:
            self.logger.error(f"An error occurred during the training of the model. The error message is: {e}.")
            raise ValueError(f"An error occurred during the training of the model. The error message is: {e}.")

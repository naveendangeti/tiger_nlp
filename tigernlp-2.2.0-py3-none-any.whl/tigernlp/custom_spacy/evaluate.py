import os

from tigernlp.core.utils import MyLogger

from .utils import run_cli


class SpacyEvaluate:
    """The class SpacyEvaluate is a utility class that provides methods to evaluate a trained spaCy model on given data.

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    ---------
    >>> from tigernlp.custom_spacy.api import SpacyEvaluate
    >>> spacy_evaluate = SpacyEvaluate()
    >>> spacy_evalaute.evaluate(test_path = 'project_folder/data/test.spacy',
                                model_save_path = 'project_folder/output/model/model-best',
                                metrics_json_save_path = 'project_folder/output/metrics')
    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """SpacyEvaluate class initialization

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def evaluate(
        self,
        data_path: str,
        model_save_path: str,
        metrics_json_save_path: str,
        gpu_id: int = -1,
        spans_key: str = None,
    ):
        """Evaluate trained spaCy model on the data taken from the data path provided.

        Parameters
        ----------
        data_path : str
            The file path of the data. Example - 'project_folder/data/test.spacy'
        model_save_path : str
            The directory path containing the spaCy saved model, can be model-best or model-last. Example - 'project_folder/output/model/model-best'
        metrics_json_save_path : str
            The file path where the evaluation metrics will be saved in json format. Example - 'project_folder/output/metrics'
        gpu_id : int, optional
            The option to enable the GPU is 0 or 1 or whichever GPU ID you want it to use. Default -1, disables the GPU.
        spans_key : str
            The key in the input data that contains the spans of text that need to be categorized. Value is either 'sc' for span_cat or None. Default None.

        Raises
        ------
        OSError
            If data_path is invalid.
        subprocess.CalledProcessError
            If an error occurs during the evaluation command-line interface.

        Examples
        ---------
        >>> from tigernlp.custom_spacy.api import SpacyEvaluate
        >>> spacy_evaluate = SpacyEvaluate()
        >>> spacy_evaluate.evaluate(data_path = 'project_folder/data/test.spacy',
        >>>                         model_save_path = 'project_folder/output/model/model-best',
        >>>                         metrics_json_save_path = 'project_folder/output/metrics/test.json')


        """
        try:
            if not os.path.isfile(data_path):
                raise OSError(f"Data not found at {data_path}")
            if not os.path.isdir(os.path.dirname(metrics_json_save_path)):
                os.makedirs(os.path.dirname(metrics_json_save_path))

            self.logger.info(f"data path - {data_path}")

            evaluate_command = f"python -m spacy evaluate {model_save_path} {data_path} --output {metrics_json_save_path} --gpu-id {gpu_id}"

            if spans_key:
                evaluate_command += f" --spans-key {spans_key}"

            run_cli(evaluate_command, logger=self.logger)

        except Exception as e:
            self.logger.error(f"An error occurred during generating the evaluation metrics for the model. The error message is: {e}.")
            raise ValueError(f"An error occurred during generating the evaluation metrics for the model. The error message is: {e}.")

import gensim
import gensim.corpora as corpora
import pandas as pd
from gensim.models import TfidfModel
from typing import Dict, List, Set, Tuple

from tigernlp.core.api import MyLogger

from .utils import TextProcessor


def number_data_words_dataframe(stem_text: List) -> Tuple[pd.DataFrame, List, List]:
    """Summary of passed data. For example - number of entries, number of unigrams, number of polygrams, list of unigrams and polygrams separately

    Parameters
    ----------
    stem_text : list
        List of data words/tokens list for each text entry

    Returns
    -------
    pd.DataFrame
        DataFrame with summary of number of entries, number of unigrams in all input data, number of polygrams in all input data
    list
        list of unigrams present in input data
    list
        list of polygrams present in input data
    """
    df = pd.DataFrame()
    df["# unique texts"] = [len(stem_text)]
    x = 0
    y = 0
    only_unigrams = []
    only_polygrams = []
    for i in stem_text:
        temp1 = []
        temp2 = []
        for j in i:
            if "_" in j:
                y = y + 1
                temp2.append(j)
            else:
                x = x + 1
                temp1.append(j)
        only_unigrams.append(temp1)
        only_polygrams.append(temp2)
    df["# unigrams"] = [x]
    df["# polygrams"] = [y]
    return df, only_unigrams, only_polygrams


def generate_gensim_phrases(
    sentences: List[str],
    min_count: int = 5,
    threshold: float = 10.0,
    max_vocab_size: int = 40000000,
    delimiter: str = "_",
    progress_per: int = 10000,
    scoring: str = "default",
    connector_words: Set[str] = frozenset(),
) -> List:
    """Create gensim phrases with minnimum count and threshold scores from the given sentences

    Parameters
    ----------
    sentences : iterable of list of str
        the `sentences` iterable can be simply a list, but for larger corpora, consider a generator that streams
        the sentences directly from disk/network, See :class:`~gensim.models.word2vec.BrownCorpus`,
        :class:`~gensim.models.word2vec.Text8Corpus` or :class:`~gensim.models.word2vec.LineSentence`
        for such examples
    min_count : int, optional
        ignore all phrases with total collected count lower than this value, by default 5
    threshold : float, optional
        represent a score threshold for forming the phrases (higher means fewer phrases).
        A phrase of words `a` followed by `b` is accepted if the score of the phrase is greater than threshold.
        Heavily depends on concrete scoring-function, see the `scoring` parameter, by default 10.0
    max_vocab_size : int, optional
        maximum size (number of tokens) of the vocabulary. Used to control pruning of less common words,
        to keep memory under control. The default of 40M needs about 3.6GB of RAM. Increase/decrease
        `max_vocab_size` depending on how much available memory you have, by default 40,000,000
    delimiter : str, optional
        glue character used to join collocation tokens, by default "_"
    scoring : {'default', 'npmi', function}, optional
        specify how potential phrases are scored. `scoring` can be set with either a string that refers to a
        built-in scoring function, or with a function with the expected parameter names.
        Two built-in scoring functions are available by setting `scoring` to a string:

        #. "default" - :func:`~gensim.models.phrases.original_scorer`.
        #. "npmi" - :func:`~gensim.models.phrases.npmi_scorer`, by default "default"
    connector_words : set of str, optional
        set of words that may be included within a phrase, without affecting its scoring.
        No phrase can start nor end with a connector word; a phrase may contain any number of
        connector words in the middle.

        **If your texts are in English, set** ``connector_words=phrases.ENGLISH_CONNECTOR_WORDS``.

        This will cause phrases to include common English articles, prepositions and
        conjuctions, such as `bank_of_america` or `eye_of_the_beholder`.

        For other languages or specific applications domains, use custom ``connector_words``
        that make sense there: ``connector_words=frozenset("der die das".split())`` etc, by default frozenset()

    Returns
    -------
    list
        List of gensim phrases
    """
    # Build the ngram model
    ngram = gensim.models.Phrases(
        sentences,
        min_count=min_count,
        threshold=threshold,
        max_vocab_size=max_vocab_size,
        delimiter=delimiter,
        progress_per=progress_per,
        scoring=scoring,
        connector_words=connector_words,
    )  # higher threshold fewer phrases.

    # Faster way to get a sentence clubbed as a ngram
    ngram_mod = gensim.models.phrases.Phraser(ngram)
    # Create and return list of ngrams
    return [ngram_mod[doc] for doc in sentences]


def cluster_model_data_preparation(
    input_text: List,
    operation: str = "only_unigram",
    phrase_level: int = 2,
    min_count: int = 1,
    threshold: float = 3,
    log_level: str = "WARNING",
    log_file_path: str = None,
    verbose: bool = True
) -> Tuple[List, List, Dict, List]:
    """Function to prepare data required for GSDMM/LDA/K-means clustering models

        Parameters
        ----------
        input_text : list
            list of text documents to cluster
        operation : str, optional
            specifies number of words in phrases (n-grams) to consider for clustering, only_unigram/only_polygram/both, by default "only_unigram"

            Option `only_polygram` will remove all the unigram phrases from the generated gensim phrases, whereas `both` will keep all the phrases.
        phrase_level : int, optional
            number of times gensim phrases will be generated, by default 2

            The value should be >=1. Optimal recommended value is 1 or 2.
            Value 1 will join unigrams and generate bigrams, value 2 will join unigrams/bigrams with unigrams/bigrams and will generate trigram/fourgram and so on.
        min_count : int, optional
            minimum number of occurences/count for the gensim phrases, by default 1
        threshold : float, optional
            gensim phrases with gensim.models.phrases.original_scorer (by default) score greater than or equal to the threshold value will be considered.
            higher threshold means fewer phrases, by default 3
        log_level : str, optional
            Level or severity of the events they are used to track, by default "WARNING"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True
        Returns
        -------
        input_text : list
            list of text documents to cluster

            For example: ["this is datawords sample", "this is one more"]
        list
            list contains list of tuples, where each list represents one sentence, and each tuple represents word ID and number of occurences for word id in the sentence.

            For example: ``[[(0,1), (1,1), (2,1), (3,1)], [(0,1), (1,1), (4,1), (5,1)]]``
            In first sentence, word ID "2" occurs once whereas it is not present in second sentence
        dictionary
            ID to word dictionary where IDs are keys and words are values.
            Each word will have unique ID associated with it.

            For example ``{0 : "this", 1 : "is", 2 : "datawords", 3 : "sample", 4 : "one", 5 : "more"}``
        list
            list of tokenized sentences generated using input_text

            For example: ``[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]``

        Raises
        ------
        ValueError
            Operation parameter supports only only_unigram/only_polygram/both values. ValueError will be raised for other inputs

        Examples
        ----------
        >>> from tigernlp.text_processing.api import cluster_model_data_preparation
        >>> cleaned_text_for_clustering = ["this is datawords sample", "this is one more"] # Large dataset required
        >>> input_text, corpus, id2word, data_words  = (
        >>>     cluster_model_data_preparation(
        >>>         cleaned_text_for_clustering,
        >>>         operation="both",
        >>>         phrase_level=2,
        >>>         min_count=1,
        >>>         threshold=3
        >>>     )
        >>> )
    """

    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    text_col = "text"
    # Create DataFrame from given series.
    frame = {text_col: input_text}
    input_text = pd.DataFrame(frame)
    input_text.fillna("", inplace=True)
    data = input_text.text.values.tolist()

    tp = TextProcessor(input_text)

    # generating 2d matrix containing tokens
    data_words = list(tp.sentence_to_words(data))
    data_words_unigram_tokens = data_words

    # Build the gensim phrases polygram_level times
    # It will cgreate polygrams.

    # removing polygrams
    if operation == "only_unigram":
        data_words = data_words_unigram_tokens
    else:
        if phrase_level < 1:
            logger.error(f"""phrase_level can have minimum value 1. You provided  {phrase_level}. Please provide supported one.""")
            raise ValueError(f"""phrase_level can have minimum value 1. You provided  {phrase_level}. Please provide supported one.""")
        i = 1

        while i <= phrase_level:
            data_words = generate_gensim_phrases(data_words, min_count=min_count, threshold=threshold)
            i += 1
        # removing empty stems
        input_text, data_words = tp.remove_empty_stems(input_text, data_words)
        data_words_unigram_tokens = [ele for ele in data_words_unigram_tokens if ele != []]

        dfx2, only_unigrams, only_polygrams = number_data_words_dataframe(stem_text=data_words)
        # removing unigrams
        if operation == "only_polygram":
            data_words = only_polygrams

        elif operation == "both":
            # data_words already contain mixture of unigrams and polygrams.
            # No need to do anything axplicitly.
            pass
        else:
            logger.error(
                f"""Operation parameter supports only only_unigram/only_polygram/both values. You have provided operation {operation} which is not supported by the current pipeline"""
            )
            raise ValueError(
                f"""Operation parameter supports only only_unigram/only_polygram/both values.  You have provided operation {operation} which is not supported by the current pipeline"""
            )
    # Create Dictionary
    id2word = corpora.Dictionary(data_words)

    # Create Corpus
    # Term Document Frequency
    corpus = [id2word.doc2bow(text) for text in data_words]

    tfidf = TfidfModel(corpus, id2word=id2word)
    low_value = 0.05
    words = []
    words_missing_in_tfidf = []
    for i in range(0, len(corpus)):
        bow = corpus[i]
        low_value_words = []
        tfidf_ids = [id for id, value in tfidf[bow]]
        bow_ids = [id for id, value in bow]
        low_value_words = [id for id, value in tfidf[bow] if value < low_value]
        drops = low_value_words + words_missing_in_tfidf
        for item in drops:
            words.append(id2word[item])
        words_missing_in_tfidf = [id for id in bow_ids if id not in tfidf_ids]  # The words with tf-idf socre 0 will be missing
        new_bow = [b for b in bow if b[0] not in low_value_words and b[0] not in words_missing_in_tfidf]
        corpus[i] = new_bow

    return input_text["text"], corpus, id2word, data_words

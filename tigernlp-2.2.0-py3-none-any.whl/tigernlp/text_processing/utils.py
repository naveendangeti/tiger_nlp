import contractions
import emoji
import gensim
import itertools
import nltk
import numpy as np
import os
import pandas as pd
import re
import spacy
import sys
import traceback
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from spellchecker import SpellChecker
from spellchecker.utils import ensure_unicode
from typing import List, Set, Union
from urllib.parse import urlparse

from tigernlp.core.api import Pipeline
from tigernlp.core.nlp_downloads import download_nltk_data, set_nltk_data_path

from ..core.api import MyLogger, parallelize, verify_spacy

bin_path = os.path.abspath(os.path.join(sys.executable, os.pardir))
bin_flag = 0
if bin_path in sys.path:
    sys.path.remove(bin_path)
    bin_flag = 1


if bin_flag == 1:
    sys.path.append(bin_path)


class TextProcessor:

    """A class containing text data processing with standard NLP pre-processing steps/ functions.

    This can be used on any text data

    Parameters
    ----------
    df: None, optional (pd.DataFrame or pd.Series)
        pandas dataframe or series containing `text` column. By default, None.
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True
    log_level : str, optional
        Level or severity of the events they are used to track, by default "WARNING"
    en_core_web_model_path: str, optional, default:"en_core_web_sm"
        Specify which Spacy english model is to be used. Valid options are "en_core_web_sm", "en_core_web_md", "en_core_web_lg".
        If unable to download en_core_web model, path of the model can be provided manually here.
        If providing the directory location of the model, make sure it is a valid string.

        example: ``r"C:/folder/subfolder/en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0"``
        or ``r"C:\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
        or ``"C:\\\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
    nltk_data_path: str, optional
            Directory location of the `nltk_data` folder.

    Examples
    --------
    >>> from tigernlp.text_processing.api import TextProcessor
    >>> ip_file = "path_to_data.csv"
    >>> df = pd.read_csv(ip_file)
    >>> tp = TextProcessor(df=df, log_file_path=None, verbose=True, log_level="WARNING")
    """

    def __init__(
        self,
        df=None,
        log_level="WARNING",
        log_file_path=None,
        verbose=True,
        en_core_web_model_path="en_core_web_sm",
        nltk_data_path=None,
    ):
        """__init__ Initialise required NLP operations.

        Initialises required NLP operations from `NLTK`, `spacy`, `Punctuator` (Ex: stemming, lemmetizing, corpus, stopwords)

        Parameters
        ----------
        df: None, optional (pd.DataFrame or pd.Series)
            pandas dataframe or series containing `text` column. By default, None.
        log_level : str, optional
            Level or severity of the events they are used to track, by default "WARNING"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True
        en_core_web_model_path: str, optional, default:"en_core_web_sm"
            Specify which Spacy english model is to be used. Valid options are "en_core_web_sm", "en_core_web_md", "en_core_web_lg".
            If unable to download en_core_web model, path of the model can be provided manually here.
            If providing the directory location of the model, make sure it is a valid string.

            example: ``r"C:/folder/subfolder/en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0"``
            or ``r"C:\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
            or ``"C:\\\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
        nltk_data_path: str, optional
            Directory location of the `nltk_data` folder. If nothing is provided, data is searched in default locations.

        """
        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose
        self.logger = MyLogger(
            level=log_level, log_file_path=self.log_file_path, verbose=self.verbose
        ).logger

        if df is not None:
            if not (isinstance(df, pd.DataFrame) or isinstance(df, pd.Series)):
                self.logger.error(
                    "Input data is of incorrect type - {}. Can not proceed further, "
                    "Requires a pandas DataFrame or Series".format(type(df))
                )
                raise ValueError("Input data is incorrect")
            if isinstance(df, pd.Series):
                df = pd.DataFrame(df)
            self.df = df
        else:
            self.df = pd.DataFrame()

        # Default Spacy version
        self.SPACY_DEFAULT_VERSION = "3.3.0"

        if not isinstance(en_core_web_model_path, str):
            self.logger.error('"en_core_web_model_path" paramter must be a string')
            raise ValueError('"en_core_web_model_path" must be a string')

        # If slash in string, it means its a directory. If directory doesn't exist then raise an error
        if (
            "\\" in en_core_web_model_path or os.sep in en_core_web_model_path
        ) and not os.path.isdir(en_core_web_model_path):
            self.logger.error(
                f'"{en_core_web_model_path}" is not a valid directory. Make sure the right path to model is provided.'
            )
            raise ValueError(f'"{en_core_web_model_path}" is not a valid directory')

        # If model name is provided
        if not os.path.isdir(en_core_web_model_path) and en_core_web_model_path not in [
            "en_core_web_sm",
            "en_core_web_md",
            "en_core_web_lg",
        ]:
            self.logger.error(
                'Only english models are accepted. Valid options to en_core_web_model are "en_core_web_sm", "en_core_web_md", "en_core_web_lg". If you are trying to pass a path, make sure it exists.'
            )
            raise ValueError(
                'Valid options to en_core_web_model are "en_core_web_sm", "en_core_web_md", "en_core_web_lg". If you are trying to pass a path, make sure it exists.'
            )
        # If en_core_web is manually downloaded and its path is provided
        spacy_validated = verify_spacy(en_core_web_model_path, self.SPACY_DEFAULT_VERSION)
        if spacy_validated:
            self.nlp = spacy.load(en_core_web_model_path)
        else:
            self.logger.warn(
                """Below Functions that utilizes spacy model will not work as spacy models are not available to use.

                1. POS
                2. NER
                3. lemmatization
                4. tokenization
            """
            )
            # if validation failed, no point in running it again.
            # self.nlp = spacy.load(en_core_web_model_path)
            # self.logger.error(
            #     """Provided model version is {} whereas the required version is {}.""".format(
            #         self._get_spacy_model_version(), self.SPACY_DEFAULT_VERSION
            #     )
            # )
            # self.logger.info(
            #     "Run 'python -m spacy download en_core_web_sm' in your terminal to download the required version of spacy model. Replace en_core_web_sm to en_core_web_md or en_core_web_lg for medium or large models respectively."
            # )
            # raise ValueError(
            #     """Provided model version is {} whereas the required version is {}. Can not proceed further.""".format(
            #         self._get_spacy_model_version(), self.SPACY_DEFAULT_VERSION
            #     )
            # )

        if nltk_data_path:
            if not isinstance(nltk_data_path, str):
                self.logger.error(
                    "Input path is of incorrect type - {}. Can not proceed further, "
                    "Requires a string".format(type(nltk_data_path))
                )
                raise ValueError("Input path is of incorrect type.")

            if not os.path.isdir(nltk_data_path):
                raise ValueError(f"{nltk_data_path} is not a valid directory")

            set_nltk_data_path(nltk_data_path)

        try:
            error_block = """One or more models from NLTK are not downloaded. Thus, below functions that utilizes NLTK's model will not work as expected.
                1. stemming.
                2. lemmatization.
                3. remove unmeaningful words.
                4. NER.
                5. POS.
                6. truecasing/camelcasing.

                For manual installation, follow below steps.

                1. Download the below nltk module as zip from https://github.com/nltk/nltk_data/tree/gh-pages/packages or https://www.nltk.org/nltk_data/
                    1. maxent_ne_chunker
                    2. omw-1.4
                    3. stopwords
                    4. wordnet
                    5. words
                    6. tagsets
                    7. averaged_perceptron_tagger
                    8. punkt

                2. Once it's downloaded, unzip the file into respective folder to maintain the folder structure as shown below and note the path where these modules are saved.
                    1. chunkers/maxent_ne_chunker
                    2. corpora/omw-1.4
                    3. corpora/stopwords
                    4. corpora/wordnet
                    5. corpora/words
                    6. help/tagsets
                    7. taggers/averaged_perceptron_tagger
                    8. tokenizers/punkt

                3. Make sure the correct path for nltk_data is passed to the module as follows:

                >>> tp = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "WARNING", nltk_data_path = directory_location/modules_saved_path")
                """
            error_flag = download_nltk_data()
            if error_flag:
                self.logger.warn(f"{error_block}")

        except Exception:
            self.logger.warn(traceback.format_exc())
            self.logger.warn(f"{error_block}")

        self.st = nltk.PorterStemmer()
        self.lm = nltk.WordNetLemmatizer()
        self.nltk_words = {w.lower() for w in nltk.corpus.words.words()}

        self.punc = None
        self.punc_model_path = None
        self.pipeline = Pipeline(log_level=log_level, log_file_path=log_file_path, verbose=verbose)
        self.spellChecker = SpellChecker()

    @staticmethod
    def _get_URL(text: str, url_pattern: str) -> list:
        """Gets the URL from text

        Parameters
        ----------
        text : string
            Sentence or conversation block from which URL is to be extracted
        url_pattern : string
            regex pattern to extract the URL from a string. `(http?\://\S+|https?\://\S+|www\.\S+)`

        Returns
        -------
        list
        list of URLs identified in the text. If there is no URL in the text, returns nan.
        """
        urls = re.findall(pattern=url_pattern, string=str(text), flags=re.IGNORECASE)

        if len(urls) == 0:
            return "nan"

        return urls

    @staticmethod
    def _get_domain(text: str, url_pattern: str) -> list:
        """Get domain name from a URL

        Parameters
        ----------
        text : string
            Sentence or conversation block from which URL domain is to be extracted
        url_pattern : raw str
            regex pattern

        Returns
        -------
        list
            list of domains identified from the text URL. If there is no URL in the text, returns nan.
        """
        text = TextProcessor._get_URL(text, url_pattern)

        if text == "nan":
            return np.nan

        if text != "nan":
            domain = []
            for link in text:
                domain.append(urlparse(link).netloc)
            return domain

    def _get_pos(self, text: str, keep_pos_only: bool, tag_list=list()) -> dict:
        """Generates parts of speech tags for a given sentence.

        Parameters
        ----------
        text : string
            Sentence or conversation block.

        tag_list : list, optional
            List of specific POS tags.
            Filters the output and returns only the words and POS tag pairs, that are passed to this parameter.
            if nothing is passed, by default the dictionary with all tags and word pairs will be returned.
            the passed list should contain any of the following:
            ["ADJ", "ADP", "ADV", "AUX", "CONJ", "DET", "INTJ", "NOUN", "NUM", "PART", "PRON", "PROPN", "PUNCT", "SCONJ", "SYM", "VERB", "X", "EOL", "SPACE"]

            abbreveations: {'ADJ': 'adjective', 'ADP': 'adposition', 'ADV': 'adverb',
            'AUX': 'auxiliary', 'CONJ': 'conjunction', 'DET': 'determiner', 'INTJ': 'interjection',
            'NOUN': 'noun', 'NUM': 'numeral', 'PART': 'particle', 'PRON': 'pronoun',
            'PROPN': 'proper noun', 'PUNCT': 'punctuation', 'SCONJ': 'subordinating conjunction',
            'SYM': 'symbol', 'VERB': 'verb', 'X': 'other', 'EOL': 'end of line', 'SPACE': 'space'}
        keep_pos_only: bool
            If true, then function would return the text with desired POS tags only. By default, False.

        Returns
        -------
        dict
            dictionary of word and POS tag pairs after filtering for pos tags entered in tag_list.
        """
        pos_dict = {}
        doc = self.nlp(text)
        if len(tag_list) != 0:
            for token in doc:
                if token.pos_ in tag_list:
                    pos_dict[token.text] = token.pos_
            if keep_pos_only:
                pos_list = []
                for k, v in pos_dict.items():
                    pos_list.append(k)
                text = " ".join(pos_list)
                return text

        if len(tag_list) == 0:
            for token in doc:
                pos_dict[token.text] = token.pos_

        if len(pos_dict) == 0:
            return np.nan

        return pos_dict

    def _get_ner(self, text: str, model: str, drop_entities: bool) -> dict:
        """Identifies named entities (Named Entity Recognition - NER) in a given text.

        Parameters
        ----------
        text : string
            Sentence or conversation block

        model : string
            Package(model) to use for NER. Can be either "spacy" or "nltk"
        drop_entities: bool
            If set to true the entities will be dropped from text.

        Returns
        -------
        dict
            dictionary of words and their corresponding NER tag pairs
        """
        entity_dict = {}
        if model == "spacy":
            doc = self.nlp(text)
            for ent in doc.ents:
                entity_dict[ent.text] = ent.label_

        if model == "nltk":
            for token in nltk.sent_tokenize(text):
                for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(token))):
                    if hasattr(chunk, "label"):
                        entity_dict[" ".join(c[0] for c in chunk)] = chunk.label()

        if len(entity_dict) == 0:
            return np.nan

        if drop_entities:
            entity_list = []
            for k, v in entity_dict.items():
                entity_list.append(k)
            text_list = text.split()
            text = " ".join([word for word in text_list if word not in entity_list])
            return text

        return entity_dict

    @staticmethod
    def _remove_characters(text: str, char_list: list):
        for i in char_list:
            text = text.replace(i, " ").strip()
        return text

    def _get_spacy_model_version(self) -> str:
        """Returns Spacy model version loaded in :mod:`__init__` method while initializing nlp object with spacy model.

        Returns
        -------
        str
            Returns version of spacy model loaded in nlp
        """
        return self.nlp.meta["version"]

    def to_lower(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Converts text into lower case.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that is required to convert into lower case.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or DataFrame with text column containing text in lower case.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING one", "string two", "string three"]})
        >>> text_for_processing = "I am A TeSt StRing."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> lower_case_text = text_processor_object.to_lower(text = text_for_processing)
        >>> print(lower_case_text)
         'i am a test string.'

        >>> # working with DataFrame
        >>> lower_case_dataframe = text_processor_object.to_lower(col_in="text", col_out="text_lower")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

                self.df[col_out] = self.df[col_in].apply(lambda x: str.lower(x))
                self.logger.info("Converting text column to lowercase")
                return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Converting text to lowercase")
            return text.lower()

    def to_upper(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Converts text into upper case.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that is required to convert into upper case.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or DataFrame with text column containing text in upper case.

        For example:
            `"EXAMPLE OUTPUT STRING."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`
        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["string one", "string two", "string three"]})
        >>> text_for_processing = "I am A TeSt StRing."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> upper_case_text = text_processor_object.to_upper(text = text_for_processing)
        >>> print(upper_case_text)
        'I AM A TEST STRING.'

        >>> # working with DataFrame
        >>> upper_case_dataframe = text_processor_object.to_upper(col_in="text", col_out="text_upper")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(lambda x: str.upper(x))
            self.logger.info("Converting text column to uppercase.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Converting text to uppercase.")
            return text.upper()

    def remove_custom_characters(
        self, char_list: list, text=None, col_in=None, col_out=None
    ) -> Union[pd.DataFrame, str]:
        """Function to remove the characters from the text.

        Parameters
        ----------
        text : None, optional (string)

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        char_list : list[str]
            List of characters to remove from text. Example: `["@", ".@", "#", ".#", "|", "-"]`
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text after cleaning.

        For example:
            `"example output string after removing the characters."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is STRING one", "I am not string two", "you are reading string three"]})
        >>> text_for_processing = "this is an #example @string to .@remove .@desired characters from text |"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> char_list = [".@", "@", ".#", "#", "|"]
        >>> # working with string
        >>> processed_text = text_processor_object.remove_custom_characters(text = text_for_processing, char_list = char_list)
        >>> print(processed_text)
        'this is an  example  string to  remove  desired characters from text'

        >>> # working with DataFrame
        >>> df = text_processor_object.remove_custom_characters(char_list=char_list, col_in="text", col_out="cleaned_text")
        """

        if not isinstance(char_list, list):
            self.logger.error(
                "Given list of characters is not correct. - {}. Can not proceed further, "
                "requires a list of characters".format(type(char_list))
            )
            raise ValueError("Bad input given. List of characters is not a valid list.")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: self._remove_characters(text=x, char_list=char_list)
            )

            self.logger.info("Removing custom characters from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method.")

        if text:
            for i in char_list:
                text = text.replace(i, " ").strip()
            self.logger.info("Removing custom characters from text.")
            return text

    def remove_blank_space(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Removes blank spaces, tabs and lines from the given text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing blank space or lines.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`


        Raises
        ------
        ValueError
            If the argument is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING \\n one", "string \\t two", "string      three"]})
        >>> text_for_processing = "I'll     be \\n there within 5 \\t min."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_blank_space(text = text_for_processing)
        >>> print(cleaned_text)
        "I'll be there within 5 min."

        >>> # working with DataFrame
        >>> cleaned_dataframe = text_processor_object.remove_blank_space(col_in="text", col_out="cleaned_text")

        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: re.sub(r"\s+| +|\n+", " ", x).strip()
            )
            self.logger.info("Removing blank spaces/tabs/lines from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            text = re.sub(r"\s+| +|\n+", " ", text).strip()
            self.logger.info("Removing blank spaces/tabs/lines from text.")
            return text

    def remove_contraction(
        self,
        text=None,
        slang=True,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Replaces all the contractions in the sentence with expanded text (Ex: "don't" will be replaced with "do not").

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after replacing contractions with expanded text

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["It's STRING one", "you're string two", "I'll be string three"]})
        >>> text_for_processing = "I'll be there within 5 min. Shouldn't you be there too? I'd love to see u there my dear. It's awesome to meet new friends."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> expanded_text = text_processor_object.remove_contraction(text = text_for_processing)
        >>> print(expanded_text)
        'I will be there within 5 min. Should not you be there too? I would love to see you there my dear. It is awesome to meet new friends.'

        >>> # working with DataFrame
        >>> expanded_text_dataframe = text_processor_object.remove_contraction(col_in="text", col_out="cleaned_text")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(lambda x: contractions.fix(x, slang=slang))
            self.logger.info("Replacing contractions from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Replacing contractions from text.")
            return contractions.fix(text, slang=slang)

    def remove_punctuations(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Removes punctuations from a given text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
            Text data to remove following punctuation marks `[!"'(),-.:;?]`.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing punctuations.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`


        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING one.", "string-two", "string,three"]})
        >>> text_for_processing = "I'll be there within 5 min. Shouldn't you be there too? I'd love to see u there my dear. It's awesome to meet new friends."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_punctuations(text = text_for_processing)
        >>> print(cleaned_text)
        'I ll be there within 5 min Shouldn t you be there too I d love to see u there my dear It s awesome to meet new friends'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_punctuations(col_in="text", col_out="cleaned_text")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: re.sub(
                    r"\s+",
                    " ",
                    "".join(" " if c in """!"'(),-.:;?""" else c for c in x),
                ).strip()
            )
            self.logger.info("Removing punctuations from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            text = str(text)
            text = "".join(" " if c in """!"'(),-.:;?""" else c for c in text)
            text = re.sub(r"\s+", " ", text).strip()
            self.logger.info("Removing punctuations from text.")
            return text

    def replace_special_punctuation(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Replaces the special punctuation (‘, ’, “, ”) in text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after replacing special punctuations.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2], 'text': ["‘STRING one’", "“string two”"]})
        >>> text_for_processing = "‘I'll be there within 5 min. Shouldn't you be there too?’ “go beyond a privacy policy make sure it's clear how your customer data is being collected.”"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.replace_special_punctuation(text = text_for_processing)
        >>> print(cleaned_text)
        '\'I\'ll be there within 5 min. Shouldn\'t you be there too?\' "go beyond a privacy policy make sure it\'s clear how your customer data is being collected."'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.replace_special_punctuation(col_in="text", col_out="cleaned_text")
        """

        rep_dict = {"‘": "'", "’": "'", "“": '"', "”": '"'}
        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].replace(rep_dict, regex=True)
            self.logger.info("Replacing special punctuation characters from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            for pun, char in rep_dict.items():
                text = text.replace(pun, char)
            self.logger.info("Replacing special punctuation characters.")
            return text

    def add_punctuation(
        self,
        punc_path: str,
        text=None,
        col_in=None,
        col_out=None,
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, str]:
        """Adds punctuation marks to a stream of text without punctuation marks to the sentence.
        Make sure to have the punctuator model stored in the directory.

        For more information visit https://github.com/ottokart/punctuator2

        Parameters
        ----------
        text : None, optional (string)
            Raw text in which punctuation should be inserted.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        punc_path: str
            Location of the punctuator model with name. ex.: "folder/INTERSPEECH-T-BRNN.pcl"
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | str
            Text or text column after restoring punctuations.

        For example:
            `"test output string. with punctuation added!"`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid
        LookupError
            If unable to find punctuator model

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is an example string which contains punctuations marks", "string two", "string three"]})
        >>> text_for_processing = "hey I am a string I don't have all the punctuation marks could you please add some punctuation marks to me"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> # working with string
        >>> processed_text = text_processor_object.add_punctuation(text = text_for_processing, punc_path = path/to/punctuator_model.pcl)
        >>> print(processed_text)
        "Hey, I am a string I don't have all the punctuation marks? Could you please? Add some punctuation marks to me."

        >>> # working with DataFrame
        >>> punctuated_dataframe = text_processor_object.add_punctuation(col_in="text", col_out="punctuated_text")
        """

        # (TODO: To discuss how to handle this)
        # ( TODO: for later: We also need to make sure and put some blocker that user doesn't run both remove_punctuations and add_punctuations)
        if not os.path.isdir(re.sub("INTERSPEECH-T-BRNN.pcl", "", punc_path)):
            self.logger.error(
                "Directory location for punctuator model is incorrect - {}. Can not proceed further, "
                "Requires a valid directory.".format(
                    re.sub("INTERSPEECH-T-BRNN.pcl", "", punc_path)
                )
            )
            raise ValueError(f"{punc_path} is not a valid directory")

        if "INTERSPEECH-T-BRNN.pcl" not in os.listdir(
            re.sub("INTERSPEECH-T-BRNN.pcl", "", punc_path)
        ):
            self.logger.error("Punctuator model is not present in the directory provided.")
            raise LookupError("Unable to find punctuator model in the directory provided.")

        if not punc_path.endswith("INTERSPEECH-T-BRNN.pcl"):
            self.logger.error(
                "Incorrect directory location to punctuator model.: {}".format(punc_path)
            )
            raise ValueError("Incorrect directory location to punctuator model.")

        self.punc_model_path = punc_path

        if self.punc is None:
            self.punc = Punctuator(self.punc_model_path)

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            raw_punc = re.findall("[!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~]", self.df.text[0])
            if len(raw_punc) != 0:
                self.logger.warning("The input text column has some punctuation marks already!")

            if not parallel_process:
                self.df[col_out] = self.df[col_in].apply(lambda x: self.punc.punctuate(x))

            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of processors is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of processors is of incorrect type.")
                self.df[col_out] = parallelize(
                    self.df[col_in], lambda x: self.punc.punctuate(x), n_jobs=n_jobs
                )
            self.logger.info("adding punctuation to text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            raw_punc = re.findall("[!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~]", text)
            if len(raw_punc) != 0:
                self.logger.warning("The input string has some punctuation marks already!")
            self.logger.info("adding punctuation to text.")
            return self.punc.punctuate(text)

    # TODO: Add replace misc characters where you pass in regex and replace it with replacement text or character.

    def remove_misc_characters(
        self,
        text=None,
        char_list="""[-:;#$%&*+/<=>@[\]("')'^_`{|}~]""",
        col_in=None,
        col_out=None,
        replace_with_space=True,
    ) -> Union[pd.DataFrame, str]:
        """Removes the miscellaneous characters `[-:;#$%&*+/<=>@[\]("')'^_`{|}~]` from text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.
            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        char_list : string (regex pattern)
            Regular expression pattern.
            provide the characters as a regular expression pattern
            for example, if `"("`,  `")"`, `"["`, `"]"` need to be removed, pass ``char_list="[()[]]"``.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        replace_with_space : Bool, Optional
            whether to replace special characters with spaces or not.

        Returns
        -------
        DataFrame | str
            Text or text column after removing the miscellaneous characters

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING<> one", "string/ two", "string~ three"]})
        >>> text_for_processing = "I'll be there within 5 min. Shouldn't you be there too? I'd love to see u there my dear."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_misc_characters(text = text_for_processing)
        >>> print(cleaned_text)
        'I ll be there within 5 min. Shouldn t you be there too? I d love to see u there my dear.'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_misc_characters(col_in="text", col_out="cleaned_text")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if replace_with_space:
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: re.sub(str(char_list), " ", x).strip()
                )

            if not replace_with_space:
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: re.sub(str(char_list), "", x).strip()
                )

            self.logger.info("Removing Misclleneous characters from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            if replace_with_space:
                text = re.sub(str(char_list), " ", text).strip()

            if not replace_with_space:
                text = re.sub(str(char_list), "", text).strip()

            self.logger.info("Removing Misclleneous characters from text.")
            return text

    def _spell_known(self, words: List[str]) -> Set[str]:
        """
        The subset of `words` that appear in the dictionary of words.
        This function is a modification of SpellChecker.known function to allow case sensitive returns
        """
        tmp_words = [ensure_unicode(w) for w in words]
        tmp = [w.lower() for w in tmp_words]
        return {
            orig_w
            for orig_w, w in zip(words, tmp)
            if w in self.spellChecker._word_frequency.dictionary
            and self.spellChecker._check_if_should_check(w)
        }

    def _correct_repeating_chars_from_text(self, text: str) -> str:
        """Correct text containing unnecessary repeating characters like: ("helllooo" to "hello").

        Parameters
        ----------
        text : str
            Raw text that needs to be corrected from repeating characters.


        Returns
        -------
        str
            Text containing corrected words
        """
        # Split text to get list of words, punctuations and whitespace
        list_of_words_punc = re.findall(r"\w+|[^\w]+", text)
        # Get a list of misspelled words in the above list
        misspelled_words = self.spellChecker.unknown(list_of_words_punc)
        # List to store final corrected words
        final_words_list = []
        for word in list_of_words_punc:
            # If word has letters or numbers and is misspelled
            if word.isalnum() and word.lower() in misspelled_words:
                # Stores list of lists containing characters
                # For example for the word "hellloo"
                # char_list will have [["h"], ["e"], ["l", "ll", "lll"], ["o", "oo"]]
                # This is to get all permutations possible while not omitting any character
                char_list = []
                for _, group in itertools.groupby(word):
                    list_group = list(group)
                    char_list.append(
                        [char + list_group[0] * idx for idx, char in enumerate(list_group)]
                    )
                # Get all possible permutations
                word_perms = list(itertools.product(*char_list))
                # Join into list of words
                word_perms = ["".join(word_perm) for word_perm in word_perms]

                # Return set of words that are spelled correctly, it is case sensitive
                correct_words = self._spell_known(word_perms)
                if correct_words == set():
                    # If no correct word is found, append original word
                    final_words_list.append(word)
                    # Removes all extra characters
                    # final_words_list.append(''.join(c[0] for c in itertools.groupby(word)))
                else:
                    # If correct word is found
                    # Last item from set is returned
                    final_words_list.append(next(iter(correct_words)))

            else:
                # If there is nothing wrong with the spelling
                # Append original word
                final_words_list.append(word)
        return "".join(final_words_list).strip()

    def correct_repeating_chars(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """For a text or dataframe, correct text containing unnecessary repeating characters like: ("helllooo" to "hello").

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after correcting repeating characters.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRINGGGGG one", "ssssstring two", "string threeeeee"]})
        >>> text_for_processing = "heyyyyyyy I'm a stringggg I have some repeaaaaaaaating characters. Please fixxxxxxxx me!"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> processed_text = text_processor_object.correct_repeating_chars(text = text_for_processing)
        >>> print(processed_text)
        "hey I'm a string I have some repeating characters. Please fix me!"

        >>> # working with DataFrame
        >>> processed_text_dataframe = text_processor_object.correct_repeating_chars(col_in="text", col_out="cleaned_text")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: self._correct_repeating_chars_from_text(x)
            )

            self.logger.info("Correcting words with repeating characters from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Correcting words with repeating characters from text.")
            # return re.sub(r"(.)\1+", r"\1\1", text)
            return self._correct_repeating_chars_from_text(text)

    def remove_numbers(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Removes all numbers (numeric occurrences) from the given text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing numbers.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["S1T2R3I54NG o24ne","st54ri76ng t87wo", "st435rin234g t65422hr48768ee"]})
        >>> text_for_processing = "He234y, I52 a56m a 1 t222es6565t st3452ring2346, pl2346ease re2346move t2345he nu2345mbers."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_numbers(text = text_for_processing)
        >>> print(cleaned_text)
        'Hey, I am a  test string, please remove the numbers.'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_numbers(col_in="text", col_out="cleaned_text")
        """
        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(lambda x: re.sub(r"[0-9]+", "", x).strip())
            self.logger.info("Removing numbers from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Removing numbers from text.")
            return re.sub(r"[0-9]+", "", text).strip()

    def replace_HTML_entities(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Replaces HTML entities names ("&amp;", "&lt;", "&gt;", "â€™") with respective symbols.

        For more information please visit https://www.freeformatter.com/html-entities.html

        Parameters
        ----------
        text : None, optional (string)
            Text from which HTML entity names need to be replaced.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after replacement.

        For example:
            `"< example output string. >"`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING &amp; one", "&lt; string two &gt;", "string &amp; threeâ€™"]})
        >>> text_for_processing = " &lt; this is a string &amp; with HTML entities &gt; ."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.replace_HTML_entities(text = text_for_processing)
        >>> print(cleaned_text)
        ' < this is a string & with HTML entities > .'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.replace_HTML_entities(col_in="cleaned_text", col_out="cleaned_text")
        """
        ent_dict = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "â€™": "'"}
        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].replace(ent_dict, regex=True)
            self.logger.info("Replacing html entities from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            for ent, char in ent_dict.items():
                text = text.replace(ent, char)
            self.logger.info("Replacing html entities.")
            return text

    def remove_nonASCII_characters(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Remove Non-ASCII Characters from the input text.

        For more information, please visit  https://rbutterworth.nfshost.com/Tables/compose/

        Parameters
        ----------
        text : None, optional (string)
            Text data to remove Non-ASCII Characters.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing Non-ASCII Characters.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING one", "string two", "string three"]})
        >>> text_for_processing = "‘Announcement: ¡john Launches New £Data Insights Report, Providing #drinks"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_nonASCII_characters(text = text_for_processing)
        >>> print(cleaned_text)
        'Announcement:  john Launches New  Data Insights Report, Providing #drinks'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_nonASCII_characters(col_in="cleaned_text", col_out="cleaned_text")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = (
                self.df[col_in]
                .str.encode("ascii", "replace")
                .str.decode("ascii")
                .str.replace("?", " ", regex=False)
                .str.strip()
            )
            self.logger.info("Removing non ASCII characters from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            encoded_string = text.encode("ascii", "replace")
            decode_string = encoded_string.decode()
            decode_string = decode_string.replace("?", " ").strip()
            self.logger.info("Removing non ASCII characters from text.")
            return decode_string

    def remove_short_word(
        self, text=None, col_in=None, col_out=None, len_min_wrd=3, words_to_keep=list()
    ) -> Union[pd.DataFrame, str]:
        """Remove short words (length less than :attr:`len_min_wrd`) except words entered in the :attr:`words_to_keep` from the given text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        len_min_wrd : int, optional
            Min length of the word to not consider it as shortword (words having a length less than n are considered as short words), by default 3
        words_to_keep : list, optional
            List of words which are short but want to keep, by default []

        Returns
        -------
        DataFrame | str
            Text or text column after removing short words.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING on", "string two", "string three"]})
        >>> text_for_processing = "this is not a simple text string, this will be used as an example text string."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_short_word(text = text_for_processing, len_min_wrd=4, words_to_keep=["no", "not", "our"])
        >>> print(cleaned_text)
        'this not simple text string, this will used example text string.'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_short_word(col_in="text", col_out="cleaned_text", words_to_keep=["no", "not"])
        """
        if len_min_wrd is None or not isinstance(len_min_wrd, int):
            self.logger.error(
                "Input number is of incorrect type - {}. Can not proceed further, "
                "Requires an input integer".format(type(len_min_wrd))
            )
            raise ValueError("Input n is not set or incorrect type in this method")
        if not isinstance(words_to_keep, list):
            self.logger.error(
                "Given words to keep are not a valid array in the input list - {}. Can not proceed further.".format(
                    words_to_keep
                )
            )
            raise ValueError("Bad ip. Given custom words to keep is not a valid array.")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: " ".join(
                    word
                    for word in x.split()
                    if (len(word) > len_min_wrd - 1) or (word in words_to_keep)
                )
            )
            self.logger.info("Removing short words from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Removing short words from text.")
            return " ".join(
                word
                for word in text.split()
                if (len(word) > len_min_wrd - 1) or (word in words_to_keep)
            )

    def remove_unmeaningful_words(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Remove unmeaningful words from the input text.

        Words that are not in the nltk corpus are considered unmeaningful words.

        Parameters
        ----------
        text : None, optional (string)
            Text data to remove unmeaningful words.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing unmeaningful words.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is STRING one of sample dataframe", "I am string two within the sample dataframe", "you are reading sample text in example dataframe"]})
        >>> text_for_processing = "Announcement: An organization Launches New #Data Insights Report, Providing #Alcohol Brands With Consumer… https://t.co/link"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_unmeaningful_words(text = text_for_processing)
        >>> print(cleaned_text)
        'Announcement : An organization New # Data Report , Providing # Alcohol With Consumer … :// t . / link'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_unmeaningful_words(col_in="text", col_out="cleaned_text")
        """

        nltk_words = set(nltk.corpus.words.words())

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(
                lambda x: " ".join(
                    w
                    for w in nltk.wordpunct_tokenize(x)
                    if w.lower() in nltk_words or not w.isalpha()
                )
            )
            self.logger.info("Removing unmeaningful words from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Removing unmeaningful words from text.")
            return " ".join(
                w
                for w in nltk.wordpunct_tokenize(text)
                if w.lower() in nltk_words or not w.isalpha()
            )

    def remove_empty_stems(self, input_text: pd.DataFrame, data_words: list) -> pd.DataFrame:
        """Remove empty space words from the input text for clustering model data prep

        Parameters
        ----------
        input_text : pd.DataFrame
            pd.DataFrame containing input sentences. The length of input_text and data_words should be the same.

            For example::

                index  text
                0      this is a datawords sample
                1      this is one more
                2

        data_words : list
            list of tokenized sentences generated using input_text
            For example: :attr:`[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"], []]`

        Returns
        -------
        pd.DataFrame
            Updated input_text (input_text after removing empty stems/space)

            For example::

                index  text
                0      this is a datawords sample
                1      this is one more

        list
            Updated data_words (data_words after removing empty stems/space)
            For example: :attr:`[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]`

        Raises
        ------
        ValueError
            If any of the arguments is missing or invalid.
        """
        if not isinstance(input_text, pd.DataFrame):
            self.logger.error(
                "Given text array is not a valid array in the input list. - {}. Can not proceed further, "
                "requires a list".format(type(input_text))
            )
            raise ValueError("Bad input. Given text list is not a valid array.")

        if not isinstance(data_words, list):
            self.logger.error(
                "Given text array is not a valid array in the input list. - {}. Can not proceed further, "
                "requires a list".format(type(data_words))
            )
            raise ValueError("Bad input. Given text list is not a valid array.")

        count = 0
        index_to_remove = []
        for i in data_words:
            if not i:
                index_to_remove.append(count)
            count = count + 1
        data_words = [ele for ele in data_words if ele != []]
        input_text = input_text.drop(index_to_remove).reset_index(drop=True)

        return input_text, data_words

    def extract_mentions(
        self,
        mention_handler: str,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str, list]:
        """Extract `@mentions` (tags) from input text and perform `("get_name"/ "remove"/ "unalter")` operation according to `handler` parameter.

        Parameters
        ----------
        text : None, optional (string)
            text containing `@mentions`

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        mention_handler : string
            Can be either `"get_name"/ "remove"/ "unalter"`
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str | list

        For example:
            `['mention_1', 'mention_2', 'mention_3']`
                or

                "example output string after removing mention."

                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "mentions"]`

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["@STRING one", "string @two", "@string_three"]})
        >>> text_for_processing = "hello @user, I am an @example string to workwith @mentions"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> handles_removed_text = text_processor_object.extract_mentions(text = text_for_processing, mention_handler = "remove")
        >>> print(handles_removed_text)
        'hello , I am an  string to workwith '

        >>> # working with DataFrame
        >>> df = text_processor_object.extract_mentions(col_in="text", col_out="text", mention_handler = "remove")
        """

        if mention_handler not in ["get_name", "remove", "unalter"] or mention_handler is None:
            self.logger.error(
                "Invalid choice passed to mentions handler - {}. Can not proceed further, "
                'Expected either of ["get_name", "remove", "unalter"]'.format(mention_handler)
            )
            raise ValueError("Bad input. Wrong choice or No choice of mentions handler")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if mention_handler == "remove":
                self.df[col_out] = self.df[col_in].apply(lambda x: re.sub(r"@[\w]+", "", x))
            elif mention_handler == "get_name":
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: re.findall("@([a-zA-Z0-9]{1,15})", x)
                )
            else:  # unalter
                pass

            self.logger.info(
                "@mentions (tags) in texts are successfully extracted from text column."
            )
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            if mention_handler == "remove":
                text = re.sub(r"@[\w]+", "", text)
            elif mention_handler == "get_name":
                text = re.findall("@([a-zA-Z0-9]{1,15})", text)
            else:  # unalter
                pass
            self.logger.info("@mentions (tags) in texts are successfully extracted.")
            return text

    def extract_hashtags(
        self,
        topic_handler: str,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str, list]:
        """Extract `#hashtags` from input string and perform `("get_topic"/ "remove"/ "unalter")` operation according to `topic_handler` parameter.

        Parameters
        ----------
        text : None, optional (string)
            Text containing `#hashtags`

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        topic_handler : string
            Can be either `"get_topic"/ "remove"/ "unalter"`
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str | list

        For example:
            ['hashtag1', 'hashtag2']
                or

                "example output string after removing hashtags."

                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "hashtag"]`


        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["#STRING one", "string #two", "#string_three"]})
        >>> text_for_processing = "Heyy, I am a #string with #hashtags."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> hashtag_removed_text = text_processor_object.extract_hashtags(text = text_for_processing, topic_handler = "remove")
        >>> print(hashtag_removed_text)
        'Heyy, I am a  with .'

        >>> # working with DataFrame
        >>> df = text_processor_object.extract_hashtags(col_in="text", col_out="text", topic_handler = "remove")
        """

        if topic_handler not in ["get_topic", "remove", "unalter"] or topic_handler is None:
            self.logger.error(
                "Invalid choice passed to hashtags handler - {}. Can not proceed further, "
                'Expected either of ["get_topic", "remove", "unalter"]'.format(topic_handler)
            )
            raise ValueError("Bad input. Wrong choice or No choice of hashtags handler.")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if topic_handler == "remove":
                self.df[col_out] = self.df[col_in].apply(lambda x: re.sub(r"#[\w]+", "", x))
            elif topic_handler == "get_topic":
                self.df[col_out] = self.df[col_in].apply(lambda x: re.findall("#(\w+)", x))
            else:  # unalter
                pass
            self.logger.info("Hashtags in texts are successfully extracted from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            if topic_handler == "remove":
                text = re.sub(r"#[\w]+", "", text)
                self.logger.info("Hashtags in texts are successfully extracted.")
                return text
            elif topic_handler == "get_topic":
                hashtag = re.findall("#(\w+)", text)
                self.logger.info("Hashtags in texts are successfully extracted")
                return hashtag
            else:  # unalter
                pass
            self.logger.info("Hashtags in texts are successfully extracted")
            return text

    def extract_emojis(
        self,
        emoji_handler: str,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Extract emojis from the text.

        For more information please visit https://carpedm20.github.io/emoji/docs/api.html#emoji.replace_emoji

        Parameters
        ----------
        text : None, optional (string)
            text containing emojis.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        emoji_handler: string
            Can be either `"convert_to_text"/ "remove" / "unalter"`
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str

        For example:
            `"example output string after converting emojis to text."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`


        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["👋STRING one", "string two😎", "string 🍾 three"]})
        >>> text_for_processing = "heyy 👋, I am an example✍️ string with some emojies lets 😎 party🍾 "
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> # working with string
        >>> emojies_removed_text = text_processor_object.extract_emojis(text=text_for_processing, emoji_handler="remove")
        >>> print(emojies_removed_text)
        'heyy  , I am an example  string with some emojies lets   party  '

        >>> # working with DataFrame
        >>> df = text_processor_object.extract_emojis(col_in="text", col_out="text", emoji_handler = "remove")
        """

        if emoji_handler not in ["convert_to_text", "remove", "unalter"] or emoji_handler is None:
            self.logger.error(
                "Invalid choice passed to emoji handler - {}. Can not proceed further, "
                'Expected either of ["convert_to_text", "remove", "unalter"]'.format(emoji_handler)
            )
            raise ValueError("Bad input. Wrong choice or No choice of emoji handler.")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if emoji_handler == "remove":
                self.df[col_out] = self.df[col_in].apply(lambda x: emoji.replace_emoji(x, " "))
                self.logger.info("Emojis are extracted successfully.")
                return self.df
            elif emoji_handler == "convert_to_text":
                self.df[col_out] = self.df[col_in].apply(lambda x: emoji.demojize(x))
                self.logger.info("Emojis are extracted successfully.")
                return self.df
            else:  # This is for unaltered. No need to change anything.
                pass
            self.logger.info("Emojis are extracted successfully.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            if emoji_handler == "remove":
                text = emoji.replace_emoji(text, " ")
                self.logger.info("Emojis are extracted successfully.")
                return text
            elif emoji_handler == "convert_to_text":
                text = emoji.demojize(text)
                self.logger.info("Emojis are extracted successfully.")
                return text
            else:  # This is for unaltered. No need to change anything.
                pass
            self.logger.info("Emojis are extracted successfully.")
            return text

    def extract_hyperlinks(
        self,
        url_handler: str,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str, list]:
        """Extract `Hyperlink` from input string and perform `"get_domain"/ "remove"/ "unalter"` operation according to `url_handler` parameter.

        Parameters
        ----------
        text : None, optional (string)
            text containing `hyperlink`

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        url_handler: string
            Can be either `"get_domain"/ "remove"/ "unalter"`.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str | list

        For example:
            `['t.co', 't.co']`
                or

                "example output string after removing hyperlink."

                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "domain"]`


        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["https://t.co/linkone STRING one", "string https://t.co/linktwo two", "string_three https://t.co/linkthree"]})
        >>> text_for_processing = "rt : four lessons from running a business during the pandemic  https://t.co/linkzero written by of https://t.co/linktwo"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> urls_removed_text = text_processor_object.extract_hyperlinks(text = text_for_processing, url_handler = "remove")
        >>> print(urls_removed_text)
        'rt : four lessons from running a business during the pandemic    written by of  '

        >>> # working with DataFrame
        >>> df = text_processor_object.extract_hyperlinks(col_in="text", col_out="text", url_handler = "remove")
        """

        if url_handler not in ["get_domain", "remove", "unalter"] or url_handler is None:
            self.logger.error(
                "Invalid choice passed to hyperlinks handler - {}. Can not proceed further"
                'Expected either of ["get_domain", "remove", "unalter"]'.format(url_handler)
            )
            raise ValueError("Bad input. Wrong choice or No choice of emoji handler")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            URLPATTERN = r"(http?\://\S+|https?\://\S+|www\.\S+)"

            # Hyper link handler options logic
            if url_handler == "get_domain":
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: TextProcessor._get_domain(x, URLPATTERN)
                )
                self.logger.info("Hyperlinks are successfully extracted from text column.")
                return self.df

            elif url_handler == "remove":
                self.df[col_out] = self.df[col_in].apply(lambda x: re.sub(URLPATTERN, " ", x))
                self.logger.info("Hyperlinks are successfully extracted from text column.")
                return self.df

            else:  # unalter, no need to change anything
                pass
            self.logger.info("Hyperlinks are successfully extracted from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method.")

        if text:
            # Extract hyperlinks to new column
            URLPATTERN = r"(http?\://\S+|https?\://\S+|www\.\S+)"
            url = TextProcessor._get_domain(text, URLPATTERN)

            # Hyper link handler options logic
            if url_handler == "get_domain":
                self.logger.info("Hyperlinks in texts are successfully extracted.")
                return url

            elif url_handler == "remove":
                text = re.sub(URLPATTERN, " ", text)
                self.logger.info("Hyperlinks in texts are successfully extracted.")
                return text

            else:  # unalter, no need to change anything
                pass
            self.logger.info("Hyperlinks in texts are successfully extracted.")
            return text

    def lemmatization(
        self,
        text=None,
        col_in=None,
        col_out=None,
        lemmatizer="nltk",
        pos="n",
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, str]:
        """Does lemmatization on the input text using `lemmatizer` (can be "nltk" or "spacy").

        Parameters
        ----------
        text : None, optional (string)
            Text data to apply lemmatization.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        lemmtizer: string
            lemmatizer model, can be either "nltk" or "spacy". (default "nltk")
        pos: str optional (default: "n")
            The Part Of Speech tag. Valid options are `"n"` for nouns,
            `"v"` for verbs, `"a"` for adjectives, `"r"` for adverbs and `"s"`
            for satellite adjectives.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | str
            Text after lemmatization.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`


        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING one", "string two", "string three"]})
        >>> text_for_processing = "In 2018, Cornell researchers built a high-powered detector that, in combination with an algorithm-driven process called Ptychography"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> lemmatized_text = text_processor_object.lemmatization(text_for_processing, lemmatizer = "nltk")
        >>> print(lemmatized_text)
        'In 2018 , Cornell researcher built a high-powered detector that , in combination with an algorithm-driven process called Ptychography'

        >>> # working with DataFrame
        >>> df = text_processor_object.lemmatization(col_in="text", col_out="lemmatized_text", lemmatizer = "nltk")
        """

        if lemmatizer not in ["nltk", "spacy"]:
            self.logger.error(
                "Invalid choice for lemmatizer -{}. Can not proceed further, "
                'Expected: "nltk" or "spacy"'.format(lemmatizer)
            )
            raise ValueError("Invalid choice for lammatizer.")

        if pos not in ["n", "v", "a", "r", "s"]:
            self.logger.error(
                "Invalid choice for pos tag  -{}. Can not proceed further, "
                'Expected: either of ["n", "v", "a", "r", "s"]'.format(pos)
            )
            raise ValueError("Invalid choice for pos tag.")

        if lemmatizer == "nltk":

            if not isinstance(pos, str):
                self.logger.error(
                    "Invalid choice for POS tag -{}. Can not proceed further, "
                    "requires a string".format(type(pos))
                )

            if not text:

                if not col_in:
                    self.logger.error(
                        "Input column name is not provided, "
                        "set parameter col_in for input column name."
                    )
                    raise ValueError("Set input column name to parameter: col_in")

                if col_in not in self.df.columns:
                    self.logger.error(
                        "Input column name is either incorrect or not present in the dataframe."
                    )
                    raise ValueError("Provide correct input column name.")

                if not col_out:
                    self.logger.error(
                        "Output column name is not provided, "
                        "set parameter col_out for output column name."
                    )
                    raise ValueError("Set output column name to parameter: col_out")

                if (col_in is not None) & (col_out is not None):
                    if not isinstance(col_in, str):
                        self.logger.error(
                            "Input column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_in))
                        )
                        raise ValueError("Input column name is of incorrect type.")

                    if not isinstance(col_out, str):
                        self.logger.error(
                            "Output column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_out))
                        )
                        raise ValueError("Output column name is of incorrect type.")

                if not parallel_process:
                    self.df[col_out] = self.df[col_in].apply(
                        lambda x: " ".join(
                            self.lm.lemmatize(word, pos=pos) for word in word_tokenize(x)
                        )
                    )
                    self.logger.info("Applying lemmatization on text column.")
                    return self.df

                if parallel_process:
                    if not isinstance(n_jobs, int):
                        self.logger.error(
                            "Number of cores is of incorrect type - {}. Can not proceed further, "
                            "requires an integer.".format(type(n_jobs))
                        )
                        raise ValueError("Number of cores is of incorrect type.")
                    self.df[col_out] = parallelize(
                        self.df[col_in],
                        lambda x: " ".join(
                            self.lm.lemmatize(word, pos=pos) for word in word_tokenize(x)
                        ),
                        n_jobs=n_jobs,
                    )
                    self.logger.info("Applying lemmatization on text column.")
                    return self.df

            if not isinstance(text, str):
                self.logger.error(
                    "Input text is of incorrect type - {}. Can not proceed further, "
                    "Requires an input string".format(type(text))
                )
                raise ValueError("Input text is not set or incorrect type in this method")

            if text:
                words = word_tokenize(text)
                words = [self.lm.lemmatize(word, pos=pos) for word in words]
                text = " ".join(words)
                self.logger.info("Applying lemmatization on text.")
                return text

        if lemmatizer == "spacy":
            if not text:

                if not col_in:
                    self.logger.error(
                        "Input column name is not provided, "
                        "set parameter col_in for input column name."
                    )
                    raise ValueError("Set input column name to parameter: col_in")

                if col_in not in self.df.columns:
                    self.logger.error(
                        "Input column name is either incorrect or not present in the dataframe."
                    )
                    raise ValueError("Provide correct input column name.")

                if not col_out:
                    self.logger.error(
                        "Output column name is not provided, "
                        "set parameter col_out for output column name."
                    )
                    raise ValueError("Set output column name to parameter: col_out")

                if (col_in is not None) & (col_out is not None):
                    if not isinstance(col_in, str):
                        self.logger.error(
                            "Input column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_in))
                        )
                        raise ValueError("Input column name is of incorrect type.")

                    if not isinstance(col_out, str):
                        self.logger.error(
                            "Output column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_out))
                        )
                        raise ValueError("Output column name is of incorrect type.")

                if not parallel_process:
                    self.df[col_out] = self.df[col_in].apply(
                        lambda x: " ".join([token.lemma_ for token in self.nlp(x)])
                    )
                    self.logger.info("Applying lemmatization on text column.")
                    return self.df

                if parallel_process:
                    if not isinstance(n_jobs, int):
                        self.logger.error(
                            "Number of cores is of incorrect type - {}. Can not proceed further, "
                            "requires an integer.".format(type(n_jobs))
                        )
                        raise ValueError("Number of cores is of incorrect type.")

                    texts = self.df[col_in]
                    list_out = []
                    for doc in self.nlp.pipe(texts, n_process=n_jobs):
                        text_lemma = []
                        for token in doc:
                            text_lemma.append(token.lemma_)
                        list_out.append(" ".join(text_lemma))
                    self.df[col_out] = list_out
                    self.logger.info("Applying lemmatization on text column.")
                    return self.df

            if not isinstance(text, str):
                self.logger.error(
                    "Input text is of incorrect type - {}. Can not proceed further, "
                    "Requires an input string".format(type(text))
                )
                raise ValueError("Input text is not set or incorrect type in this method")

            if text:
                self.logger.info("Applying lemmatization on text.")
                return " ".join([token.lemma_ for token in self.nlp(text)])

    def remove_stopwords(
        self,
        text=None,
        col_in=None,
        col_out=None,
        stop_word_handler="remove",
        stop_words=list(),
        words_to_keep=list(),
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, str]:
        """Removes the stopwords from a given text.
        The user-defined stopwords :attr:`stop_words` will be appended to the default list of `nltk stopwords`.

        Parameters
        ----------
        text : None, optional (string)
            Text data to remove stopwords.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        stop_words : list, optional
            List of additional stopwords to remove, by default list()
        stop_word_handler: can be either "remove" or "get_list".
        words_to_keep : list, optional
            List of stopwords to keep, by default list()
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | str
            Text after removing stopwords.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            If any of the arguments is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is STRING one", "I am not string two", "you are reading string three"]})
        >>> text_for_processing = "In 2018, Cornell researchers built a high-powered detector that, in combination with an algorithm-driven process called Ptychography"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> stopwords_removed_text = text_processor_object.remove_stopwords(text = text_for_processing, stop_words = ["no", "not"])
        >>> print(stopwords_removed_text)
        'In 2018, Cornell researchers built high-powered detector that, combination algorithm-driven process called Ptychography'

        >>> # working with DataFrame
        >>> df = text_processor_object.remove_stopwords(col_in="text", col_out="cleaned_text", stop_words = ["no", "not"])
        """

        if not isinstance(stop_words, list):
            self.logger.error(
                "Given stopwords are not a valid array in the input list {} . Can not proceed further".format(
                    stop_words
                )
            )
            raise ValueError("Bad input. Given custom stopwords is not a valid array.")

        stpwords = stopwords.words("english")
        if len(stop_words) != 0:
            stpwords.extend(stop_words)

        if len(words_to_keep) != 0:
            for i in words_to_keep:
                if i in stpwords:
                    stpwords.remove(i)

        if stop_word_handler not in ["remove", "get_list"]:
            self.logger.error(
                "Incorrect choice of handler for stopwords- {}. Can not proceed further, "
                'Requires either `"remove"` or `"get_list"`'.format(stop_word_handler)
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if stop_word_handler == "get_list":
            sw_list = stopwords.words("english")
            return sw_list

        if stop_word_handler == "remove":
            if not text:

                if not col_in:
                    self.logger.error(
                        "Input column name is not provided, "
                        "set parameter col_in for input column name."
                    )
                    raise ValueError("Set input column name to parameter: col_in")

                if col_in not in self.df.columns:
                    self.logger.error(
                        "Input column name is either incorrect or not present in the dataframe."
                    )
                    raise ValueError("Provide correct input column name.")

                if not col_out:
                    self.logger.error(
                        "Output column name is not provided, "
                        "set parameter col_out for output column name."
                    )
                    raise ValueError("Set output column name to parameter: col_out")

                if (col_in is not None) & (col_out is not None):
                    if not isinstance(col_in, str):
                        self.logger.error(
                            "Input column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_in))
                        )
                        raise ValueError("Input column name is of incorrect type.")

                    if not isinstance(col_out, str):
                        self.logger.error(
                            "Output column name is of incorrect type - {}. Can not proceed further, "
                            "requires a string".format(type(col_out))
                        )
                        raise ValueError("Output column name is of incorrect type.")

                if not parallel_process:
                    self.df[col_out] = self.df[col_in].apply(
                        lambda x: " ".join(
                            [word for word in str(x).split() if word not in stpwords]
                        )
                    )
                if parallel_process:
                    if not isinstance(n_jobs, int):
                        self.logger.error(
                            "Number of cores is of incorrect type - {}. Can not proceed further, "
                            "requires an integer.".format(type(n_jobs))
                        )
                        raise ValueError("Number of cores is of incorrect type.")

                    self.df[col_out] = parallelize(
                        self.df[col_in],
                        lambda x: " ".join(
                            [word for word in str(x).split() if word not in stpwords]
                        ),
                        n_jobs=n_jobs,
                    )
                self.logger.info("Removing stopwords from text column.")
                return self.df

            if not isinstance(text, str):
                self.logger.error(
                    "Input text is of incorrect type - {}. Can not proceed further, "
                    "Requires an input string".format(type(text))
                )
                raise ValueError("Input text is not set or incorrect type in this method")

            if text:
                text = " ".join([word for word in str(text).split() if word not in stpwords])
                self.logger.info("Removing stopwords from text.")
                return text

    def stemming(
        self, text=None, col_in=None, col_out=None, parallel_process=False, n_jobs=-1
    ) -> Union[pd.DataFrame, str]:
        """Implement Stemming on the input text.

        Parameters
        ----------
        text : None, optional (string)
            Text data to apply stemming.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | str
            Text after stemming.

        For example:
            `"example output string."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is STRING one", "I am not string two", "you are reading string three"]})
        >>> text_for_processing = "In 2018, Cornell researchers built a high-powered detector that, in combination with an algorithm-driven process called Ptychography"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> stemmed_text = text_processor_object.stemming(text = text_for_processing)
        >>> print(stemmed_text)
        'in 2018 , cornel research built a high-pow detector that , in combin with an algorithm-driven process call ptychographi'

        >>> # working with DataFrame
        >>> df = text_processor_object.stemming(col_in="text", col_out="stemmed_text",)
        """
        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if not parallel_process:
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: " ".join([self.st.stem(word) for word in word_tokenize(x)])
                )
            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of cores is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of cores is of incorrect type.")

                self.df[col_out] = parallelize(
                    self.df[col_in],
                    lambda x: " ".join([self.st.stem(word) for word in word_tokenize(x)]),
                    n_jobs=n_jobs,
                )

            self.logger.info("Applying stemming on text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            words = word_tokenize(text)
            words = [self.st.stem(word) for word in words]
            text_out = " ".join(words)
            self.logger.info("Applying stemming on text.")
            return text_out

    def sentence_to_words(self, sentences: list):
        """Converts given sentences to the list of words.

        Parameters
        ----------
        sentences : list
            List of sentences to convert in words

        Yields
        ------
        Generator
            An iterator over list of words

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["STRING one.", "string-two", "string,three"]})
        >>> sentences = ["four lesson running business pandemic written", "latest pandemic transformed company biggest takeaway share", "no understating impacted traditional practice way felt"]
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> data_words = list(text_processor_object.sentence_to_words(sentences))
        """

        if not isinstance(sentences, list):
            self.logger.error(
                "Given sentence list is not a valid array in the input- {}. Can not proceed further, "
                "requires a list of string".format(type(sentences))
            )
            raise ValueError("Bad input. Given text list is not a valid list.")

        for sentence in sentences:
            # deacc=True removes punctuations
            yield (gensim.utils.simple_preprocess(str(sentence), deacc=True, max_len=25))

    def get_tokens(
        self,
        text=None,
        col_in=None,
        col_out=None,
        tokenizer="spacy",
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, list]:
        """Creates a list of tokens for the given text.

        Parameters
        ----------
        text : None, optional (string)
            text to generate tokens.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        tokenizer : str
            can be either `"nltk"` or `"spacy"`, default: "spacy"
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | list

        For example:
            `['four', 'lesson', 'running', 'business', 'pandemic', 'written', 'latest']`
                or

                dataframe with the following columns:

                    :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "tokens"]`

        Raises
        ------
        ValueError
            If any of the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["this is STRING one", "I am not string two", "you are reading string three"]})
        >>> sentence = "example string to show usecase of get_tokens method"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> tokens = text_processor_object.get_tokens(text = sentence, tokenizer = "spacy")
        >>> print(tokens)
        ['example', 'string', 'to', 'show', 'usecase', 'of', 'get_tokens', 'method']

        >>> # working with DataFrame
        >>> df = text_processor_object.get_tokens(col_in="text", col_out="tokens",tokenizer = "spacy")
        """

        if tokenizer not in ["nltk", "spacy"]:
            self.logger.error(
                "Invalid choice passed to tokenizer - {}. Can not proceed further,"
                'Expected either `"nltk"` or `"spacy"`'.format(tokenizer)
            )
            raise ValueError("Bad input. Wrong choice of tokenizer")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if not parallel_process:
                if tokenizer == "nltk":
                    self.df[col_out] = self.df[col_in].apply(lambda x: word_tokenize(x))
                    self.logger.info("Tokens for text column are successfully generated.")
                    return self.df

                if tokenizer == "spacy":
                    self.df[col_out] = self.df[col_in].apply(
                        lambda x: [tok.text for tok in self.nlp(x)]
                    )
                    self.logger.info("Tokens for text column are successfully generated.")
                    return self.df

            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of cores is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of cores is of incorrect type.")
                if tokenizer == "nltk":
                    self.df[col_out] = parallelize(
                        self.df[col_in], lambda x: word_tokenize(x), n_jobs=n_jobs
                    )
                    self.logger.info("Tokens are successfully generated.")
                    return self.df

                if tokenizer == "spacy":
                    texts = self.df[col_in]
                    list_out = []
                    for doc in self.nlp.pipe(texts, n_process=n_jobs):
                        tokens = []
                        for token in doc:
                            tokens.append(token.text)
                        list_out.append(tokens)
                    self.df[col_out] = list_out
                    return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            if tokenizer == "nltk":
                tokens = word_tokenize(text)

            if tokenizer == "spacy":
                tokens = []
                doc = self.nlp(text)
                for token in doc:
                    tokens.append(token.text)

            self.logger.info("Tokens are successfully generated.")
            return tokens

    def NER_tag(
        self,
        text=None,
        col_in=None,
        col_out=None,
        model="spacy",
        drop_entities=False,
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, dict, str]:
        """Recognizes the words as `named entities` in a given sentence.

        Parameters
        ----------
        text : None, optional (string)
            text in which entities need to be identified.

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        model: string
            can be either `"nltk"` or `"spacy"`, default: "spacy"
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        drop_entities: bool, optional
            Optional parameter, if set to true the entities will be dropped from text. By default, False.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | dict | str
            Dictionary with words and NER tag as key-value pairs.

        For example:
            `{'European': 'GPE', 'Google': 'PERSON'}`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "NER"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid
        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> sentence = "European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> NER = text_processor_object.NER_tag(text = sentence, model = "spacy")
        >>> print(NER)
        {'European': 'NORP', 'Google a record $5.1 billion': 'ORG', 'Wednesday': 'DATE'}
        """
        if model not in ["nltk", "spacy"]:
            self.logger.error(
                "Invalid choice passed to model - {}. Can not proceed further,"
                'Expected either `"nltk"` or `"spacy"`'.format(model)
            )
            raise ValueError("Bad input. Wrong choice or No choice of model")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if not parallel_process:
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: self._get_ner(x, model, drop_entities)
                )

            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of cores is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of cores is of incorrect type.")

                if model == "nltk":
                    self.df[col_out] = parallelize(
                        self.df[col_in],
                        lambda x: self._get_ner(x, model, drop_entities),
                        n_jobs=n_jobs,
                    )
                if model == "spacy":
                    texts = self.df[col_in]
                    list_out = []
                    for doc in self.nlp.pipe(
                        texts, n_process=n_jobs, disable=["tagger", "parser"]
                    ):
                        d = {}
                        for ent in doc.ents:
                            d[ent.text] = ent.label_
                        if drop_entities:
                            entity_list = []
                            for k, v in d.items():
                                entity_list.append(k)
                            text_list = doc.text.split()
                            text = " ".join(
                                [word for word in text_list if word not in entity_list]
                            )
                            list_out.append(text)
                        else:
                            list_out.append(d)
                    self.df[col_out] = list_out

            self.logger.info("Identifying named entities from text column.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Identifying named entities from text")
            return self._get_ner(text, model, drop_entities)

    def POS_tag(
        self,
        text=None,
        col_in=None,
        col_out=None,
        tag_list=list(),
        keep_pos_only=False,
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, dict, str]:
        """Identifies each word of an input sentence as `nouns, pronouns, proper noun, verbs, adjectives, adposition, adverb, auxiliary, conjunction, determiner, interjection, numeral, particle, punctuation, subordinating conjunction, symbol, other, end of line, space`.

        Parameters
        ----------
        text : None, optional (string)

            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        tag_list : list, optional
            List of specific POS tags.
            Filters the output and returns only the words and POS tag pairs, that are passed to this parameter.
            if nothing is passed, by default the dictionary with all tags and word pairs will be returned.
            the passed list should contain any of the following:

            `["ADJ", "ADP", "ADV", "AUX", "CONJ", "DET", "INTJ", "NOUN", "NUM", "PART", "PRON", "PROPN", "PUNCT", "SCONJ", "SYM", "VERB", "X", "EOL", "SPACE"]`

            **abbreviation:** `{'ADJ': 'adjective', 'ADP': 'adposition', 'ADV': 'adverb',
            'AUX': 'auxiliary', 'CONJ': 'conjunction', 'DET': 'determiner', 'INTJ': 'interjection',
            'NOUN': 'noun', 'NUM': 'numeral', 'PART': 'particle', 'PRON': 'pronoun',
            'PROPN': 'proper noun', 'PUNCT': 'punctuation', 'SCONJ': 'subordinating conjunction',
            'SYM': 'symbol', 'VERB': 'verb', 'X': 'other', 'EOL': 'end of line', 'SPACE': 'space'}`
        keep_pos_only: bool, optional
            If true, then function would return the text with desired POS tags only. By default, False.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | dict | str

        For example:
            `{'European': 'ADJ', 'authorities': 'NOUN', 'fined': 'VERB', 'record': 'NOUN', 'abusing': 'VERB', 'power': 'NOUN'}`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "POS Tag"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> sentence = "European authorities fined Google a record $5.1 billion on Wednesday for abusing its power in the mobile phone market and ordered the company to alter its practices"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> POS = text_processor_object.POS_tag(text = sentence, tag_list = ["ADJ", "ADP", "ADV"])
        >>> print(POS)
        {'European': 'ADJ', 'for': 'ADP', 'in': 'ADP', 'mobile': 'ADJ', 'on': 'ADP'}
        """
        if not isinstance(tag_list, list):
            self.logger.error(
                "Given sentence list is not a valid array in the input. - {}. Can not proceed further, "
                "requires a list of string".format(type(tag_list))
            )
            raise ValueError("Bad ip. Given POS tag is not a valid list.")

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if not parallel_process:
                self.df[col_out] = self.df[col_in].apply(
                    lambda x: self._get_pos(text=x, keep_pos_only=keep_pos_only, tag_list=tag_list)
                )

            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of cores is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of cores is of incorrect type.")

                texts = self.df[col_in]
                list_out = []
                for doc in self.nlp.pipe(texts, n_process=n_jobs):
                    d = {}
                    for tok in doc:
                        if tok.pos_ in tag_list:
                            d[tok.text] = tok.pos_
                    if keep_pos_only:
                        pos_list = []
                        for k, v in d.items():
                            pos_list.append(k)
                        text = " ".join(pos_list)
                        list_out.append(text)
                    else:
                        list_out.append(d)
                self.df[col_out] = list_out

            self.logger.info("Generating Parts Of Speech tags.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Generating Parts Of Speech tags.")
            return self._get_pos(text=text, keep_pos_only=keep_pos_only, tag_list=tag_list)

    def remove_duplicate_words(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Removes all duplicate words from the given text.

        Parameters
        ----------
        text : None, optional (string)
            Raw text that needs to be cleaned.
            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str
            Text or text column after removing duplicate words.


        For example:
            `"string after processing."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text", "POS Tag"]`

        Raises
        ------
        ValueError
            If the argument is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["string one string one","string string two two", "string three"]})
        >>> text_for_processing = "test test string to test the funtion to remove duplicate words from a string"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level = "INFO")
        >>> # working with string
        >>> cleaned_text = text_processor_object.remove_duplicate_words(text = text_for_processing)
        >>> print(cleaned_text)
        'test string to the funtion remove duplicate words from a'

        >>> # working with DataFrame
        >>> cleaned_text_dataframe = text_processor_object.remove_duplicate_words(col_in="text", col_out="cleaned_text")
        """

        if not text:
            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            self.df[col_out] = self.df[col_in].apply(lambda x: " ".join(dict.fromkeys(x.split())))
            self.logger.info("Removing duplicate words from given texts")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Removing duplicate words from given text.")
            return " ".join(dict.fromkeys(text.split()))

    def _truecasing(self, text) -> str:
        """
        Convert the words of a sentence to truecase/Camelcase.

        Parameter
        ---------
        text: str
            input text/sentence.

        Return
        ------
        str
            text/sentence after converting to truecasing.

        """

        # tokenize the text into words
        words = nltk.word_tokenize(text)

        # apply POS-tagging on words
        tagged_words = nltk.pos_tag([word.lower() for word in words])

        # apply capitalization based on POS tags
        capitalized_words = [
            w.capitalize() if t in ["NN", "NNS"] else w for (w, t) in tagged_words
        ]

        word_list = []
        # reset the truecasing for entities and non-entities
        for token in nltk.sent_tokenize(" ".join(capitalized_words)):
            for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(token))):
                if not hasattr(chunk, "label"):
                    word_list.append(chunk[0].lower())
                if hasattr(chunk, "label"):
                    for x in chunk:
                        word_list.append(x[0])

        # capitalize first word in sentence
        word_list[0] = word_list[0].capitalize()

        # join capitalized wordstrue
        text_truecase = re.sub(" (?=[\.,'!?:;])", "", " ".join(word_list))
        return text_truecase

    def make_truecase(
        self,
        text=None,
        col_in=None,
        col_out=None,
        parallel_process=False,
        n_jobs=-1,
    ) -> Union[pd.DataFrame, str]:
        """
        Convert the words of a sentence to truecase/Camelcase.

            `"meet my friend john." -> "Meet my Friend John."`

        Parameters
        ----------
        text : None, optional (string)
            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.
        parallel_process: False, optional (bool)
            Wether to use parallel processing, by default False.
        n_jobs : -1, optional (int)
            Number of cores to use in parallel processing. By default, -1 (all processesors)

        Returns
        -------
        DataFrame | str

        For example:
            `"Meet my Friend John."`
                or

                dataframe with the following columns:

                :attr:`["id", "conv_b_num", "speaker", "speaker_source", "text", "start_time", "end_time,"confidence_score", "processed_text"]`
        Raises
        ------
        ValueError
            If the argument is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["country", "i live in india", "i will go to europe"]})
        >>> text_for_processing = "i live in india"
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> # working with string
        >>> true_case_text = text_processor_object.make_truecase(text = text_for_processing)
        >>> print(True_case_text)
        'I live in India'

        >>> # working with DataFrame
        >>> true_case_dataframe = text_processor_object.make_truecase(col_in="text", col_out="text_truecase")
        """

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            if (col_in is not None) & (col_out is not None):
                if not isinstance(col_in, str):
                    self.logger.error(
                        "Input column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_in))
                    )
                    raise ValueError("Input column name is of incorrect type.")

                if not isinstance(col_out, str):
                    self.logger.error(
                        "Output column name is of incorrect type - {}. Can not proceed further, "
                        "Requires a string".format(type(col_out))
                    )
                    raise ValueError("Output column name is of incorrect type.")

            if not parallel_process:
                self.df[col_out] = self.df[col_in].apply(lambda x: self._truecasing(x))

            if parallel_process:
                if not isinstance(n_jobs, int):
                    self.logger.error(
                        "Number of cores is of incorrect type - {}. Can not proceed further, "
                        "requires an integer.".format(type(n_jobs))
                    )
                    raise ValueError("Number of cores is of incorrect type.")

                self.df[col_out] = parallelize(
                    self.df[col_in], lambda x: self._truecasing(x), n_jobs=n_jobs
                )

            self.logger.info("Converting text column to truecase.")
            return self.df

        if not isinstance(text, str):
            self.logger.error(
                "Input text is of incorrect type - {}. Can not proceed further, "
                "Requires an input string".format(type(text))
            )
            raise ValueError("Input text is not set or incorrect type in this method")

        if text:
            self.logger.info("Converting text to truecase.")

            text = self._truecasing(text)
            return text

    def data_process(
        self,
        text=None,
        col_in=None,
        col_out=None,
    ) -> Union[pd.DataFrame, str]:
        """Recommended approach to process the text data.

        Parameters
        ----------
        text : None, optional (string)
            If set as :const:`None`, the operation is performed on the DataFrame passed as the parameter while initializing the ``TextProcessor`` class.
        col_in : None, optional (string)
            Column name containing input text.
        col_out : None, optional (string)
            Column name for output text.

        Returns
        -------
        DataFrame | str

        For example:
            `"string after processing."`
                or

                Pandas DataFrame containing input data and processed data.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.DataFrame({'id': [1, 2, 3], 'text': ["string$ one.", "string-two", "strrring three?"]})
        >>> text = "!example $string    with @mention, #tag."
        >>> text_processor_object = TextProcessor(df = df, log_file_path = None, verbose = True, log_level="INFO")
        >>> # working with string
        >>> processed_text = text_processor_object.data_process(text=text)
        >>> print(processed_text)
        "example string"

        >>> # working with DataFrame
        >>> processed_data = text_processor_object.data_process(col_in = "text", col_out = "processed_text")
        """
        self.logger.info("Data processing using data_process started")

        words_to_keep = ["no"]

        methods = [
            ("extract_mentions", {"mention_handler": "remove"}),
            ("extract_hashtags", {"topic_handler": "remove"}),
            ("extract_hyperlinks", {"url_handler": "remove"}),
            ("extract_emojis", {"emoji_handler": "remove"}),
            ("remove_nonASCII_characters", {}),
            ("remove_contraction", {}),
            ("replace_special_punctuation", {}),
            ("replace_HTML_entities", {}),
            ("correct_repeating_chars", {}),
            ("remove_numbers", {}),
            ("remove_punctuations", {}),
            ("remove_misc_characters", {}),
            ("lemmatization", {}),
            (
                "remove_stopwords",
                {
                    "stop_word_handler": "remove",
                    "stop_words": [],
                    "words_to_keep": words_to_keep,
                },
            ),
            ("remove_blank_space", {}),
            ("to_lower", {}),
        ]

        if text:

            if not isinstance(text, str):
                self.logger.error(
                    "Input text is of incorrect type - {}. Can not proceed further, "
                    "Requires an input string".format(type(text))
                )
                raise ValueError("Input text is not set or incorrect type in this method")

            pipeline_output = self.pipeline.pipeline(
                class_module=self,
                methods=methods,
                data_parameters=[("text", text)],
                skip_errors=False,
            )
            text = pipeline_output[0][1]

            self.logger.info("Text processing using data_process completed")
            return text

        if not text:

            if not col_in:
                self.logger.error(
                    "Input column name is not provided, "
                    "set parameter col_in for input column name."
                )
                raise ValueError("Set input column name to parameter: col_in")

            if col_in not in self.df.columns:
                self.logger.error(
                    "Input column name is either incorrect or not present in the dataframe."
                )
                raise ValueError("Provide correct input column name.")

            if not col_out:
                self.logger.error(
                    "Output column name is not provided, "
                    "set parameter col_out for output column name."
                )
                raise ValueError("Set output column name to parameter: col_out")

            self.df[col_out] = self.df[col_in]
            self.df[col_out] = self.df[col_out].fillna("")

            self.pipeline.pipeline(
                class_module=self,
                methods=methods,
                skip_errors=False,
                col_in=col_out,
                col_out=col_out,
            )

            self.df = self.df[self.df[col_out] != ""]
            self.df = self.df.drop_duplicates(subset=[col_out])
            self.logger.info("Data processing using data_process completed")
            return self.df

    def data_process_pipeline(
        self,
        methods: list,
        text=None,
        # col_in=None,
        # col_out=None,
        skip_errors=False,
        **kwargs,
    ) -> pd.DataFrame:
        """Process the text data in sequence of the methods provided as a list.

        Parameters
        ----------
        methods : List of tuple.
            List of tuples, method name as first element and the dictionary of parameters as second element of tuple.
            All methods will run in the order specified.
            If a certain method has no required parameters,
            empty dictionary can be passed and default parameters will be used when running that method.

            Note that, methods `remove_empty_stems` and `sentence_to_words` are not part of pipeline.

        skip_errors : bool, optional (False)
            If errors are to be skipped, if True will skip functions having errors and proceed.
            Will raise error if False in case function is not present or any errors during execution,
            by default False.

        Returns
        -------
        DataFrame | str

        For example:
            `"string after processing."`
                or

                Pandas DataFrame containing input data and processed data.

        Raises
        ------
        ValueError
            any of the argument is invalid or absent.
        ValueError
            Method names i.e., first element of tuple passed inside methods are not string.
        ValueError
            Function parameters, second element of tuple passed inside methods are not dictionary.
        ValueError
            If a certain required parameter is not passed as function_parameters.
        ValueError
            If an error occured when running a method.

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> df = pd.read_csv('data.csv')
        >>> text_processor_object = TextProcessor(df = df, save_logs=False, log_level="INFO")

        >>> # Option 1: Pass all parameters as a dictionary for each method.
        >>> pipeline_methods = [
                ("extract_mentions", {"col_in" : "cleaned_text", "col_out" : "mentions", "mention_handler": "get_name"}),
                ("extract_hashtags", {"col_in" : "cleaned_text", "col_out" : "topics", "topic_handler": "get_topic"}),
                ("extract_hyperlinks", {"col_in" : "cleaned_text", "col_out" : "domains", "url_handler": "get_domain"}),
                ("extract_emojis", {"col_in" : "cleaned_text", "col_out" : "cleaned_text", "emoji_handler": "remove"}),
                ("remove_blank_space", {"col_in" : "cleaned_text", "col_out" : "cleaned_text"}),
                ("to_lower", {"col_in" : "cleaned_text", "col_out" : "cleaned_text"})]
        >>> processed_data = text_processor_object.data_process_pipeline(methods=pipeline_methods, skip_errors=False)

        >>> # Option 2: Pass the common parameters as kwargs.
        >>> # Pass tuple to override kwargs
        >>> pipeline_methods = [
                ("extract_mentions", {"col_in" : "text"}),
                "extract_hashtags",
                "remove_blank_space",
                "to_lower"
            ]
        >>> processed_data = text_processor_object.data_process_pipeline(
                methods=pipeline_methods,
                col_in="processed_text",
                col_out="processed_text",
                mention_handler="remove",
                topic_handler="remove",
                skip_errors=False
            )

        >>> # Option 3: Processing string with pipeline.
        >>> text = "!example $string    with @mention, #tag."
        >>> pipeline_methods=["extract_mentions", "to_lower", "remove_punctuations"]
        >>> processed_text = text_processor_object.data_process_pipeline(
                text=text,
                methods=pipeline_methods,
                mention_handler="remove"
            )
        >>> print(processed_text)
        'example $string with #tag'

        """
        self.logger.info("Data processing using data_process_pipeline started")

        if text:

            if not isinstance(text, str):
                self.logger.error(
                    "Input text is of incorrect type - {}. Can not proceed further, "
                    "Requires an input string".format(type(text))
                )
                raise ValueError("Input text is not set or incorrect type in this method")

            pipeline_output = self.pipeline.pipeline(
                class_module=self,
                methods=methods,
                data_parameters=[("text", text)],
                skip_errors=False,
                **kwargs,
            )
            text = pipeline_output[0][1]
            self.logger.info("Text processing using data_process_pipeline completed.")
            return text

        if not text:

            if ("col_in" in kwargs) & ("col_out" in kwargs):

                col_in = kwargs["col_in"]
                col_out = kwargs["col_out"]

                kwargs["col_in"] = kwargs["col_out"]

                if col_in not in self.df.columns:
                    self.logger.error(
                        "Input column name is either incorrect or not present in the dataframe."
                    )
                    raise ValueError("Provide correct input column name.")

                self.df[col_out] = self.df[col_in]
                self.df[col_out] = self.df[col_out].fillna("")

            self.pipeline.pipeline(
                class_module=self, methods=methods, skip_errors=skip_errors, **kwargs
            )

            self.logger.info("Data processing using data_process_pipeline completed.")
            return self.df


def load_json_data(filename: str) -> pd.DataFrame:
    """
    Extracts raw data from json and jsonl files and converts it into a pandas dataframe for DataParser class.

    Parameters
    ----------
    filename : str
        Filename of the json or jsonl file
    Returns
    -------
    pd.DataFrame
        Pandas dataframe of the raw data
    Raises
    ------
    ValueError
        If file is not a json or jsonl
    """
    # TODO: Add support for s3
    extension = os.path.splitext(filename)[1]
    if extension == ".json":
        with open(filename, "r", encoding="utf-8") as json_file:
            raw_data = pd.DataFrame(
                data={
                    "call_id": ["callid#1"],
                    "call_transcript": [json_file.read()],
                }
            )
    elif extension == ".jsonl":
        with open(filename, "r") as multi_call:
            calls_df = pd.DataFrame(data=None, columns=["call_id", "call_transcript"])
            for rn, line in enumerate(multi_call):
                current = pd.DataFrame(
                    data={"call_id": [f"callid#{str(rn + 1)}"], "call_transcript": [line]}
                )

                calls_df = pd.concat([calls_df, current])

        raw_data = calls_df.reset_index(drop=True)
    else:
        raise ValueError(
            f'Expected "json" or "jsonl" files. Got "{extension}" which is not supported.'
        )
    return raw_data

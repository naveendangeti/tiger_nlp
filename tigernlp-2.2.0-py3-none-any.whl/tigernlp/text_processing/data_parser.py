"""This module is for parsing the raw data to a dataframe defined by the user.
"""

import json
import numpy as np
import os
import pandas as pd
from datetime import timedelta
from typing import Union

from tigernlp.core.api import MyLogger, parallelize_row_wise


class DataParser:
    """Utility class for parsing of call and chat transcripts from various sources. When ``source=None``, this class will create a dataframe with id and text column as specified by user along with any other column that is present in ``raw_data``. If conv_b_num is not present, it will be auto-generated as per id column. Usage of ``source=None`` is not recommended in Data Parser and should only be used if there is a need in other module use cases.

    Parameters
    ----------
    raw_data: Union[str, pd.DataFrame]
        Pass the absolute path of the file that contains the raw data.

    source : str, by default None.
        Pass the source as string. Acceptable sources are ::

            "watson-chat",
            "google",
            "assembly_ai",
            "speechmatics",
            "azure",
            "revai",
            "aws",
            "ibm",
            "verint",
            "twitter"

    logging_level: str
        Level or severity of the events they are used to track. Acceptable values are ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from text_processing import data_parser
    >>> ip_file = "data/chat_transcripts/twiiter/sample_dataset.csv"
    >>> chat_data = data_parser.DataParser(source="twitter", raw_data=ip_file)
    """

    # TODO: Add support for Freshworks data.

    def __init__(
        self,
        raw_data: Union[str, pd.DataFrame],
        source: str = None,
        logging_level: str = "WARNING",
        log_file_path=None,
        verbose=True,
    ) -> None:
        self.source = source
        self.raw_data = raw_data
        self._df_text = pd.DataFrame(data=None)  # Our final data will be set here.
        self.acceptable_sources = [
            "watson-chat",
            "google",
            "assembly_ai",
            "speechmatics",
            "azure",
            "revai",
            "aws",
            "ibm",
            "verint",
            "twitter",
        ]
        if source not in self.acceptable_sources and source is not None:
            raise ValueError(
                f"Enter a valid source. Acceptable sources are {self.acceptable_sources}"
            )

        # Create logger object
        self.logger = MyLogger(
            level=logging_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def __repr__(self) -> str:
        return f"Parsing of raw data from source {self.source} in the file {self.raw_data}"

    @property
    def data(self) -> pd.DataFrame:
        """Getter for text dataframe. Use this to get the data

        Returns
        -------
        pd.Dataframe
            Current state of the pre-processed data
        """
        if self._df_text.empty:
            raise ValueError("Parsing is not done.")

        return self._df_text

    def _parse_google_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor Google, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information. Column names are:
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        google_data = json.loads(text)

        # Word level information is captured in results -> alternatives -> words values.
        df_google = pd.json_normalize(
            google_data, record_path=["results", "alternatives", "words"]
        )
        df_google = df_google.rename(
            columns={
                "startTime": "start_time",
                "endTime": "end_time",
                "speakerTag": "speaker",
                "confidence": "confidence_score",
                "word": "text",
            }
        )
        df_google["start_time"] = df_google["start_time"].str.replace("s", "")
        df_google["end_time"] = df_google["end_time"].str.replace("s", "")
        df_google["conv_b_num"] = np.nan
        df_google["speaker_source"] = np.nan
        df_google["id"] = id
        return df_google

    def _parse_assemblyai_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor Assemblyai, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        assemblyai_data = json.loads(text)

        # Word level information can be found by getting values of utterances -> words.
        df_assemblyai = pd.json_normalize(assemblyai_data, record_path=["utterances", "words"])
        df_assemblyai = df_assemblyai.rename(
            columns={"start": "start_time", "end": "end_time", "confidence": "confidence_score"}
        )

        df_assemblyai["start_time"] = df_assemblyai["start_time"] / 1000
        df_assemblyai["end_time"] = df_assemblyai["end_time"] / 1000
        df_assemblyai["conv_b_num"] = np.nan
        df_assemblyai["speaker_source"] = np.nan
        df_assemblyai["id"] = id
        return df_assemblyai

    def _parse_speechmatics_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor speechmatics, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        speechmatics_data = json.loads(text)

        df_speechmatics = pd.json_normalize(
            speechmatics_data,
            record_path=["results", "alternatives"],
            meta=[["results", "start_time"], ["results", "end_time"]],
        )
        # print(df_speechmatics)
        # df2_speechmatics = pd.json_normalize(speechmatics_data, record_path=["results"])
        # df_speechmatics = pd.concat([df1_speechmatics, df2_speechmatics], axis=1)
        # df_speechmatics.drop("alternatives", axis=1, inplace=True)
        df_speechmatics = df_speechmatics.rename(
            columns={
                "confidence": "confidence_score",
                "content": "text",
                "results.start_time": "start_time",
                "results.end_time": "end_time",
            }
        )
        df_speechmatics["conv_b_num"] = np.nan
        df_speechmatics["speaker_source"] = np.nan
        df_speechmatics["id"] = id

        # Remove unnecessary column
        df_speechmatics = df_speechmatics.drop(["language"], axis=1)

        return df_speechmatics

    def _parse_azure_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor Azure, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        azure_data = json.loads(text)

        df_azure = pd.json_normalize(
            azure_data,
            record_path=["NBest", "Words"],
            meta=[["NBest", "Confidence"], "Id", "speaker"],
            errors="ignore",
        )

        # When speaker tag is not present, we default it with "UNKN"
        df_azure["speaker"] = df_azure["speaker"].fillna("UNKN")

        df_azure = df_azure.rename(
            columns={
                "Word": "text",
                "Offset": "start_time",
                "NBest.Confidence": "confidence_score",
                "Id": "tmp_conv_b_num",
            }
        )

        df_azure["end_time"] = (df_azure["start_time"] + df_azure["Duration"]) / 10000000
        df_azure["start_time"] = df_azure["start_time"] / 10000000
        df_azure["speaker_source"] = np.nan
        df_azure["id"] = id
        df_azure["conv_b_num"] = np.nan

        # Each Conversation block (ID key level) can have many NBest values. Pick the one with highest confidence.
        df_azure["highest_confidence"] = df_azure.groupby(by="tmp_conv_b_num")[
            "confidence_score"
        ].transform(max)
        df_azure = df_azure.query("confidence_score == highest_confidence").copy()

        df_azure.drop(["Duration", "tmp_conv_b_num"], axis=1, inplace=True)
        return df_azure

    def _parse_revai_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor Revai, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        revai_data = json.loads(text)

        df_revai_final = pd.json_normalize(
            revai_data, record_path=["monologues", "elements"], meta=[["monologues", "speaker"]]
        )

        df_revai_final.dropna(inplace=True)
        df_revai_final = df_revai_final.rename(
            columns={
                "ts": "start_time",
                "end_ts": "end_time",
                "confidence": "confidence_score",
                "value": "text",
                "monologues.speaker": "speaker",
            }
        )
        df_revai_final["speaker_source"] = np.nan
        df_revai_final["id"] = id
        df_revai_final["conv_b_num"] = np.nan

        # Drop the unnecessary column
        df_revai_final = df_revai_final.drop(["type"], axis=1)
        return df_revai_final

    def _parse_aws_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor AWS, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        aws_data = json.loads(text)

        df_aws_final = pd.json_normalize(
            aws_data,
            record_path=[
                "TranscriptResultStream",
                "TranscriptEvent",
                "Transcript",
                "Results",
                "Alternatives",
                "Items",
            ],
        )

        df_aws_final = df_aws_final.rename(
            columns={
                "StartTime": "start_time",
                "EndTime": "end_time",
                "Confidence": "confidence_score",
                "Content": "text",
                "Speaker": "speaker",
            }
        )
        df_aws_final["speaker_source"] = np.nan
        df_aws_final["conv_b_num"] = np.nan
        df_aws_final["id"] = id

        df_aws_final = df_aws_final.drop(["Stable", "Type", "VocabularyFilterMatch"], axis=1)

        return df_aws_final

    def _parse_ibm_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in json voice to text output of vendor IBM, for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text : str
            string data containing text and other conversation details from the original JSON response.

        Returns
        -------
        pd.DataFrame
            Returns a dataframe has which word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        ibm_data = json.loads(text)

        df_ibm1 = pd.json_normalize(ibm_data, record_path=["results", "speaker_labels"])

        # Extract text
        df_ibm2 = pd.json_normalize(
            ibm_data, record_path=["results", "alternatives", "timestamps"]
        )
        df_ibm1["text"] = df_ibm2[0]  # First column contains the word

        # Rename columns as per format.
        df_ibm = df_ibm1.rename(
            columns={"from": "start_time", "to": "end_time", "confidence": "confidence_score"}
        )
        df_ibm["conv_b_num"] = np.nan
        df_ibm["speaker_source"] = np.nan
        df_ibm["id"] = id

        # remove the unnecessary columns
        df_ibm.drop(["final"], axis=1, inplace=True)
        return df_ibm

    def _parse_verint_single_call(self, id: str, text: str) -> pd.DataFrame:
        """Takes in pipe delimited text output of vendor verint for one call and converts it to a dataframe in standard format which has word level information

        Parameters
        ----------
        id : str
            unique id of the call

        text: str
            text string for the call(raw data as string for a single call)

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has word level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        self.logger.debug(f"Parsing for id = {id}")

        word_level_data = pd.Series(text.split("|"))
        df_verint = word_level_data.str.split(":", expand=True)
        df_verint.columns = ["text", "confidence_score", "start_time", "end_time", "speaker"]
        df_verint.dropna(inplace=True)

        # Convert str to float and div by 1000 to make it fall between [0, 1]
        df_verint["id"] = id
        df_verint["start_time"] = df_verint["start_time"].astype(float)
        df_verint["end_time"] = df_verint["end_time"].astype(float)
        df_verint["confidence_score"] = df_verint["confidence_score"].astype(float)
        df_verint["start_time"] = df_verint["start_time"] / 1000
        df_verint["end_time"] = df_verint["end_time"] / 1000
        df_verint["confidence_score"] = df_verint["confidence_score"] / 1000

        return df_verint

    def _word_to_conv_block(self, df_word_level: pd.DataFrame) -> pd.DataFrame:
        """Helper method that converts word level transcript dataframe to conversation block level transcript dataframe, adds start and end time, average confidence score and conversation block number at conversation block level. This is for a single call.

        Parameters
        ----------
        df_word_level : pd.DataFrame
            Word level Dataframe. It's format is same as the standard format given below.
            id | text | speaker | speaker_source | start_time | end_time | confidence | conv_b_num

        Returns
        -------
        pd.DataFrame
            Returns dataframe which has conversation block level information in following format:
            id | text | speaker | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        current_call_id = df_word_level["id"].unique()[0]
        self.logger.debug(
            f"Conversation word level to conversation block level for id = {current_call_id} started."
        )
        # Calculate conversation block number whenever speaker changes.
        df_word_level["conv_b_num"] = (
            df_word_level["speaker"] != df_word_level["speaker"].shift()
        ).cumsum()
        # df_word_level = df_word_level.reset_index()

        df_conv_level = (
            df_word_level.groupby(["conv_b_num", "speaker"])
            .agg(
                text=pd.NamedAgg(column="text", aggfunc=" ".join),
                start_time=pd.NamedAgg(column="start_time", aggfunc=np.nanmin),
                end_time=pd.NamedAgg(column="end_time", aggfunc=np.nanmax),
                confidence_score=pd.NamedAgg(column="confidence_score", aggfunc=np.nanmean),
            )
            .reset_index()
        )
        df_conv_level["id"] = current_call_id

        # Other columns
        df_conv_level["speaker_source"] = np.nan

        self.logger.debug(
            f"Conversation word level to conversation block level for id = {current_call_id} completed."
        )

        return df_conv_level

    def _parse_wrapper(
        self, df_raw_data: pd.DataFrame, id_column: str, transcript_column: str
    ) -> pd.DataFrame:
        """Wrapper function to support parallel computation of parsing multiple calls.

        Parameters
        ----------
        df_raw_data: pd.DataFrame
            Raw dataframe for verint.

        id_column : str
            column name of column containing ID of call

        transcript_column : str
           column name of column containing transcript

        Returns
        -------
        pd.DataFrame
            dataframe that has one row per conversation block and multiple rows per call. Columns are:
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        current_call_id = df_raw_data[id_column].values[0]
        current_text = df_raw_data[transcript_column].values[0]

        self.logger.debug(f"Call {current_call_id} selected for parsing.")

        if self.source == "verint":
            df_word_level = self._parse_verint_single_call(id=current_call_id, text=current_text)
        elif self.source == "google":
            df_word_level = self._parse_google_single_call(id=current_call_id, text=current_text)
        elif self.source == "assembly_ai":
            df_word_level = self._parse_assemblyai_single_call(
                id=current_call_id, text=current_text
            )
        elif self.source == "speechmatics":
            df_word_level = self._parse_speechmatics_single_call(
                id=current_call_id, text=current_text
            )
        elif self.source == "azure":
            df_word_level = self._parse_azure_single_call(id=current_call_id, text=current_text)
        elif self.source == "revai":
            df_word_level = self._parse_revai_single_call(id=current_call_id, text=current_text)
        elif self.source == "aws":
            df_word_level = self._parse_aws_single_call(id=current_call_id, text=current_text)
        elif self.source == "ibm":
            df_word_level = self._parse_ibm_single_call(id=current_call_id, text=current_text)

        df_conv_level = self._word_to_conv_block(df_word_level=df_word_level)

        self.logger.debug(f"Call {current_call_id} completed parsing.")

        # self._df_text = pd.concat([self._df_text, df_conv_level])

        return df_conv_level

    def _parse_setup(self, id_column: str, transcript_column: str, n_jobs: int) -> pd.DataFrame:
        """if the raw data contains multiple' call transcripts in a single csv, this function converts the call level dataframe (i.e., each row in a dataframe contains the entire call transcript) to conversation block level dataframe (i.e., each row in a dataframe is one conversation block for a call).

        Parameters
        ----------
        id_column : str
            column name of column containing ID of call

        transcript_column : str
           column name of column containing transcript

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            dataframe that has one row per conversation block and multiple rows per call. Columns are:
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num

        """
        if isinstance(self.raw_data, pd.DataFrame):
            self.logger.debug("Raw data is passed as dataframe.")
            raw_data = self.raw_data
        else:
            extension = os.path.splitext(self.raw_data)[1]
            if extension == ".csv":
                raw_data = pd.read_csv(self.raw_data)
            elif extension == ".txt":
                # This can occur if its a single call.
                with open(self.raw_data, "r") as call:
                    raw_data = pd.DataFrame(
                        data={id_column: ["id#1"], transcript_column: [call.read()]}
                    )
            elif extension == ".json":
                with open(self.raw_data, "r", encoding="utf-8") as json_file:
                    raw_data = pd.DataFrame(
                        data={
                            id_column: ["id#1"],
                            transcript_column: [json_file.read()],
                        }
                    )
            elif extension == ".jsonl":
                with open(self.raw_data, "r") as multi_call:
                    calls_df = pd.DataFrame(data=None, columns=[id_column, transcript_column])
                    for rn, line in enumerate(multi_call):
                        current = pd.DataFrame(
                            data={id_column: ["id#" + str(rn + 1)], transcript_column: [line]}
                        )
                        calls_df = pd.concat([calls_df, current])

                raw_data = calls_df.reset_index(drop=True)

        # Convert id column to str
        raw_data[id_column] = np.where(
            raw_data[id_column].isnull(), np.nan, raw_data[id_column].astype("str")
        )

        # Check if all call id value is valued. if not, fill it with a sequence number.
        null_id_str = "nullid#"
        null_idx = raw_data[id_column].isnull()
        raw_data[id_column] = raw_data[id_column].fillna(null_idx.cumsum())
        raw_data.loc[null_idx, id_column] = null_id_str + raw_data.loc[null_idx, id_column].astype(
            "int"
        ).astype("str")

        wrapper_kwargs = {
            "id_column": id_column,
            "transcript_column": transcript_column,
        }

        # Sequential took 25s
        # _ = raw_data[[id_column, transcript_column]].apply(self._parse_wrapper, **wrapper_kwargs)

        # Parallel took 9s
        df_final = parallelize_row_wise(
            df=raw_data[[id_column, transcript_column]],
            func=self._parse_wrapper,
            kwargs=wrapper_kwargs,
            n_jobs=n_jobs,
        )

        # self._df_text = self._df_text.reset_index(drop=True)
        df_final = df_final.reset_index(drop=True)

        # self.logger.debug(f"Final length is {self._df_text.shape[0]}")

        # return self._df_text
        return df_final

    def _parse_watson_chat(self) -> pd.DataFrame:
        """Helper method which parses watson chat raw data into a dataframe. Below dict shows mapping between raw data and parsed data. Keys are the old column names, values are new column names as per our template. In the preprocessing template, start_time and confidence_score will be set to nan. In the raw data, we will keep the columns such as timel, texttype as is.

        Mapping::

            {
                "record": "id",
                "text": "text",
                "source": "speaker",  # agent/visitor
                "by": "speaker_source",  # Agent names if agent/ You if visitor
                "time": "end_time",
                "lineseq": "conv_b_num"
            }

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has conversation block level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        if isinstance(self.raw_data, pd.DataFrame):
            self.logger.debug("Raw data is passed as dataframe.")
            df = self.raw_data
        else:
            df = pd.read_csv(self.raw_data)

        old_to_new_col_mapping = {
            "record": "id",
            "text": "text",
            "source": "speaker",  # agent/visitor
            "by": "speaker_source",  # Agent names if agent/ You if visitor
            "time": "end_time",
            "lineseq": "conv_b_num",
        }
        df = df.rename(columns=old_to_new_col_mapping)
        df["start_time"] = np.nan
        df["confidence_score"] = np.nan

        return df

    def _parse_twitter(self) -> pd.DataFrame:
        """Parse twitter raw data into a dataframe. Below dict shows mapping between raw data and parsed data. Keys are the old column names, values are new column names as per our template. In the preprocessing template, all other columns will be set to nan. In the raw data, we will keep rest column as is.

        Mapping::

            {
                "tweet_id": "id",
                "text": "text",
                "belongsto": "speaker",  # agent/visitor
                "time": "end_time",
            }

        Returns
        -------
        pd.DataFrame
            Returns a dataframe which has conversation block level information
            id | text | speaker_by | speaker_source | start_time | end_time | confidence | conv_b_num
        """
        if isinstance(self.raw_data, pd.DataFrame):
            self.logger.debug("Raw data is passed as dataframe.")
            df = self.raw_data
        else:
            df = pd.read_csv(self.raw_data)

        df = df.rename(
            columns={
                "tweet_id": "id",
                "text": "text",
                "time": "end_time",
            }
        )
        df["start_time"] = np.nan
        df["confidence_score"] = np.nan
        df["conv_b_num"] = np.nan
        df["speaker_source"] = np.nan
        df["speaker"] = np.nan

        return df

    def _parse_no_source(
        self, id_column: str, transcript_column: str, col_in: dict = None
    ) -> pd.DataFrame:
        """Helper method to parse data for non-supported sources. ``transcript_column`` containing the text is mandatory. If ``id_column`` contains null/NaN, autogenerated unique ID will be used. For any other column that is present in the raw data and serves same meaning as the columns in the standard template (for standard template, refer documentation of Text processing), pass it in ``col_in``. Otherwise, those columns will be created and set as NaN.

        Parameters
        ----------
        id_column : str
            Name of the ID column

        transcript_column : str
            Name of the Text column

        col_in : dict, optional
            dictionary containing column mapping to standard format., by default None

        Returns
        -------
        pd.DataFrame
            Dataframe converted to standard template as much as possible.
        """
        # Check if all call id value is valued. if not, fill it with a sequence number.
        null_id_str = "id#"
        null_idx = self.raw_data[id_column].isnull()
        self.raw_data[id_column] = self.raw_data[id_column].fillna(null_idx.cumsum())
        self.raw_data.loc[null_idx, id_column] = null_id_str + self.raw_data.loc[
            null_idx, id_column
        ].astype("int").astype("str")

        df = self.raw_data.rename(columns={id_column: "id", transcript_column: "text"})

        # Add columns only if its not there already.
        if col_in is None:

            if "start_time" not in df.columns:
                df["start_time"] = np.nan

            if "end_time" not in df.columns:
                df["end_time"] = np.nan

            if "confidence_score" not in df.columns:
                df["confidence_score"] = np.nan

            if "conv_b_num" not in df.columns:
                df["conv_b_num"] = df.groupby("id")["id"].cumcount() + 1

            if "speaker_source" not in df.columns:
                df["speaker_source"] = np.nan

            if "speaker" not in df.columns:
                df["speaker"] = np.nan
        else:

            if col_in.get("start_time", "not a column") not in df.columns:
                df["start_time"] = np.nan

            if col_in.get("end_time", "not a column") not in df.columns:
                df["end_time"] = np.nan

            if col_in.get("confidence_score", "not a column") not in df.columns:
                df["confidence_score"] = np.nan

            if col_in.get("conv_b_num", "not a column") not in df.columns:
                df["conv_b_num"] = df.groupby("id")["id"].cumcount() + 1

            if col_in.get("speaker_source", "not a column") not in df.columns:
                df["speaker_source"] = np.nan

            if col_in.get("speaker", "not a column") not in df.columns:
                df["speaker"] = np.nan

        return df

    def _convert_to_seconds(self, value: Union[float, int], time_level: str) -> float:
        """Helper method to convert given numeric value to seconds as per the time level.

        Parameters
        ----------
        value : Union[float, int]
            Input number that can be in millisecond, seconds, minutes or hours format.

        time_level : str
            Specify level of time measurement. Acceptable values are millisecond, sec, min and hour.

        Returns
        -------
        float
            Seconds value
        """
        try:
            value = float(value)
        except:
            self.logger.warning(
                f"Value = {value} cannot be casted to valid number. Hence, it cannot be converted to seconds."
            )
            return value

        if time_level == "ms":
            return value / 1000.0
        elif time_level == "sec":
            return value
        elif time_level == "min":
            return value * 60.0
        elif time_level == "hour":
            return value * 60.0 * 60.0

    def parse_raw_data(
        self,
        col_in: dict = None,
        col_out: dict = None,
        n_jobs: int = 1,
        time_level: str = None,
        timestamp_format: str = None,
    ) -> None:
        """Parses the raw data to standard dataframe at conversation block level and then renames column as per ``col_out`` if provided.

        Standard dataframe will be of the format:
        id | conv_b_num | speaker |	speaker_source | text |	start_time | end_time |	confidence_score

        Parameters
        ----------
        col_in : dict, optional
            Mapping which indicates the id column and transcript column when a dataframe is passed as the input. Transcript column must be given as shown below. If id column doesn't exist in raw data, it can be skipped. by default None. i.e., if a dataframe is passed as input, id column name in dataframe is considered to be "id" and transcript column name is considered to be "transcript".

            For example::

                {
                    "id_column": "id",
                    "transcript_column": "transcript"
                }

        col_out : dict, optional
            Mapping between column names from the standard template to user defined column names. If you wish to rename only few columns, have those column names alone as key-value pair[s]. by default None i.e., column name will follow the standard template.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_block_number",
                    "text": "text_block"
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        time_level: str
            Enter the level of measurement of timestamp fields. Acceptable values are "ms", "sec", "min", "hour" and "datetime". This should be valued only if source is None. by default None.

        timestamp_format: str
            Format of the timestamp columns. It must be valued if ``time_level = datetime``. by default None

            For example::

                "%y%m%d %H%M"

        Raises
        ------
        ValueError
            If any of the sources are invalid or any arguments are missing or invalid.

        Examples
        --------
        >>> ip_file = "data/chat_transcripts/twitter/sample_dataset.csv"
        >>> chat_data = data_parser.DataParser(source="twitter", ip_file=ip_file)
        >>> chat_data.parse_raw_data()

        """
        self.logger.info(f"Parsing raw data started for {self.source}")

        # check for transcript columns when input is df
        if col_in is not None and "transcript_column" not in col_in.keys():
            self.logger.error("col_in is missing transcript_column key-value pair")
            raise ValueError("col_in is missing transcript_column key-value pair")
        elif time_level is not None and time_level not in ["ms", "sec", "min", "hour", "datetime"]:
            raise ValueError("Enter correct value in time_level.")

        if col_in is not None:
            # check if id column is given.
            if "id_column" not in col_in.keys():
                self.logger.warning(
                    "id_column is not entered in col_in parameter, hence id column will be auto generated as sequence."
                )
                if isinstance(self.raw_data, pd.DataFrame):
                    # Inside _parse_setup, this will be auto generated.
                    self.raw_data["id"] = np.nan
                id_column = "id"
            else:
                id_column = col_in["id_column"]

            # Get transcript column
            transcript_column = col_in["transcript_column"]
        else:
            id_column = "id"
            transcript_column = "transcript"

        if self.source == "watson-chat":
            self._df_text = self._parse_watson_chat()
        elif self.source == "twitter":
            self._df_text = self._parse_twitter()
        elif self.source in [
            "google",
            "assembly_ai",
            "speechmatics",
            "azure",
            "revai",
            "aws",
            "ibm",
            "verint",
        ]:
            self._df_text = self._parse_setup(
                id_column=id_column, transcript_column=transcript_column, n_jobs=n_jobs
            )
        elif self.source is None:
            self.logger.warning(
                "No source is entered. Output of data parsing will not be in standard format and so downstream tasks may not work as intended."
            )
            self._df_text = self._parse_no_source(
                id_column=id_column,
                transcript_column=transcript_column,
                col_in=col_in,
            )

            if time_level is not None:
                self.logger.info(
                    f"Timestamp conversion is specified with time level {time_level}."
                )
                # If input timestamp field is datetime, then we apply to_datetime to convert to timestamp field.
                if time_level == "datetime":
                    if timestamp_format is None:
                        raise ValueError(
                            "timestamp_format should be valued with valid format if time_level = 'datetime'"
                        )

                    self.logger.info(
                        f"Timestamp format {timestamp_format} will be used to convert timestamp fields to datetime object."
                    )
                    if col_in.get("start_time", "Not a column") in self._df_text.columns:
                        self._df_text[col_in["start_time"]] = pd.to_datetime(
                            self._df_text[col_in["start_time"]], format=timestamp_format
                        )

                    if col_in.get("end_time", "Not a column") in self._df_text.columns:
                        self._df_text[col_in["end_time"]] = pd.to_datetime(
                            self._df_text[col_in["end_time"]], format=timestamp_format
                        )
                else:
                    if col_in.get("start_time", "Not a column") in self._df_text.columns:
                        self._df_text[col_in["start_time"]] = self._df_text[
                            col_in["start_time"]
                        ].apply(self._convert_to_seconds, time_level=time_level)

                    if col_in.get("end_time", "Not a column") in self._df_text.columns:
                        self._df_text[col_in["end_time"]] = self._df_text[
                            col_in["end_time"]
                        ].apply(self._convert_to_seconds, time_level=time_level)

        else:
            raise ValueError(
                f"Enter a Valid source. Acceptable sources are {self.acceptable_sources}"
            )

        # Rename column as per user input.
        if col_out is not None:
            self._df_text = self._df_text.rename(columns=col_out)
            self.logger.info("Columns will be renamed as per values passed in col_out")

        # Reset index
        self._df_text = self._df_text.reset_index(drop=True)

        self.logger.info(f"Parsing raw data completed for {self.source}")

        return

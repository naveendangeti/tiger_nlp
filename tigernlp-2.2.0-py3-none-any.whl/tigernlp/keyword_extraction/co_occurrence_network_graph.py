import ast
import numpy as np
import os
import pandas as pd
import time
import tqdm
from joblib import effective_n_jobs
from torch.multiprocessing import Pool

from tigernlp.core.utils import MyLogger
from tigernlp.text_processing.api import TextProcessor


class CoOccurrenceNetworkGraph:
    """Co-occurrence network graph generation utility class.

    Generates a network graph to identify top occurring need states, expressions and need state - expressions pairs.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> import pandas as pd
    >>> from tigernlp.keyword_extraction.api import CoOccurrenceNetworkGraph
    >>> input_df = pd.read_parquet(r"span_cat_inference_60k.parquet")
    >>> input_df.dropna(inplace=True)
    >>> span_category_cols = ['BENEFIT', 'BRAND', 'FLAVOR', 'INGREDIENT', 'OCCASION', 'PRODUCT']
    >>> inf_ob = SpanCatInference()
    >>> mapping_df = inf_ob.get_span_category_mapping(input_df, span_category_cols)
    >>> need_states = ['BENEFIT','BRAND', 'OCCASION']
    >>> expressions = ['FLAVOR','INGREDIENT','PRODUCT']
    >>> drop_unigram_spans = ["BENEFIT", "OCCASION"]
    >>> co_occurrence_network_graph_obj = CoOccurrenceNetworkGraph()
    >>> results = (
    >>>     co_occurrence_network_graph_obj
    >>>     .build_co_occurrence_network_graph(
    >>>         df_inference=df_sample.copy(),
    >>>         df_inference_unique_id_col="unique_id_df",
    >>>         mapping_df=mapping_df.copy(),
    >>>         mapping_df_span_col="spans",
    >>>         need_states=need_states,
    >>>         expressions=expressions,
    >>>         drop_unigram_spans=drop_unigram_spans,
    >>>     )
    >>> )

    """

    def __init__(
        self,
        log_level="WARNING",
        log_file_path=None,
        verbose=True,
    ):
        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
        self.tp_ob = TextProcessor(log_level=log_level, log_file_path=log_file_path, verbose=verbose)

    def _process_spans_inference(self, data, col):
        """Function to process spans present for each span category (need_state + expression cols) from span category inference output.
        Converts spans to lower case, performs lemmatization, drops spans with only special characters, removes numbers etc.

        This function is used internally.

        Parameters
        ----------
        data : pd.DataFrame
            dataframe with spans present in the col. It is inference output from span categorizer.
        col : str
            column name for the span values. Example - "BRAND" or "brand"

        Returns
        -------
        pd.DataFrame
            clean spans available in the `col` column
        """
        # lower and lemmatization for need state and expression
        # do not need multiple varients of the same words for the graph
        # remove stopwords words from the spans

        data[col] = data[col].apply(lambda a: ast.literal_eval(str(a)))
        # removes empty list form the list of need states and expressions identified
        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.to_lower(i) for i in x])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_punctuations(i) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_numbers(i) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_nonASCII_characters(i) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_misc_characters(i) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_short_word(i, len_min_wrd=2) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.lemmatization(i, pos="v") for i in x])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_stopwords(i, words_to_keep=["no", "not"]) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        data[col] = data[col].apply(lambda x: [self.tp_ob.remove_blank_space(i) for i in x])

        data[col] = data[col].apply(lambda x: [i.strip() for i in x if len(i.strip()) > 0])
        return data[col]

    def _process_spans_mapping(self, data, col):
        """Function to process spans present in the mapping span column (mapping_df_span_col) from the span category mapping dataframe.
        Converts mapping spans to lower case, performs lemmatization, drops spans with only special characters, removes numbers etc.
        It performs same operations as `_process_spans_inference` and these cleaned spans are used to map the span categories in the final output.

        This function is used internally.

        Parameters
        ----------
        data : pd.DataFrame
            dataframe with mapping_df_span_col. It is mapping_df taken as an input in inference function
        col : str
            mapping_df_span_col

        Returns
        -------
        pd.DataFrame
            clean spans available in the `mapping_df_span_col` column
        """
        # lower and lemmatization for need state and expression
        # do not need multiple varients of the same words for the graph
        # remove stopwords words from the spans

        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.to_lower(i))
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_punctuations(i))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_numbers(i))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_nonASCII_characters(i))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_misc_characters(i))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_short_word(i, len_min_wrd=2))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.lemmatization(i, pos="v"))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_stopwords(i, words_to_keep=["no", "not"]))
        data = data[data[col] != ""]
        data[col] = data[col].apply(lambda i: self.tp_ob.remove_blank_space(i))
        data = data[data[col] != ""]

        return data

    def _graph_structure(self, df):
        """Function to generate all the possible need states and expressions combinations.
        TODO - Include docstrings for df
        """
        df = df.reset_index(drop=True)
        combination_list = []
        pbar = tqdm.tqdm(total=len(df))
        for i in range(len(df)):
            combination_list = combination_list + [
                (df[self.df_inference_unique_id_col][i], x, y) for x in df["need_state_nouns"][i] for y in df["expression_nouns"][i]
            ]
            pbar.update(1)
        pbar.close()

        combination_pairs_df = pd.DataFrame(combination_list, columns=[self.df_inference_unique_id_col, "need_states", "expressions"])

        return combination_pairs_df

    def _filter_graph_df(self, graph_df, need_states_doc_freq_cutoff, expressions_doc_freq_cutoff, pair_doc_frequency_cutoff):
        """Function to filter the co-occurence graph based on the cut-offs provided in graph_filtering_params
        TODO - Check and update to run this only if graph_filtering=True. Check if there are additional steps performered here which are required for final output

        Parameters
        ----------
        graph_df : pd.DataFrame
            Dataframe with aggregated view of need states and expressions combinations
        need_states_doc_freq_cutoff : int, optional
            only those need states will be considered that has need state document freq >= need_states_doc_freq_cutoff
        expressions_doc_freq_cutoff: int, optional
            only those expressions will be considered that has expression document freq >= expressions_doc_freq_cutoff
        pair_doc_frequency_cutoff : int, optional
            only those need_state-expression pairs will be considered that has pair document freq >= pair_doc_frequency_cutoff

        Returns
        -------
        pd.Dataframe :
            Returns the filtered co-occurence network based on the provided cut-offs
        """

        need_states_doc_freq_cutoff = int(need_states_doc_freq_cutoff)
        expressions_doc_freq_cutoff = int(expressions_doc_freq_cutoff)
        pair_doc_frequency_cutoff = int(pair_doc_frequency_cutoff)

        filtered_graph = graph_df[
            (graph_df["need_states_doc_freq"] >= need_states_doc_freq_cutoff)
            & (graph_df["expressions_doc_freq"] >= expressions_doc_freq_cutoff)
            & (graph_df["pair_doc_frequency"] >= pair_doc_frequency_cutoff)
        ].reset_index(drop=True)

        return filtered_graph

    def _need_states_clubbing(self, data_frame):
        """Function to club similar polygrams(like trigrams, tetragrams, pentagrams etc) into a single n-gram word based on the document frequency, token count and alphabetical order.
        Example - if we have three phrases such as ["muscle mass", "gain muscle mass", "muscle mass loss"] with document frequency of [10, 10, 5] respectively.
        We will associate one n-gram to all the phrases, "muscle mass" in this case because "muscle mass" has the highest document frequency and lowest token count (2), (number of grams)

        Parameters
        ----------
        data_frame : pd.DataFrame
            filtered co-occurence network

        Returns
        -------
        pd.DataFrame:
            dataframe with two columns - Clubbed_name and List_of_phrases
            Example -
            Clubbed_name : str : "muscle mass"
            List_of_phrases: list : ["muscle mass", "gain muscle mass", "muscle mass loss"]
        """

        need_states_df = data_frame[["need_states", "need_states_doc_freq", "need_states_token_count"]]
        need_states_df = need_states_df.drop_duplicates()
        # sorting on doc freq and token count to select the clubbed need state name
        # incase of a tie in doc freq, bigram/lowest n gram word will be selected
        # included to compute highest freq phrase
        need_states_df = need_states_df.sort_values(
            by=["need_states_doc_freq", "need_states_token_count", "need_states"], ascending=[False, True, True]
        ).reset_index(drop=True)
        need_states_phrases_list = list(need_states_df["need_states"])

        phrase_freq_mapping = data_frame[["need_states", "need_states_doc_freq"]].drop_duplicates().reset_index(drop=True)
        phrase_freq_mapping.columns = ["phrase", "phrase_doc_freq"]

        a = []
        b = []
        completed_phrases_set = set()
        pbar = tqdm.tqdm(total=len(need_states_phrases_list))
        for i in need_states_phrases_list:
            token_count = len(i.split())
            filtered_need_states_df = need_states_df[need_states_df["need_states_token_count"] > token_count]
            current = []
            for j in list(filtered_need_states_df["need_states"]):
                if j not in completed_phrases_set:
                    sub_list = i.split()
                    main_list = j.split()
                    if all(x in main_list for x in sub_list):
                        current.append(j)

            if i not in completed_phrases_set:
                current.append(i)

            if len(current) > 0:
                temp_hfp = need_states_df[need_states_df["need_states"].isin(current)]
                temp_hfp = temp_hfp.sort_values(
                    by=["need_states_doc_freq", "need_states_token_count", "need_states"], ascending=[False, True, True]
                ).reset_index(drop=True)
                highest_freq_phrase = temp_hfp["need_states"][0]
                a.append(highest_freq_phrase)
                b.append(current)

            completed_phrases_set = completed_phrases_set.union(set(current))
            need_states_phrases_list = list(set(need_states_phrases_list) - completed_phrases_set)
            pbar.update(1)
        pbar.close()

        main_df = pd.DataFrame({"Clubbed_name": a, "List_of_phrases": b})
        return main_df

    def build_co_occurrence_network_graph(
        self,
        df_inference=None,
        df_inference_unique_id_col=None,
        mapping_df=None,
        mapping_df_span_col="spans",
        need_states=["BENEFIT", "BRAND", "OCCASION"],
        expressions=["FLAVOR", "INGREDIENT", "PRODUCT"],
        drop_unigram_spans=["BENEFIT", "OCCASION"],
        graph_filtering_params=None,
        parallel_processing=False,
        n_core=-1,
    ):
        """Function to generate the co-occurence network graph for the predicted spans from span categorizer model.
        TODO - Factor for identified noun chunks from PhraseExtraction module

        Parameters
        ----------
        df_inference : pd.DataFrame, optional
            dataframe with spans associated with each span category as individual columns, by default None
            This data is output for span cat inference module.
        df_inference_unique_id_col : str, optional
            unique_id column name which defines the unique data level in df_inference, by default None
            if None, index will be used to create unique ids.
            unique id is used to compute the pair doc frequency, need state frequency and expression frequency, unique id should be present at review level and not tokenized sentence level
        mapping_df : _type_, optional
            spans to span category mapping dataframe with value 1 or 0 for each span, by default None
            refer inf_ob.get_span_category_mapping() docstrings for more details.
        mapping_df_span_col : str, optional
            span column name in mapping_df, by default "spans"
        need_states : list, optional
            list of columns which you want to consider as need states, by default ["BENEFIT", "BRAND", "OCCASION"]
            Note - columns as part of `expressions` can not be included in `need_states` and should be exclusive of each other
        expressions : list, optional
            list of columns which you want to consider as expressions, by default ["FLAVOR", "INGREDIENT", "PRODUCT"]
            Note - columns as part of `need_states` can not be included in `expressions` and should be exclusive of each other
        drop_unigram_spans : list, optional
            will drop unigram spans for the associated column names, by default ["BENEFIT", "OCCASION"]
            Example - "diet"span associated with "BENEFIT" will not be available in the co-occurence network
        graph_filtering_params : dict, optional
            paramters required to filter the co-occurence network based on the provided cut-offs, by default None

            if None, co-occurence network without any filters on pair document and document frequency will be returned
            keys required - {'graph_filtering': False, 'need_states_doc_freq_cutoff': 20, 'expressions_doc_freq_cutoff': 2, 'pair_doc_frequency_cutoff': 1}

            "graph_filtering" : bool
                if True, will use the cut-offs to filter the co-occurence network graph
            "need_states_doc_freq_cutoff" : int
                cut-off to filter need state phrase based on the document frequency.
                Example - if need state phrase `weight loss` is available for 15 df_inference_unique_id_col it will be dropped from the network
            "expressions_doc_freq_cutoff" : int
                cut-off to filter expression phrase based on the document frequency.
                Example - if expression phrase `green tea` is available for 1 df_inference_unique_id_col it will be dropped from the network
            "pair_doc_frequency_cutoff" : int
                cut-off to filter need state and expression phrase pair based on the pair document frequency.
                Example - if need state and expression phrase pair (`weight loss`, `green tea`) is available for 1 df_inference_unique_id_col it will be dropped from the network
                Note - Pair will be dropped even if need state and expression meets the respective document frequency cut-off
        parallel_processing : bool, optional
            Whether to use parallel processing, by default False.
        n_core : int, optional
            number of concurrent workers, by default -1 i.e., use all available workers

        Returns
        -------
        list[pd.DataFrame, pd.DataFrame, pd.DataFrame]
            list[0] : dataframe with columns [df_inference_unique_id_col, need_state_nouns,	expression_nouns] + df_inference.columns
                need_state_nouns = list of all phrases/spans associated with the need_states columns. Example : [antioxidant, diet, infection, Disney]

                expression_nouns = list of all phrases/spans associated with the expression columns. Example : [dark, chocolate, vital, contain, bell, almond]

            list[1] : dataframe with columns [Clubbed_name, List_of_phrases]
                Clubbed_name : str : ``muscle mass``,
                List_of_phrases: list : ``["muscle mass", "gain muscle mass", "muscle mass loss"]``

                How we compute Clubbed_name - if we have three phrases such as ["muscle mass", "gain muscle mass", "muscle mass loss"] with document frequency of [10, 10, 5] respectively.
                We will associate one n-gram to all the phrases, "muscle mass" in this case because "muscle mass" has the highest document frequency and lowest token count (2), (number of grams)

            list[2] : co-occurence network dataframe with columns
                ``[Clubbed Need states, Need states, Expressions, pair_doc_frequency, Doc freq(Need states), Doc freq(Expressions), need_states_token_count, expressions_token_count, BENEFIT, BRAND, OCCASION, FLAVOR, INGREDIENT, PRODUCT, # Expressions, # Need states]``
                where ``[BENEFIT, BRAND, OCCASION, FLAVOR, INGREDIENT, PRODUCT]`` columns will change based on the need_states and expression parameter input provided by the user.

                **Column description**

                - *Clubbed Need states*: hierarchy of need state column computed as explained in the above list[1] description
                - *Need states*: list of spans (entities) associated with the need states categories such as ["BENEFIT", "BRAND", "OCCASION"]
                - *Expressions*: list of spans (entities) associated with the expressions categories such as ["FLAVOR", "INGREDIENT", "PRODUCT"]
                - *pair_doc_frequency*: #unique ids for need state and expressions pairs
                - *Doc freq(Need states)*: #unique ids for need state
                - *Doc freq(Expressions)*: #unique ids for expressions
                - *need_states_token_count*: #ngrams in need states. Example - if need state = "muscle mass loss", need_states_token_count = 2
                - *expressions_token_count*: #ngrams in expressions. Example - if expressions = "green tea", expressions_token_count = 2
                - *BENEFIT, BRAND, OCCASION, FLAVOR, INGREDIENT, PRODUCT*: 1 or 0 flag to identify the need state and expressions category
                - *# Expressions*: #unique expressions associated with the need state span
                - *# Need states*: #unique need states associated with the expression span
        """
        try:

            # TODO - fix column names for coding best practices for all the possible columns
            # TODO - check what happens with phrases part of multiple categories where one category is in drop_unigram_spans and another is not part of it.
            # TODO - Solution is to mark that span as 0 for the category available in drop_unigram_spans
            # TODO - filter for records where sum(need_state + expression column flag)==0, i.e. spans does not belond to any of the provided need state and expression category

            self.logger.info("Building co-occurence network graph process started")
            self.parallel_processing = parallel_processing
            self.n_core = effective_n_jobs(n_core)

            if not isinstance(self.parallel_processing, bool):
                raise ValueError(
                    f"Input parallel_processing is of incorrect type - {type(self.parallel_processing)} in this method. Requires an input bool"
                )

            if self.n_core > os.cpu_count():
                raise ValueError(f"Input n_core exceeds the limit. Can not proceed further, Max {os.cpu_count()} core can be used")

            df = df_inference.copy()
            if (df is None) or (len(df) <= 0):
                raise ValueError(f"Bad input passed to df {df}")

            if (mapping_df is None) or (len(mapping_df) <= 0):
                raise ValueError(f"Bad input passed to mapping_df {mapping_df}")

            if not isinstance(need_states, list):
                raise ValueError(f"Input need_states is of incorrect type - {type(need_states)} in this method. Requires an input list")

            if not isinstance(expressions, list):
                raise ValueError(f"Input expressions is of incorrect type - {type(expressions)} in this method. Requires an input list")

            if len(set(need_states) - set(df.columns)) != 0:
                raise ValueError(
                    f"Need State columns {need_states} are either incorrect or not present in the inference dataframe columns list {df.columns}"
                )

            if len(set(expressions) - set(df.columns)) != 0:
                raise ValueError(
                    f"Expression columns {expressions} are either incorrect or not present in the inference dataframe columns list {df.columns}"
                )

            self.df_inference_unique_id_col = df_inference_unique_id_col
            if self.df_inference_unique_id_col is not None:
                if self.df_inference_unique_id_col not in df.columns:
                    raise ValueError(
                        f"Unique ID {self.df_inference_unique_id_col} is either incorrect or not present in the inference dataframe columns list {df.columns}"
                    )

            if len(set(need_states + expressions) - set(mapping_df.columns)) != 0:
                raise ValueError(
                    f"Need state and Expression columns {need_states, expressions} are either incorrect or not present in the mapping dataframe columns list {mapping_df.columns}"
                )
            if mapping_df_span_col not in mapping_df.columns:
                raise ValueError(
                    f"span column {mapping_df} is either incorrect or not present in the mapping dataframe columns list {mapping_df.columns}"
                )

            if graph_filtering_params is None:
                graph_filtering = False
                need_states_doc_freq_cutoff = 1
                expressions_doc_freq_cutoff = 1
                pair_doc_frequency_cutoff = 1

            if graph_filtering_params is not None:
                graph_filtering = graph_filtering_params["graph_filtering"]
                need_states_doc_freq_cutoff = graph_filtering_params["need_states_doc_freq_cutoff"]
                expressions_doc_freq_cutoff = graph_filtering_params["expressions_doc_freq_cutoff"]
                pair_doc_frequency_cutoff = graph_filtering_params["pair_doc_frequency_cutoff"]

                if not isinstance(graph_filtering, bool):
                    raise ValueError(
                        f"Input graph_filtering is of incorrect type - {type(graph_filtering)} in this method. Requires an input bool"
                    )

                if not isinstance(need_states_doc_freq_cutoff, int):
                    raise ValueError(
                        f"Input need_states_doc_freq_cutoff is of incorrect type - {type(need_states_doc_freq_cutoff)} in this method. Requires an input integer"
                    )

                if not isinstance(expressions_doc_freq_cutoff, int):
                    raise ValueError(
                        f"Input expressions_doc_freq_cutoff is of incorrect type - {type(expressions_doc_freq_cutoff)} in this method. Requires an input integer"
                    )

                if not isinstance(pair_doc_frequency_cutoff, int):
                    raise ValueError(
                        f"Input pair_doc_frequency_cutoff is of incorrect type - {type(pair_doc_frequency_cutoff)} in this method. Requires an input integer"
                    )

            for col in expressions + need_states:
                df[col] = self._process_spans_inference(df, col)

            self.logger.info("Processed inference spans")

            mapping_df = self._process_spans_mapping(mapping_df, mapping_df_span_col)
            mapping_df = mapping_df.groupby([mapping_df_span_col]).max().reset_index()
            self.logger.info("Processed mapping dataframe spans")

            def func_to_append_noun_chunks(x, span_cat_list):
                a = []
                for i in span_cat_list:
                    # print(x[i])
                    a = a + ast.literal_eval(str(x[i]))
                return list(set(a))

            df["need_state_nouns"] = df.apply(lambda a: func_to_append_noun_chunks(a, need_states), axis=1)
            df["expression_nouns"] = df.apply(lambda a: func_to_append_noun_chunks(a, expressions), axis=1)

            df.reset_index(inplace=True, drop=True)
            df = df[df.apply(lambda c: ((c["need_state_nouns"] != []) | (c["expression_nouns"] != [])), axis=1)].reset_index(drop=True)
            df["need_state_nouns"] = df["need_state_nouns"].apply(lambda a: ["None"] if a == [] else a)
            df["expression_nouns"] = df["expression_nouns"].apply(lambda a: ["None"] if a == [] else a)

            if self.df_inference_unique_id_col is None:
                self.logger.warning("Unique ID column not present in the data. Unique ID created using dataframe index")
                self.df_inference_unique_id_col = "unique_id"
                df[self.df_inference_unique_id_col] = df.index

            df[self.df_inference_unique_id_col] = df[self.df_inference_unique_id_col].astype("str")

            cols_to_select = [i for i in df.columns if i not in need_states + expressions]
            text_nouns = df[cols_to_select]

            # --------------------------- Building Graph Structure ---------------------------
            begin = time.time()
            df = df[[self.df_inference_unique_id_col, "need_state_nouns", "expression_nouns"]]
            # df[df_inference_unique_id_col] = df[df_inference_unique_id_col].astype("int")

            if self.parallel_processing:
                df_split = np.array_split(df, self.n_core)
                pool = Pool(processes=self.n_core)
                combination_pairs_df = pd.concat(pool.map(self._graph_structure, df_split))
                pool.close()
            else:
                combination_pairs_df = self._graph_structure(df)
            combination_pairs_df = combination_pairs_df.reset_index(drop=True)

            end = time.time()
            self.logger.info(f"Building Graph Structure Completed, Total runtime {end - begin}")

            # ---------------------------------------------------------------------------------
            begin = time.time()

            combination_pairs_df.reset_index(inplace=True, drop=True)
            combination_pairs_df["pair_doc_frequency"] = combination_pairs_df.groupby(["need_states", "expressions"])[
                self.df_inference_unique_id_col
            ].transform("nunique")
            combination_pairs_df["need_states_doc_freq"] = combination_pairs_df.groupby(["need_states"])[
                self.df_inference_unique_id_col
            ].transform("nunique")
            combination_pairs_df["expressions_doc_freq"] = combination_pairs_df.groupby(["expressions"])[
                self.df_inference_unique_id_col
            ].transform("nunique")

            graph_df = combination_pairs_df[
                ["need_states", "expressions", "pair_doc_frequency", "need_states_doc_freq", "expressions_doc_freq"]
            ].copy()
            graph_df.drop_duplicates(inplace=True)
            graph_df["need_states_token_count"] = graph_df["need_states"].apply(lambda x: len(x.split()))
            graph_df["expressions_token_count"] = graph_df["expressions"].apply(lambda x: len(x.split()))

            graph_df = graph_df[graph_df["need_states"] != graph_df["expressions"]].reset_index(drop=True)
            graph_df = graph_df[graph_df["need_states"] != "None"].reset_index(drop=True)
            graph_df = graph_df[graph_df["expressions"] != "None"].reset_index(drop=True)

            if graph_filtering:
                graph_df = self._filter_graph_df(
                    graph_df, need_states_doc_freq_cutoff, expressions_doc_freq_cutoff, pair_doc_frequency_cutoff
                )

            end = time.time()
            self.logger.info(f"Graph aggregate view generated, Total runtime {end - begin}")

            # ---------------------------------------------------------------------------------
            # drop unigram "BENEFIT", "OCCASION", "OTHER" need state and expression

            # identify need_states spans
            graph_df = pd.merge(
                graph_df,
                mapping_df[[mapping_df_span_col] + need_states],
                left_on="need_states",
                right_on=mapping_df_span_col,
                how="left",
            )

            graph_df.drop([mapping_df_span_col], axis=1, inplace=True)
            if graph_df.isna().sum().sum() > 0:
                self.logger.warning(
                    f"All need state column spans from the inference data were not mapped to need states flag in mapping df. Summary of NA records is {graph_df.isna().sum()}"
                )
            graph_df.fillna(0, inplace=True)

            # identify expression spans
            graph_df = pd.merge(
                graph_df,
                mapping_df[[mapping_df_span_col] + expressions],
                left_on="expressions",
                right_on=mapping_df_span_col,
                how="left",
            )
            graph_df.drop([mapping_df_span_col], axis=1, inplace=True)
            if graph_df.isna().sum().sum() > 0:
                self.logger.warning(
                    f"All expression column spans from the inference data were not mapped to expressions flag in mapping df. Summary of NA records is {graph_df.isna().sum()}"
                )
            graph_df.fillna(0, inplace=True)

            drop_need_state = set(drop_unigram_spans).intersection(set(need_states))
            drop_expression = set(drop_unigram_spans).intersection(set(expressions))

            records_dropped = 0
            records_original = graph_df.shape[0]
            if len(drop_need_state) > 0:
                self.logger.info(f"Dropping unigrams need states associated with {drop_need_state}")
                for col in drop_need_state:
                    graph_df["to_drop"] = np.where((graph_df["need_states_token_count"] <= 1) & (graph_df[col] == 1), 1, 0)
                    records_dropped = records_dropped + graph_df[graph_df["to_drop"] == 1].shape[0]
                    graph_df = graph_df[graph_df["to_drop"] == 0]
                del graph_df["to_drop"]

            if len(drop_expression) > 0:
                self.logger.info(f"Dropping unigrams expressions associated with {drop_expression}")
                for col in drop_expression:
                    graph_df["to_drop"] = np.where((graph_df["expressions_token_count"] <= 1) & (graph_df[col] == 1), 1, 0)
                    records_dropped = records_dropped + graph_df[graph_df["to_drop"] == 1].shape[0]
                    graph_df = graph_df[graph_df["to_drop"] == 0]
                del graph_df["to_drop"]

            self.logger.warning(
                f"Dropped {records_dropped}, {np.round(100*records_dropped/records_original,2)}% number of records out of {records_original} orignal records due unigram spans"
            )

            # ---------------------------------------------------------------------------------
            begin = time.time()
            self.logger.info("Graph Clubbing Started")

            need_states_clubbing_mapping_df = self._need_states_clubbing(graph_df)
            need_states_clubbing_mapping_dic = dict(
                need_states_clubbing_mapping_df[["List_of_phrases", "Clubbed_name"]].explode("List_of_phrases").values
            )
            graph_df_columns_list = list(graph_df.columns)
            graph_df["Clubbed Need states"] = graph_df["need_states"].apply(lambda a: need_states_clubbing_mapping_dic[a])
            graph_df = graph_df[["Clubbed Need states"] + graph_df_columns_list]

            end = time.time()
            self.logger.info(f"Graph Clubbing Completed, Total runtime {end - begin}")

            # ---------------------------------------------------------------------------------
            need_states_and_expressions_df = graph_df.copy()
            need_states_and_expressions_df.drop_duplicates(inplace=True)

            need_states_and_expressions_df["unmapped_ns"] = need_states_and_expressions_df[need_states].max(axis=1)
            need_states_and_expressions_df["unmapped_exp"] = need_states_and_expressions_df[expressions].max(axis=1)

            df_unmapped = need_states_and_expressions_df[need_states_and_expressions_df["unmapped_ns"] == 0]
            if df_unmapped.shape[0] > 0:
                self.logger.warning(
                    f"All need state column spans from the inference data were not mapped to need states flag in mapping df. Missing need state mappings are {df_unmapped['need_states'].unique()}"
                )

            df_unmapped = need_states_and_expressions_df[need_states_and_expressions_df["unmapped_exp"] == 0]
            if df_unmapped.shape[0] > 0:
                self.logger.warning(
                    f"All expression column spans from the inference data were not mapped to need states flag in mapping df. Missing need state mappings are {df_unmapped['expressions'].unique()}"
                )

            need_states_and_expressions_df = need_states_and_expressions_df[need_states_and_expressions_df["unmapped_ns"] == 1]
            need_states_and_expressions_df = need_states_and_expressions_df[need_states_and_expressions_df["unmapped_exp"] == 1]
            need_states_and_expressions_df.drop(["unmapped_ns", "unmapped_exp"], axis=1, inplace=True)

            need_states_and_expressions_df.rename(
                columns={
                    "need_states": "Need states",
                    "expressions": "Expressions",
                    "need_states_doc_freq": "Doc freq(Need states)",
                    "expressions_doc_freq": "Doc freq(Expressions)",
                },
                inplace=True,
            )

            need_states_and_expressions_df.drop_duplicates(inplace=True)
            need_states_and_expressions_df["# Expressions"] = need_states_and_expressions_df.groupby(["Need states"])[
                "Expressions"
            ].transform("nunique")
            need_states_and_expressions_df["# Need states"] = need_states_and_expressions_df.groupby(["Expressions"])[
                "Need states"
            ].transform("nunique")

            need_states_and_expressions_df.reset_index(drop=True, inplace=True)

            return (text_nouns, need_states_clubbing_mapping_df, need_states_and_expressions_df)

        except Exception as e:
            self.logger.error(f"Following error occured while creating co-occurence network graph {e}")

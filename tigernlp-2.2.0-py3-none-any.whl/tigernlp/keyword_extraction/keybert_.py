import numpy as np
import pandas as pd
from keybert import KeyBERT
from typing import Union

from tigernlp.core.utils import MyLogger, k_func, rank_func


class KeyBertScorer:
    """Keyword extraction utility using KeyBert algorithm.

    Generates and ranks n-gram keywords present in the document using the KeyBert algorithm.
    Feature `n_gram_range` can be used to get unigram, bigram, or trigram keywords.

    For example, a ngram_range of (1, 1) means only unigrams, (1, 2) means unigrams and bigrams, and (2, 2) means only bigrams.

    Parameters
    ----------
    log_level: str, optional
        Level or severity of the events needed to be tracked, by default "INFO"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.keyword_extraction.api import KeyBertScorer
    >>> text_for_keyword_extraction = ["Four Lessons From Running A Business During The Pandemic", "My latest for @Forbes: The pandemic has transformed my company"]
    >>> score_class_object = KeyBertScorer()
    >>> df_ke = score_class_object.score(input_text=text_for_keyword_extraction, n_gram_range=(1,3), top_n=5)
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """KeyBertScorer class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _extract_keyBert_keywords(self, kw_model):
        """Extract n-gram keywords from the text document using KeyBERT algorithm

        Parameters
        ----------
        kw_model : model object
            keybert model instance

        Returns
        -------
        pd.DataFrame
            Dataframe with keyword phrases as columns
        """

        keywords = kw_model.extract_keywords(
            docs=self.input_text,
            keyphrase_ngram_range=self.n_gram_range,
            stop_words=self.language,
            top_n=self.top_n,
            min_df=self.min_df,
            use_maxsum=self.use_maxsum,
            nr_candidates=self.nr_candidates,
            use_mmr=self.use_mmr,
            diversity=self.diversity,
        )

        if isinstance(self.input_text, str):
            keywords = [keywords]

        keybert_df = pd.DataFrame(keywords)
        self.logger.info("KeyBERT keywords extraction completed")
        return keybert_df

    def _KeyBERT_func(self, kw_model):
        """Function to extract keywords and map the respective keybert score.

        Parameters
        ----------
        kw_model : str
            keybert model instance

        Returns
        -------
        pd.DataFrame
            Dataframe containing appended keyword phrases and respective cosine similarity scores as columns
        """
        keybert_df = self._extract_keyBert_keywords(kw_model)
        keybert_df = keybert_df.melt()
        keybert_df = keybert_df[~keybert_df["value"].isna()]
        keybert_df = keybert_df[keybert_df["value"] != "None Found"].reset_index(drop=True)
        keybert_df.drop(["variable"], axis=1, inplace=True)
        keybert_df.columns = ["keyword_score"]
        keybert_df["keyword"] = keybert_df.apply(lambda a: a["keyword_score"][0], axis=1)
        keybert_df["score"] = keybert_df.apply(lambda a: a["keyword_score"][1], axis=1)
        keybert_df = (
            keybert_df.groupby(["keyword"])["score"]
            .mean()
            .reset_index()
            .sort_values(["score"], ascending=False)
            .reset_index(drop=True)[0 : int(self.top_n)]
        )
        # main_keybert_df = pd.concat([main_keybert_df, keybert_df])
        self.logger.info("KeyBERT keywords extraction completed")
        return keybert_df

    def _KeyBert(self, model):
        """Function to get create KeyBert model instance using the pre-trained sentence transformer embedding model

        Parameters
        ----------
        model : str
            pre-trained sentence-transformer (https://huggingface.co/sentence-transformers) embedding model name for KeyBert.
            Example - "all-MiniLM-L6-v2"

        Returns
        -------
        model object
            Keybert model instance using pre-trained sentence transformer embedding model
        """
        self.logger.info(f'sentence embedding model used for KeyBert: "{model}"')
        kw_model = KeyBERT(model=model)
        return kw_model

    def score(
        self,
        input_text: Union[str, list] = list(),
        n_gram_range=(1, 3),
        use_mmr=False,
        diversity=0.5,
        use_maxsum=False,
        nr_candidates=20,
        top_n=5,
        min_df=1,
        language="english",
        key_bert_model="all-MiniLM-L6-v2",
    ):
        """Orchestrates end-to-end keyword extraction pipeline using keyBERT.

        Parameters
        ----------
        input_text : Union[str, list]
            string or list of documents to be used for keyword extraction
        n_gram_range : tuple(int,int), optional
            The lower and upper boundary of the range of n-values for different word n-grams or char n-grams to be extracted, by default (1,3).
            All values of n such that min_n <= n <= max_n will be used.

            For example, a ngram_range of (1, 1) means only unigrams, (1, 2) means unigrams and bigrams, and (2, 2) means only bigrams
        use_mmr : bool, optional
            Whether to use Maximal Marginal Relevance (MMR) for the selection of keywords/keyphrases, by default False
        diversity : float, optional
            The diversity of the results between 0 and 1 if use_mmr is set to True, by default 0.5
        use_maxsum : bool, optional
            Whether to use Max Sum Similarity for the selection of keywords/keyphrases, by default False
        nr_candidates : int, optional
            The number of candidates to consider if use_maxsum is set to True, by default 20
        top_n : int, optional
            Return the top n keywords/keyphrases, by default 5
        min_df : int, optional
            Minimum document frequency of a word across all documents if keywords for multiple documents need to be extracted, by default 1
        language : str, optional
            language of stopwords or manual list of stopwords to be removed, by default 'english'
            Example - ['collected', 'cat']
        key_bert_model : str, optional
            pre-trained sentence-transformer (https://huggingface.co/sentence-transformers) embedding model name for KeyBert, by default "all-MiniLM-L6-v2"

        Returns
        -------
        pd.DataFrame
            Dataframe containing keyword phrases, cosine similarity score, keyword rank and concatenated keyword score value as columns

            columns - "keyword", "score", "rank", "k_s"

            Example: keyword - "phone number", score - 0.57, rank - 5, k_s - (phone number, 0.57)
        """

        try:
            self.logger.info("Keyword Extraction using KeyBert started")

            self.input_text = input_text
            self.n_gram_range = n_gram_range
            self.use_mmr = use_mmr
            self.diversity = diversity
            self.use_maxsum = use_maxsum
            self.nr_candidates = nr_candidates
            self.top_n = top_n
            self.min_df = min_df
            self.language = language

            if not isinstance(input_text, str) and not isinstance(input_text, list):
                raise ValueError(f"Incorrect input text type - {type(input_text)}")

            kw_model = self._KeyBert(key_bert_model)

            main_keybert_df = pd.DataFrame()

            main_keybert_df = self._KeyBERT_func(kw_model)

            main_keybert_df = main_keybert_df.reset_index(drop=True)
            main_keybert_df["score"] = main_keybert_df["score"].astype("float")
            main_keybert_df["score"] = np.round(main_keybert_df["score"], 5)
            main_keybert_df["k_s"] = main_keybert_df.apply(lambda a: k_func(a), axis=1)
            main_keybert_df = rank_func(main_keybert_df)
            main_keybert_df["keyword_joined"] = main_keybert_df["keyword"].apply(lambda x: "_".join(x.split()))

            self.logger.info("KeyBERT feature rank and score added")
            self.logger.info("Keyword extraction using KeyBert completed")

            main_keybert_df.reset_index(inplace=True, drop=True)

            return main_keybert_df

        except Exception as e:
            self.logger.error(f"Error occurred while using KeyBert {e}")

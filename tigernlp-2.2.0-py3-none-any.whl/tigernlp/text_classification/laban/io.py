import joblib
import os
from tqdm import tqdm


def save_config(config, path: str, name: str):
    """
    Add attributes in config to a dictionary and save it.

    Parameters
    ----------
    config : _type_
        Config class containing default configuration
    path : str
        Location to save config
    name : str
        Name of file without extension, preferably same as model name
    """
    # TODO: Type hinting for class
    if not os.path.isdir(path):
        os.makedirs(path)

    name, _ = os.path.splitext(name)

    config_dict = {
        attr: getattr(config, attr) for attr in dir(config) if not attr.startswith("__")
    }

    joblib.dump(config_dict, os.path.join(path, f"{name}.pkl"))


def load_config(path: str, name: str):
    """
    Load config dict from file and set it to Config class

    Parameters
    ----------
    path : str
        Location of config file
    name: str
        Name of config file without extension

    Returns
    -------
    Config
        Config object

    Raises
    ------
    ValueError
        Config file doesn't exist at path
    """
    # TODO: Type hinting for class
    # Load config dictionary
    if not os.path.isfile(os.path.join(path, f"{name}.pkl")):
        raise ValueError(f'File doesn\'t exist at {os.path.join(path, f"{name}.pkl")}')
    config_dict = joblib.load(os.path.join(path, f"{name}.pkl"))

    # Create Config class
    class Config:
        pass

    config = Config()

    # Set key value pairs from dict into config attributes
    for key, value in config_dict.items():
        setattr(config, key, value)

    return config


def save_dataset(save_path: str, **kwargs):
    """
    Saves dataset to a folder specified.
    All datasets can be passed as kwargs and will be saved with same name provided as parameter.

    Parameters
    ----------
    save_path : str
        Path to save dataset

    Example
    -------
    >>> save_dataset(
            save_path='path/to/dataset',
            train=train,
            test=test
        )
    """
    if not os.path.isdir(save_path):
        os.makedirs(save_path)
    for data_name, data in tqdm(kwargs.items(), total=len(kwargs)):
        joblib.dump(data, os.path.join(save_path, f"{data_name}.pkl"))


def load_dataset(*args, load_path: str):
    """
    Loads dataset from given path.
    Multiple args can be passed at the start to be loaded.
    They need to be string name of the datasets without extension.

    Parameters
    ----------
    load_path : str
        Path of the datasets to load

    Example
    -------
    >>> train, test = load_dataset('train', 'test', load_path='path/to/dataset')

    Raises
    ------
    ValueError
        If load_path doesn't exist
    ValueError
        If args provided are not string
    ValueError
        If file doesn't exist at load_path
    """
    if not os.path.isdir(load_path):
        raise ValueError(f"Path {load_path} doesn't exist.")

    data = []
    for arg in tqdm(args):
        if not isinstance(arg, str):
            raise ValueError(
                f"Expected arguments to be strings (filename) got {type(arg)} instead."
            )
        filename, ext = os.path.splitext(arg)
        if not ext:
            ext = ".pkl"
        if not os.path.isfile(os.path.join(load_path, filename + ext)):
            raise ValueError(f"File {filename+ext} doesn't exist at {load_path}")
        data.append(joblib.load(os.path.join(load_path, filename + ext)))

    return data

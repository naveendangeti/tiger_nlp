import numpy as np
import os
import torch
from transformers import BertConfig, BertTokenizer
from typing import Tuple, Union

from tigernlp.core.utils import MyLogger

from .io import load_config, load_dataset
from .model import BertZSL
from .utils import pad_data


class InferenceModel:
    """
    This class implements usecases of Laban label detection and contains the functions to process the outputs
    from the model and predict the labels for given sentence.

    Parameters
    ----------
    model_load_path : str
        Path to load trained model (Only path, not model name)
    model_load_name : str
        Model name
    data_path : str, optional
        Directory path to load the labels on which model was trained.
    config_file_path : str, optional
        Config file name is assumed to be same as model load path with same name, else provide full path, by default None
    verbose : str, optional
        Show print statements of model loading status

    Example
    -------
    >>> from tigernlp.text_classification.api import LABANInferenceModel
    >>> model_path = "D:/path/to/model"
    >>> model_name = "efficient-smoke-2"
    >>> label_path = "D:/path/to/labels"
    >>> inference_object = LABANInferenceModel(
        model_load_path=model_path,
        model_load_name=model_name,
        data_path=label_path
    )

    Raises
    ------
    ValueError
        Path provided for loading model doesn't exist
    """

    def __init__(
        self,
        model_load_path: str,
        model_load_name: str,
        train_label_dict: str,
        data_path: str = None,
        config_file_path: str = None,
        verbose: bool = True,
    ):
        """
        Initializes the data and configuration required for the model and loads the model to generates the label predictions.

        Parameters
        ----------
        model_load_path : str
            Path to load trained model (Only path, not model name)
        model_load_name : str
            Model name
        train_label_dict : str
            Name of the train label dictionary file (containing label as key, and a tuple of its index and tokenized form as value) when train and test folders are saved.
        data_path : str, optional
            Directory path to load the labels on which model was trained.
        config_file_path : str, optional
            Config file name is assumed to be same as model load path with same name, else provide full path, by default None
        verbose : str, optional
            Show print statements of model loading status

        Example
        -------
        >>> from tigernlp.text_classification.api import LABANInferenceModel
        >>> model_path = "D:/path/to/model"
        >>> model_name = "efficient-smoke-2"
        >>> label_path = "D:/path/to/labels"
        >>> inference_object = LABANInferenceModel(
            model_load_path=model_path,
            model_load_name=model_name,
            data_path=label_path
        )

        Raises
        ------
        ValueError
            Path provided for loading model doesn't exist
        """
        logger = MyLogger().logger
        # Remove model extension from name
        model_load_name, _ = os.path.splitext(model_load_name)

        # Raise errors if model path or config file doesn't exist
        if not os.path.isdir(model_load_path):
            raise ValueError(f"Path doesn't exist at {model_load_path}")
        if config_file_path is None:
            config_file_path = model_load_path
            _config_file_name = model_load_name
        else:
            _config_file_name = os.path.basename(config_file_path)
            config_file_path = os.path.dirname(config_file_path)

        self.device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        # Load config
        self.config = load_config(config_file_path, _config_file_name)
        if verbose:
            logger.info("Loaded Config")
        # Load train

        if not data_path:
            load_path = os.path.join(self.config.DATA_SAVE_PATH, self.config.DATA_VERSION)
        else:
            load_path = data_path

        self.train_label_dict = load_dataset(
            train_label_dict,
            load_path=load_path,
        )[0]
        if verbose:
            logger.info("Loaded labels")
        # Initialize bert tokenizer
        self._init_tokenizer()
        if verbose:
            logger.info("Loaded Tokenizer")
        # Get label token ids, label token names and mask tokens
        self.label_tokens, self.label_token_names, self.mask_tokens = self._process_labels()
        # Load model
        self.model = self._load_model()
        if verbose:
            logger.info("Loaded Model")

    def _init_tokenizer(self, bert_name: str = "bert-base-uncased"):
        """
        Initialize Bert tokenizer to encode text and labels

        Parameters
        ----------
        bert_name : str, optional
            Bert vocab file name, by default "bert-base-uncased"
        """
        self.tokenizer = BertTokenizer.from_pretrained(bert_name, do_lower_case=True)

    def _load_model(self):
        """
        Load trained model

        Returns
        -------
        Model
            Trained bert model
        """
        bert_config = BertConfig(
            vocab_size_or_config_json_file=self.config.BERT_VOCAB_SIZE,
            hidden_size=self.config.BERT_HIDDEN_SIZE,
            num_hidden_layers=self.config.BERT_NUM_HIDDEN_LAYERS,
            num_attention_heads=self.config.BERT_NUM_ATTENTION_HEADS,
            intermediate_size=self.config.BERT_INTERMEDIATE_SIZE,
        )
        model = BertZSL(
            bert_config,
            model_name=self.config.MODEL_NAME,
            model_path_name=self.config.MODEL_PATH_NAME,
            surface_encoder_method=self.config.SURFACE_ENCODER_METHOD,
            label_aware_layer_method=self.config.LABEL_AWARE_LAYER_METHOD,
            num_labels=len(self.train_label_dict),
        )

        model.load_state_dict(
            torch.load(
                os.path.join(self.config.MODEL_SAVE_PATH, self.config.MODEL_SAVE_NAME),
                map_location=self.device,
            )
        )
        model = model.to(self.device)
        model.eval()
        return model

    def _process_labels(self) -> Tuple[list, list, list]:
        """
        Process all labels to return a list of label names, token ids and masks.
        Will be done only once when initializing class

        Returns
        -------
        Tuple[list, list, list]
            label names, token ids and masks
        """
        label_token_names = [label for (label, _) in self.train_label_dict.items()]
        label_tokens_ids = [
            self.tokenizer.convert_tokens_to_ids(self.tokenizer.tokenize(label))
            for label in label_token_names
        ]
        label_tok, mask_tok = pad_data(label_tokens_ids, self.config.LABEL_PAD_LENGTH)
        label_tokens = (
            torch.zeros(len(label_tok), self.config.LABEL_PAD_LENGTH).long().to(self.device)
        )
        mask_tokens = (
            torch.zeros(len(mask_tok), self.config.LABEL_PAD_LENGTH).long().to(self.device)
        )
        for i in range(len(label_tok)):
            label_tokens[i] = torch.tensor(label_tok[i])
        for i in range(len(mask_tok)):
            mask_tokens[i] = torch.tensor(mask_tok[i])
        return label_tokens, label_token_names, mask_tokens

    def _process_data(self, text: Union[str, list]) -> Tuple[torch.tensor, torch.tensor]:
        """
        Process text data by tokenizing, getting respective ids from bert, padding and return padded token ids, masks for text

        Parameters
        ----------
        text : str | list
            Text to be preprocessed

        Returns
        -------
        Tuple[torch.tensor, torch.tensor]
            Token ids for text, masks for text
        """

        if isinstance(text, str):
            X = self.tokenizer.tokenize(text)
            X, mask_data = pad_data(
                [self.tokenizer.convert_tokens_to_ids(X)], self.config.UTTERANCE_PAD_LENGTH
            )

        if isinstance(text, list):
            text_list = [
                self.tokenizer.convert_tokens_to_ids(i)
                for i in [self.tokenizer.tokenize(x) for x in text]
            ]
            X, mask_data = pad_data(text_list, self.config.UTTERANCE_PAD_LENGTH)

        return torch.tensor(X), torch.tensor(mask_data)

    def predict(
        self,
        text: Union[str, list],
        top_n: int = 1,
        multilabel: bool = False,
    ) -> Union[Tuple[str, float], Tuple[Tuple[str, float], ...]]:
        """
        Predict label for a given text.

        Parameters
        ----------
        text : str | list
            Text or list of texts to predict label for
        top_n : int, optional
            Top n predictions, by default 1
        multilabel : bool, optional
            Wether to predict multiple label for given sentence or not. By default `False`.

        Returns
        -------
        Union[Tuple[str, float], Tuple[Tuple[str, float], ...]]
            If `top_n = 1` returns label as string and probability score as float.
            For all other values of top_n, returns a tuple of size top_n containing label as string and probability score as float.
            If list of texts is provided, returns list of dictionaries containing the texts as keys and tuple of tuples with labels
            and respective probabilities.

        Raises
        ------
        ValueError
            If top_n is less than or equal to zero
        ValueError
            If top_n is not an integer
        """

        if top_n <= 0:
            raise ValueError("Expected top_n to be greater than 0.")
        if not isinstance(top_n, int):
            raise ValueError(f"top_n is expected to be an integer, received {type(top_n)}")

        if not isinstance(text, (str, list)):
            raise ValueError(
                f"parameter `text` is expected to be a string or list of strings, received {type(text)}"
            )

        # Process text to required format
        captions, masks = self._process_data(text)
        # Set texts and masks to device
        captions = captions.to(self.device)
        masks = masks.to(self.device)

        # Get predictions
        with torch.no_grad():
            _, _, outputs = self.model(captions, masks, self.label_tokens, self.mask_tokens)

        # Run through softmax to get probabilities
        # Sigmoid can be used as well for multi label scenario
        if multilabel:
            outputs = torch.sigmoid(outputs)
        else:
            outputs = torch.softmax(outputs, dim=1)

        probs, outs = torch.topk(outputs, top_n)

        if isinstance(text, str):
            if top_n == 1:
                prob, outputs = torch.max(outputs, dim=1)
                return self.label_token_names[outputs.item()], round(prob.item(), 3)

            return tuple(
                zip(
                    [self.label_token_names[idx] for idx in outs.cpu().numpy()[0]],
                    np.around(probs.cpu().numpy()[0], 3),
                )
            )

        if isinstance(text, list):
            outs = outs.numpy().tolist()
            probs = probs.numpy().tolist()

            all_labels = []
            for i in outs:
                labels = [self.label_token_names[idx] for idx in i]
                all_labels.append(labels)

            output = []
            for i in range(len(text)):
                label_prob = tuple(zip(all_labels[i], np.around(probs[i], 3)))
                label_prob = {text[i]: label_prob}
                output.append(label_prob)

            return output

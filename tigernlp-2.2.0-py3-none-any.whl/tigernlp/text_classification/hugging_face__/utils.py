# Importing the external libraries
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.preprocessing import MultiLabelBinarizer
from transformers import AutoTokenizer, EvalPrediction, set_seed

set_seed(2022)


def label_text_definition(df, text="Text", label=None, problem_type="single_label_classification"):
    """
    This function is used to define the labels and text columns
    in the dataset.

    Parameters
    ----------
    df: pandas dataframe
        the dataset containing the texts and labels
    text: str
        the text column which needs to be classified
    label: str, optional
        the column with labels in it
    problem_type: str, optional
        string defining which type of classification to solve, default:"single_label_classification"

    Returns
    -------
    lb_ls = list
        list of values in label column
    txt = list
        list of values in text column

    Example
    --------
    >>> from tigernlp.text_classification.api import utils
    >>> import pandas as pd
    >>> df = pd.read_csv ('sentiment_analysis_sample_data_binary_class.csv')
    >>> lb_ls, txt = utils.label_text_definition(df, label = "sentiment", text = "text")
    """
    if type(df) != pd.core.frame.DataFrame:
        raise TypeError("df is not a pandas dataframe and its datatype is " + str(type(df)))
    else:
        if all(isinstance(item, str) for item in df[text]):
            if label is None:
                txt = df[text].to_list()
                return txt
            elif type(label) == list:
                lb_ls = []
                for x in range(len(df)):
                    ls_2 = []
                    for y in label:
                        ls_2.append(df[y][x])
                    lb_ls.append(ls_2)
                txt = df[text].to_list()
                return lb_ls, txt

            elif problem_type == "multi_label_classification":
                # Checking is each str item is list or not
                if all(isinstance(item, str) for item in df[label]) and all(
                    isinstance(item, list)
                    for item in [
                        (sublist.strip("][").replace(" ", "").split(",")) for sublist in df[label]
                    ]
                ):
                    lb_ls = [
                        (sublist.strip("][").replace(" ", "").split(",")) for sublist in df[label]
                    ]
                    # Converting the nest list column into one hot encoding
                    mlb = MultiLabelBinarizer()
                    lb_ls = pd.DataFrame(
                        mlb.fit_transform(lb_ls), columns=mlb.classes_
                    ).values.tolist()
                    txt = df[text].to_list()
                    return lb_ls, txt

                elif all(isinstance(item, list) for item in df[label]):
                    mlb = MultiLabelBinarizer()
                    lb_ls = pd.DataFrame(
                        mlb.fit_transform(df[label]), columns=mlb.classes_
                    ).values.tolist()
                    txt = df[text].to_list()
                    return lb_ls, txt
                else:
                    raise TypeError("The label column is in string format")

            else:
                if (
                    all(isinstance(item, int) for item in df[label])
                    and (
                        sorted(list(set(df[label].to_list())))
                        == list(
                            range(
                                min(list(set(df[label].to_list()))),
                                max(list(set(df[label].to_list()))) + 1,
                            )
                        )
                    )
                    and (min(list(set(df[label].to_list()))) == 0)
                ):  # Checking if the unique labels are a consecutive list of numbers starting with zero and are integers
                    lb_ls = df[label].to_list()
                    txt = df[text].to_list()
                    return lb_ls, txt
                else:
                    raise TypeError(
                        "The unique labels are not a consecutive list"
                        + " of numbers in the label column starting with zero"
                        + " or are not integers"
                    )
        else:
            raise TypeError("The text column doesn't contain any strings.")


def create_tokenizer_object(model_type="all-MiniLM-L6-v2"):
    """
    Function to create/initialize a tokenizer object
    for huggingface models.

    Parameters
    -----------
    model_type: str, optional
        name or link or url for the type of model to be used to create embedding, default: 'all-MiniLM-L6-v2'

    Returns
    --------
    model: tokenizer model object
        huggingface sentence tokenizer object, by default None

    Other pre trained models supported:
    -----------------------------------
    - all-MiniLM-L6-v2
    - all-MiniLM-L12-v1
    - sentence-t5-base
    - bert-base-uncased
    - roberta-large
    - many more (visit:  https://huggingface.co/sentence-transformers)

    Example:
    >>> from tigernlp.text_classification.api import utils
    >>> tokenizer = create_tokenizer_object(model_type = "roberta-large")
    """
    # Load model from HuggingFace Hub
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_type)

    except Exception:
        try:
            tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/" + model_type)

        except Exception as e:
            return print(f"Model type selected couldn't be found on Huggingface.co{e}")

    if model_type == "gpt2":
        tokenizer.padding_side = "left"
        tokenizer.pad_token = tokenizer.eos_token
        return tokenizer

    return tokenizer


def create_tokens(
    text,
    tokenizer=None,
    pad=True,
    trnc=True,
    max_length=100,
    tensor_type="pt",
):
    """
    Function to create text embeddings using the huggingface transformer
    library

    Parameters:
    -----------
    text: list
        list of texts
    tokenizer: tokenizer object
        huggingface tokenizer
    pad: logical, optional
        Flag for enabling padding , default: True
    trnc: logical, optional
        Flag for enabling truncation,  default: True
    tensor_type: str, optional
        what type of tensor should it be, default: 'pt'
    max_length: int32, optional
        the max length of the tokens to be input, default: None

    Returns:
    --------
    encoded_input: dictionary
        encoded text into tokens in dictionary

    Example:
    >>> import utils
    >>> import pandas as pd
    >>> from datasets import load_dataset
    >>> imdb = datasets.load_dataset("imdb")
    >>> df = pd.DataFrame(imdb["train"])
    >>> ls = utils.label_text_definition(df, text = "text")
    >>> tokenizer = utils.create_tokenizer_object(model_type = "roberta-large")
    >>> tokenized_ip = utils.create_tokens(ls, tokenizer=tokenizer)
    """

    # Tokenize sentences
    if max_length is None:
        encoded_input = tokenizer(
            text,
            padding=pad,
            truncation=trnc,
            return_tensors=tensor_type,
            max_length=tokenizer.model_max_length,
        )
    else:
        encoded_input = tokenizer(
            text,
            padding=pad,
            truncation=trnc,
            return_tensors=tensor_type,
            max_length=max_length,
        )
    return encoded_input


class create_dataset:
    """
    Returns the dataset needed for autoclass model format for consumption by model
    """

    def __init__(self, encodings, labels, problem_type):
        self.encodings = encodings
        self.labels = labels
        self.problem_type = problem_type

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        if self.problem_type == "single_label_classification":
            item["labels"] = torch.tensor(self.labels[idx])
        if self.problem_type == "multi_label_classification":
            item["labels"] = torch.tensor(self.labels[idx], dtype=torch.float32)
        return item

    def __len__(self):
        return len(self.labels)


def eval_metrics_trainer(predictions, labels, problem_type, num_labels, prob_threshold=0.5):
    """
    This function is used to create the evaluation metrics based on
    a classification trainer model

    Parameters:
    -----------
    predictions: list
        classification predictions
    labels: list
        True labels
    problem_type: str
        type of the classification problem
    num_labels: int32
        number of labels for the classification problem
    prob_threshold: float32, optional
        probability threshold above which the prediction is considered positive, default: 0.5

    Output:
    -------
    metrics: dictionary
        dictionary containing the calculated evaluation metrics

    """

    if problem_type == "multi_label_classification":
        sigmoid = torch.nn.Sigmoid()
        probs = sigmoid(torch.Tensor(predictions))
        y_pred = np.zeros(probs.shape)
        y_pred[np.where(probs >= prob_threshold)] = 1

    if problem_type == "single_label_classification" and num_labels > 2:
        y_pred = np.argmax(predictions, axis=-1)
        softmax = torch.nn.Softmax()
        probs = softmax(torch.Tensor(predictions))

    if problem_type == "single_label_classification" and num_labels == 2:
        softmax = torch.nn.Softmax()
        probs = softmax(torch.Tensor(predictions))
        probs = probs[:, 1].tolist()
        y_pred = [1 if i > prob_threshold else 0 for i in probs]

    y_true = labels

    accuracy = accuracy = accuracy_score(y_true, y_pred)
    if problem_type == "single_label_classification" and num_labels == 2:
        f1 = f1_score(y_true=y_true, y_pred=y_pred)
        roc_auc = roc_auc_score(y_true, y_pred)
        precision = precision_score(y_true=y_true, y_pred=y_pred)
        recall = recall_score(y_true=y_true, y_pred=y_pred)

        # return as dictionary
        metrics = {
            "accuracy": accuracy,
            "f1": f1,
            "roc_auc": roc_auc,
            "precision": precision,
            "recall": recall,
        }

    if problem_type == "single_label_classification" and num_labels > 2:
        f1_micro = f1_score(y_true=y_true, y_pred=y_pred, average="micro")
        roc_auc_micro = "Not applicable"
        precision_micro = precision_score(y_true=y_true, y_pred=y_pred, average="micro")
        recall_micro = recall_score(y_true=y_true, y_pred=y_pred, average="micro")

        f1_macro = f1_score(y_true=y_true, y_pred=y_pred, average="macro")
        roc_auc_macro = roc_auc_score(y_true, probs, average="macro", multi_class="ovo")
        precision_macro = precision_score(y_true=y_true, y_pred=y_pred, average="macro")
        recall_macro = recall_score(y_true=y_true, y_pred=y_pred, average="macro")

        f1_weighted = f1_score(y_true=y_true, y_pred=y_pred, average="weighted")
        roc_auc_weighted = roc_auc_score(y_true, probs, average="weighted", multi_class="ovo")
        precision_weighted = precision_score(y_true=y_true, y_pred=y_pred, average="weighted")
        recall_weighted = recall_score(y_true=y_true, y_pred=y_pred, average="weighted")

        # return as dictionary
        metrics = {
            "accuracy": accuracy,
            "f1_micro": f1_micro,
            "roc_auc_micro": roc_auc_micro,
            "precision_micro": precision_micro,
            "recall_micro": recall_micro,
            "f1_macro": f1_macro,
            "roc_auc_macro": roc_auc_macro,
            "precision_macro": precision_macro,
            "recall_macro": recall_macro,
            "f1_weighted": f1_weighted,
            "roc_auc_weighted": roc_auc_weighted,
            "precision_weighted": precision_weighted,
            "recall_weighted": recall_weighted,
        }

    if problem_type == "multi_label_classification":
        f1_micro = f1_score(y_true=y_true, y_pred=y_pred, average="micro")
        roc_auc_micro = roc_auc_score(y_true, probs, average="micro")
        precision_micro = precision_score(y_true=y_true, y_pred=y_pred, average="micro")
        recall_micro = recall_score(y_true=y_true, y_pred=y_pred, average="micro")

        f1_macro = f1_score(y_true=y_true, y_pred=y_pred, average="macro")
        roc_auc_macro = roc_auc_score(y_true, probs, average="macro")
        precision_macro = precision_score(y_true=y_true, y_pred=y_pred, average="macro")
        recall_macro = recall_score(y_true=y_true, y_pred=y_pred, average="macro")

        f1_weighted = f1_score(y_true=y_true, y_pred=y_pred, average="weighted")
        roc_auc_weighted = roc_auc_score(y_true, probs, average="weighted")
        precision_weighted = precision_score(y_true=y_true, y_pred=y_pred, average="weighted")
        recall_weighted = recall_score(y_true=y_true, y_pred=y_pred, average="weighted")

        # return as dictionary
        metrics = {
            "accuracy": accuracy,
            "f1_micro": f1_micro,
            "roc_auc_micro": roc_auc_micro,
            "precision_micro": precision_micro,
            "recall_micro": recall_micro,
            "f1_macro": f1_macro,
            "roc_auc_macro": roc_auc_macro,
            "precision_macro": precision_macro,
            "recall_macro": recall_macro,
            "f1_weighted": f1_weighted,
            "roc_auc_weighted": roc_auc_weighted,
            "precision_weighted": precision_weighted,
            "recall_weighted": recall_weighted,
        }

    return metrics


def compute_metrics_binary_class(eval_preds):
    """
    This function is used to compute metrics for evaluation dataset within trainer object for binary class problems

    Parameters
    ----------
    eval_preds: list
        list containing predicted and true labels

    Returns
    -------
    Computed metrics to trainer object
    """
    logits, labels = eval_preds
    result = eval_metrics_trainer(
        predictions=logits,
        labels=labels,
        problem_type="single_label_classification",
        num_labels=2,
    )
    return result


def compute_metrics_multi_class(eval_preds):
    """
    This function is used to compute metrics for evaluation dataset within trainer object for multi class problems

    Parameters
    ----------
    eval_preds: list
        list containing predicted and true labels

    Returns
    -------
    Computed metrics to trainer object
    """
    logits, labels = eval_preds
    result = eval_metrics_trainer(
        predictions=logits,
        labels=labels,
        problem_type="single_label_classification",
        num_labels=1000,
    )
    return result


def compute_metrics_multi_label(p: EvalPrediction):
    """
    This function is used to compute metrics for evaluation dataset within trainer object for multi label problems

    Parameters
    ----------
    EvalPrediction: list
        list containing predicted and true labels

    Returns
    -------
    Computed metrics to trainer object
    """
    preds = p.predictions[0] if isinstance(p.predictions, tuple) else p.predictions
    result = eval_metrics_trainer(
        predictions=preds,
        labels=p.label_ids,
        problem_type="multi_label_classification",
        num_labels=1000,
    )
    return result


def eval_metrics(y_pred, y_test, y_prob, problem_type, multi_class):
    """
    This function is used to create the evaluation metrics based on predictions from pretrained model

    Parameters:
    -----------
    y_pred: list
        predicted values using model, for multi-label problems, it will be a list of lists of predictions
    y_test: list
        True labels for multi-label problems, it will be a list of lists
    y_prob: list
        predicted probabilities using model, for multi-class and multi-label problems, it will be a list of lists of predictions
    problem_type: str
        type of the classification problem
    multi_class: int32
        if the problem is multi class or not

    Output:
    -------
    metrics: dictionary
        dictionary containing the calculated evaluation metrics

    """
    y_true = y_test
    metrics = {}

    accuracy = accuracy_score(y_true, y_pred)
    if problem_type == "single_label_classification" and multi_class == 0:
        roc_auc = roc_auc_score(y_true, y_pred)
        if type(roc_auc) != str:
            roc_auc = np.round(roc_auc, 2)

        # Code for probability threshold for maximum f1
        precision_1, recall_1, thresholds = precision_recall_curve(y_test, y_prob)
        numerator = 2 * precision_1 * recall_1
        denom = recall_1 + precision_1
        f1_scores = np.divide(numerator, denom, out=np.zeros_like(denom), where=(denom != 0))
        # max_f1 = np.max(f1_scores)
        max_f1_thresh = thresholds[np.argmax(f1_scores)]
        max_f1 = f1_scores[np.argmax(f1_scores)]
        if type(max_f1) != str:
            max_f1 = np.round(max_f1, 2)

        # self.logger.info("Maximum F1 Score is observed for probability threshold of: " + str(max_f1_thresh))

        # return as dictionary
        metrics = {
            "accuracy": np.round(accuracy, 2),
            "roc_auc": roc_auc,
            "prob_threshold_for_max_f1": np.round(max_f1_thresh, 2),
            "max_f1": max_f1,
        }

    if problem_type == "single_label_classification" and multi_class == 1:
        roc_auc_micro = "Not applicable"
        if type(roc_auc_micro) != str:
            roc_auc_micro = np.round(roc_auc_micro, 2)

        try:
            roc_auc_macro = roc_auc_score(y_true, y_prob, average="macro", multi_class="ovo")
            if type(roc_auc_macro) != str:
                roc_auc_macro = np.round(roc_auc_macro, 2)
        except Exception:
            roc_auc_macro = "Not applicable since y_true has only one value"

        try:
            roc_auc_weighted = roc_auc_score(y_true, y_prob, average="weighted", multi_class="ovo")
            if type(roc_auc_weighted) != str:
                roc_auc_weighted = np.round(roc_auc_weighted, 2)
        except Exception:
            roc_auc_weighted = "Not applicable since y_true has only one value"

        # return as dictionary
        metrics = {
            "accuracy": np.round(accuracy, 2),
            "roc_auc_micro": roc_auc_micro,
            "roc_auc_macro": roc_auc_macro,
            "roc_auc_weighted": roc_auc_weighted,
        }

    if problem_type == "multi_label_classification":
        try:
            roc_auc_micro = roc_auc_score(y_true, y_prob, average="micro")
            if type(roc_auc_micro) != str:
                roc_auc_micro = np.round(roc_auc_micro, 2)
        except Exception:
            roc_auc_micro = "Not applicable since y_true has only one value"

        try:
            roc_auc_macro = roc_auc_score(y_true, y_prob, average="macro")
            if type(roc_auc_macro) != str:
                roc_auc_macro = np.round(roc_auc_macro, 2)
        except Exception:
            roc_auc_macro = "Not applicable since y_true has only one value"

        try:
            roc_auc_weighted = roc_auc_score(y_true, y_prob, average="weighted")
            if type(roc_auc_weighted) != str:
                roc_auc_weighted = np.round(roc_auc_weighted, 2)
        except Exception:
            roc_auc_weighted = "Not applicable since y_true has only one value"

        # Code for probability threshold for maximum f1
        macro_thresholds = np.array(range(1, 10)) / 10
        test_f1_macro = []
        for th in macro_thresholds:
            pred = []
            for lst in y_prob:
                lst = [1 if i > th else 0 for i in lst]
                pred.append(lst)
            test_f1_macro1 = f1_score(y_true, pred, average="macro")
            test_f1_macro.append(test_f1_macro1)

        best_macro_th = macro_thresholds[np.argmax(test_f1_macro)]
        best_f1_macro = test_f1_macro[np.argmax(test_f1_macro)]

        micro_thresholds = np.array(range(10)) / 100 + best_macro_th
        test_f1_micro = []
        for th in macro_thresholds:
            pred = []
            for lst in y_prob:
                lst = [1 if i > th else 0 for i in lst]
                pred.append(lst)
            test_f1_micro1 = f1_score(y_true, pred, average="micro")
            test_f1_micro.append(test_f1_micro1)

        best_micro_th = micro_thresholds[np.argmax(test_f1_micro)]
        best_f1_micro = test_f1_micro[np.argmax(test_f1_micro)]

        # return as dictionary
        metrics = {
            "accuracy": np.round(accuracy, 2),
            "roc_auc_micro": roc_auc_micro,
            "roc_auc_macro": roc_auc_macro,
            "roc_auc_weighted": roc_auc_weighted,
            "prob_threshold_for_max_f1_macro": np.round(best_macro_th, 2),
            "max_f1_macro": np.round(best_f1_macro, 2),
            "prob_threshold_for_max_f1_micro": np.round(best_micro_th, 2),
            "max_f1_micro": np.round(best_f1_micro, 2),
        }

    return metrics

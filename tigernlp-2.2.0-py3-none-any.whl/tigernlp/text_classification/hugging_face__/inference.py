import os
import pandas as pd
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoModelForSequenceClassification

from tigernlp.core.utils import MyLogger
from tigernlp.text_classification.hugging_face__ import utils


class create_inference_dataset(torch.utils.data.Dataset):
    def __init__(self, encodings):
        self.encodings = encodings

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        return item

    def __len__(self):
        return len(self.encodings["input_ids"])


class Inference:
    """
    Class to generate the predicted values from NLP classification models

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.text_classification.api import inference
    >>> df = pd.read_csv ('sentiment_analysis_sample_data_binary_class.csv')
    >>> infer = Inference()
    >>> result = infer.generate_inference_output(
    >>>        test_data = df, text="text",
    >>>        model_to_load = "cardiffnlp/twitter-roberta-base-sentiment",
    >>>        model_class_path = None, prob_threshold = 0.5,
    >>>        problem_type = "single_label_classification", batch_size = 32
    >>>    )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """
        Classification Model inference class initialization
        """
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _check_file_exist(path):
        """
        Check if file or path exists
        """
        if (os.path.exists(path)) is False:
            raise Exception("File or Directory does not exist. Use '/' delimter in the path")

    def generate_inference_output(
        self,
        test_data,
        text,
        model_to_load="bert-base-uncased",
        model_class_path=None,
        prob_threshold=0.5,
        problem_type="single_label_classification",
        batch_size=32,
    ):

        """
        This function is used to generate the predicted values from text models

        Parameters
        ----------
        test_data: DataFrame
            Test Data in data frame format. The unlabelled dataset needs to be in the pandas dataframe format with text column in the string format
        text: str
            column name containing text
        model_to_load: str, optional
            pretrained model from huggingface, default: 'bert-base-uncased'.
            This argument should be None in the case of sourcing the model locally from custom trained models
        model_class_path: str, optional
            Local path from which custom trained model objects need to be loaded, default=None, in this case, model if available will be loaded from huggingface
        prob_threshold: float, optional
            User defined probability threshold for binary classification, default=0.5. Will not be considered for multiclass classification
        problem_type: str, optional
            The type of classification we are dealing with, default = "single_label_classification". "multi_label_classification" if it is multi-label.
        batch_size: int, optional
            The number of test data samples utilized in one iteration through the model, default=32

        Returns
        -------
        Dataframe
            Dataframe containing probabilities for each class and predicted class

        Example
        -------
        >>> from tigernlp.text_classification.api import inference
        >>> df = pd.read_csv ('sentiment_analysis_sample_data_binary_class.csv')
        >>> infer = Inference()
        >>> result = infer.generate_inference_output(
        >>>        test_data = df, text="text",
        >>>        model_to_load = "cardiffnlp/twitter-roberta-base-sentiment",
        >>>        model_class_path = None, prob_threshold = 0.5,
        >>>        problem_type = "single_label_classification", batch_size = 32
        >>>    )
        """

        # Check if path and model files exist
        if (model_class_path is not None) and (type(model_class_path) == str):
            if (os.path.exists(model_class_path)) is False:
                raise Exception("File or Directory does not exist. Use '/' delimter in the path")

        # Check probability threshold value limit
        if (prob_threshold < 0) or (prob_threshold > 1):
            raise ValueError("Probability should be in range [0,1]")

        # Problem type check
        if problem_type not in [
            "single_label_classification",
            "multi_label_classification",
        ]:
            raise Exception("problem_type input value should be one of ['single_label_classification', 'multi_label_classification']")

        # Check batch_size type
        if (isinstance(batch_size, int)) is False:
            raise TypeError("batch_size should be integer type")

        # Initializing multi_class to 0, to default to binary classification
        multi_class = 0

        # Extracting text columns from the dataset
        X_test = utils.label_text_definition(test_data, text, label=None)

        # Defining tokenizer object
        if model_class_path is None:
            tokenizer = utils.create_tokenizer_object(model_to_load)
        else:
            tokenizer = utils.create_tokenizer_object(model_class_path)

        # Creating encodings for X_test
        encodings = utils.create_tokens(X_test, tokenizer)

        # Creating dataset from encodings
        test_dataset = create_inference_dataset(encodings)

        # Defining dataloader, batch size for each iteration
        test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size)

        # Defining model object, model_class_path is none for predefined huggingface models
        if model_class_path is None:
            model = AutoModelForSequenceClassification.from_pretrained(model_to_load)
        else:
            model = AutoModelForSequenceClassification.from_pretrained(model_class_path)
            if model_to_load is not None:
                self.logger.info("Model from the path is taken and model_to_load is ignored")

        # use_cuda = torch.cuda.is_available()
        # device = torch.device("cuda" if use_cuda else "cpu")

        # if use_cuda:
        #    model = model.cuda()

        out = pd.DataFrame()
        # Running the model for each batch
        with torch.no_grad():
            # Initializing y_pred for storing model predictions,
            # y_pred, y_pred_binary_format, y_prob_df for storing probabilities
            y_pred, y_pred_binary_format, y_prob_df = [], [], []

            for test_input in tqdm(test_dataloader):

                output = model(**test_input)

                # Calculating probabilities and predicted labels for
                # multi class classification
                if problem_type == "single_label_classification" and multi_class == 1:
                    probabilities = F.softmax(output.logits, dim=1)
                    y_prob_df = y_prob_df + probabilities.tolist()
                    y_pred = y_pred + output.logits.argmax(dim=1).tolist()

                # Calculating probabilities and predicted labels for binary class
                # classification
                if problem_type == "single_label_classification" and multi_class == 0:
                    probabilities = F.softmax(output.logits, dim=1)
                    y_prob_df = y_prob_df + probabilities.tolist()
                    y_pred = y_pred + [1 if i > prob_threshold else 0 for i in probabilities[:, 1].tolist()]

                # Calculating probabilities and predicted labels for multi label classification
                if problem_type == "multi_label_classification":
                    probabilities = torch.sigmoid(output.logits)
                    y_prob_df = y_prob_df + probabilities.tolist()

                    for lst in probabilities.tolist():
                        y_label = []
                        lst = [1 if i > prob_threshold else 0 for i in lst]
                        y_pred_binary_format.append(lst)
                        for i in range(len(lst)):
                            if lst[i] == 1:
                                y_label.append(i)
                        y_pred.append(y_label)

        labels_cr = range(0, len(y_prob_df[0]))
        string_labels = [str(int) for int in labels_cr]
        out = pd.DataFrame(y_prob_df, columns=string_labels)
        out["predicted_label"] = y_pred
        out[text] = test_data[text].tolist()

        return out

import fasttext as ft
import numpy as np
import os
import pandas as pd
import warnings
from typing import List, Union

from tigernlp.core.utils import MyLogger


class FastTextPredictor:
    """Fasttext text classification class

    Parameters
    ----------
    model_load_path: str
        Path to the model bin file with name of file.
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------

    >>> from tigernlp.text_classification.api import FastTextPredictor
    >>> FT = FastTextPredictor(model_load_path = '/project_folder/my_model.bin')
    >>> predicted_label, predicted_probability = FT.predict('This is an example sentence')
    >>> data_frame = FT.predict(data_frame, text_col="text", prediction_col="pred")

    """

    def __init__(
        self,
        model_load_path: str,
        log_level: str = "INFO",
        log_file_path: str = None,
        verbose: bool = True,
    ):
        """FastTextPredictor text classification class initialization

        Parameters
        -----------
        model_load_path: str
            Path to the model bin file with name of file. Example - "project_folder/model/model_version.bin"
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True

        Raises
        ------
        Exception :
            raises exception when it cannot load model.
        OSError :
            raises OS error if no model path is given.

        Example
        -------

        >>> # Loading model
        >>> from tigernlp.text_classification.api import FastTextPredictor
        >>> FT = FastTextPredictor(model_load_path = 'my_model.bin')


        """
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

        # Checking if model path is given
        if model_load_path is not None:
            try:
                self.logger.info("Loading model")
                self.model_load_path = model_load_path
                self._model_loader()
                self.logger.info("Fasttext model loaded.")
            except Exception as e:
                self.logger.error("Error while loading model :", e)
                raise Exception("Error while loading model :", e)
        else:
            self.logger.error("Please provide a model path.")
            raise OSError("Please provide a model path.")

    def predict(
        self,
        text: Union[
            pd.DataFrame,
            str,
            List[
                str,
            ],
        ],
        text_col: str = "",
        prediction_col: str = "pred",
        probability_col: str = "pred_proba",
        model=None,
    ):
        """This function is used for prediction.

        Parameters
        ----------
        text: union[str,pd.DataFrame,list]
            the input dataframe or text strings or list of text strings to do prediction on.
        text_col : str
            name of text/example/utterance column to do prediction on.
        prediction_col : str
            name of output column to catch prediction.
        probability_col : str
            name of output column to catch probabilites for the prediction.

        Returns
        -------
        return one of the following output.
        df : pd.DataFrame
            data output with predicted column and predicted probability column if given text input is of dataframe type.
        str :
            string outputof predicted label and predicted probability for string input if given text input is of str type.
        pred_list : list
            list of tuple with input string and predicted label, predicted_probability if given text input is of list of str type.

        Raises
        ------
        NameError:
            raises name error when the column is not found in the dataframe.
        TypeError:
            raises type error when the input df type is not pd.DataFrame, str, list[str,].

        Example
        -------

        >>> from tigernlp.text_classification.api import FastTextPredictor
        >>> FT = FastTextPredictor(model_load_path = '/project_folder/my_model.bin')
        >>> # Option 1 - if input is string type
        >>> predicted_label, predicted_probability = FT.predict('This is an example sentence')
        >>> # Option 2 - if input is list of string
        >>> list_of_tuples = FT.predict(['This is an example sentence 1','This is an example sentence 2'])
        >>> # Option 3 - if input is dataframe
        >>> df = FT.predict(df, text_col="text", prediction_col="pred")
        >>> # Option 4 - if some other model is to be used
        >>> predicted_label , predicted_probability = FT.predict('This is an example sentence', model=my_model_2)


        """
        try:
            if model is None:
                model = self.model
            if isinstance(text, pd.DataFrame):
                if text_col in text.columns:
                    text["temp"] = text[text_col].apply(
                        lambda x: model.predict(x)
                    )
                    text[probability_col] = text["temp"].apply(
                        lambda x: np.round(float(x[1][0]), 5)
                    )
                    text[prediction_col] = text["temp"].apply(
                        lambda x: x[0][0][9:].replace("-", " ")
                    )
                    text = text.drop(columns="temp")
                else:
                    self.logger.error(f"{text_col} doesn't exists in df.")
                    raise NameError(f"{text_col} doesn't exists in df.")
                return text
            elif isinstance(text, str):
                pr = model.predict(text)
                return pr[0][0][9:].replace("-", " "), np.round(float(pr[1][0]), 5)
            elif isinstance(text, list):
                pred_list = []
                for text in text:
                    if isinstance(text, str):
                        pr = model.predict(text)[0][0][9:].replace("-", " ")
                        pred_list.append(
                            (
                                text,
                                (pr[0][0][9:].replace("-", " "), np.round(float(pr[1][0]), 5)),
                            )
                        )
                    else:
                        warnings.warn("List element not in str format :", text)
                        self.logger.warning("List element not in str format :", text)
                return pred_list
            else:
                self.logger.error("df should be a pd.Dataframe or a str or a list of str.")
                raise TypeError("df should be a pd.Dataframe or a str or a list of str.")
        except Exception as e:
            self.logger.error(f"Error occurred during predicting.\n {e}")
            raise Exception(f"Error occurred during predicting.\n {e}")

    def _model_loader(self):
        """This function loads the model.

        Raises
        ------
        OSError
            raises OSError when model path doen't exist.
        """
        if not os.path.exists(self.model_load_path):
            self.logger.error(f"{self.model_load_path} doesn't exists.")
            raise OSError(f"{self.model_load_path} doesn't exists.")
        self.model = ft.load_model(self.model_load_path)

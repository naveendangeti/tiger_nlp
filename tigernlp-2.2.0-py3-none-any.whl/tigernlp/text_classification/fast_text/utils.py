import numpy as np
import os
import pandas as pd

from tigernlp.core.utils import MyLogger

logger = MyLogger(level="WARNING", log_file_path=None, verbose=True).logger


def data_prep(
    data: pd.DataFrame,
    text_col: str = "text",
    label_col: str = "label",
    file_path_name: str = "file.txt",
):
    """This function is used to prepare data for fasttext classifier training.

    Parameters
    ----------
    data: pd.DataFrame
        data is the training data for fasttext classifier.
    text_col: str
        name of the utterance column ( example sentences against the label ) in data.
    label_col: str
        name of the label column in data.
    file_path_name: str, optional
        path with file name to store file for fasttext classifier training. Example - "project_folder/data/train.txt"

    Raises
    ------
    TypeError:
        raises type error when data is not pd.DataFrame type, utterance_col and label_col is not str format.
    ValueError:
        raises value error if the data is empty or val_size has abnormal value.
    OSError:
        raises os error if the file already exists.
    NameError:
        raises name error if the utterance_col or label_col is not present in data.

    Example
    -------
    >>> from tigernlp.text_classification.api import data_prep
    >>> data_prep(data=train,
    >>>        text_col='Questions',
    >>>        label_col='Doc_name',
    >>>        file_path_name='data/demo_ft/train.txt')


    """
    try:
        if not isinstance(data, pd.DataFrame):
            raise TypeError("data must be in pd.DataFrame format.")
        if (data.empty) or (len(data) == 0) or (len(data.index) == 0):
            raise ValueError("empty dataframe was passed.")
        if os.path.exists(file_path_name):
            raise OSError(f"{file_path_name} already exist.")
        if not isinstance(text_col, str):
            raise TypeError("utterance_col must be in str format.")
        if not isinstance(label_col, str):
            raise TypeError("label_col must be in str format.")
        if text_col not in data.columns:
            raise NameError(f"data doesn't contain {text_col} column.")
        if label_col not in data.columns:
            raise NameError(f"data doesn't contain {label_col} column.")

        len_before = len(data)
        data = data[[text_col, label_col]].drop_duplicates()
        len_after = len(data)
        if len_before != len_after:
            logger.info(f"found duplicates records and removed {len_before-len_after} rows.")
        len_before = len(data)
        data = data.drop_duplicates([text_col])
        len_after = len(data)
        if len_before != len_after:
            logger.info(
                f"found duplicates records in {text_col} column and removed {len_before-len_after} rows."
            )
        if type(data[label_col].iloc[0])!=str:
            data[label_col]=data[label_col].astype(str)
        data[label_col] = data[label_col].apply(lambda x: x.replace(" ", "-"))
        data_prep = "__label__" + data[label_col] + " " + data[text_col]
        f_train = open(file_path_name, "a")
        for i in range(len(np.array(data_prep))):
            f_train.write(np.array(data_prep)[i] + "\n")
        f_train.close()
    except Exception as e:
        logger.error(f"Error occurred during data_prep.\n {e}")
        raise Exception(f"Error occurred during data_prep.\n {e}")

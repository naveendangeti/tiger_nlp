"""
This module contains scripts for data preparation, training, evaluation and inference of Fasttext Module.
"""

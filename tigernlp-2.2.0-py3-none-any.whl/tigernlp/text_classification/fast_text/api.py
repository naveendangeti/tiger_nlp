"""
    Utilities around Fasttext text classification.
    Contains modules to generate dataset, train, evaluate and infer.
"""
from .inference import FastTextPredictor
from .train import FastTextTrainer
from .utils import data_prep

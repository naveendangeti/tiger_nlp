"""
    Utilities around Spacy Text Categorizer.
    Contains modules to generate dataset, train, evaluate and infer spacy Text Categorizer.
"""
from .data_prepare import TextCatSpacyDataPrep
from .inference import TextCatInference
from .train import TextCatTrainer

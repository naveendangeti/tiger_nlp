import numpy as np
import os
import pandas as pd
import spacy
from sklearn.preprocessing import LabelEncoder
from spacy.tokens import DocBin
from tqdm import tqdm
from typing import List, Union

from tigernlp.core.api import spacy_download_validate
from tigernlp.core.utils import MyLogger


class TextCatSpacyDataPrep:
    """The TextCatSpacyDataPrep class is utility class that provides functionalities for preparing data in the spacy format for span categorization.
    It has the following methods

    1. generate_corpus: Generates a corpus in spacy format from a dataframe.

    2. get_encoding: used for converting dataframe with str labels to int labels.

    Parameters
    ----------
    nlp_model : str, optional
        Which spacy language model to use like "en_core_web_sm" etc. None would mean use a blank english model, by default None
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Raises
    ------
    OSError
        If unable to download nlp model from spacy

    Example
    -------
    >>> from tigernlp.text_classification.textcat.api import TextCatSpacyDataPrep
    >>> textcat_dataprep = TextCatSpacyDataPrep()
    >>> df = pd.DataFrame({
    >>>                    'text': ['I like banana',
    >>>                            'This is a sentence about apples.',
    >>>                            'This is a sentence about cellphone.'],
    >>>                    'label': ['FRUIT',
    >>>                            'FRUIT',
    >>>                            'DEVICE'],
    >>>                    })
    >>> df = textcat_dataprep.get_encoding(df,'label')
    >>> df['text']
    >>> ['I like banana','This is a sentence about apples.','This is a sentence about cellphone.']
    >>> df['label']
    >>> ['FRUIT', 'FRUIT', 'DEVICE']
    >>> df['label_enc']
    >>> [0,0,1]
    >>> textcat_dataprep.generate_corpous(texts = df['text'], labels = df['label_enc'], basename = 'train', corpus_path= 'project_folder/data')



    """

    def __init__(
        self,
        nlp_model: str = None,
        log_file_path: str = None,
        log_level: str = "INFO",
        verbose: bool = True,
    ):
        """TextCatSpacyDataPrep class initialization.

        Parameters
        ----------
        nlp_model : str, optional
            Which spacy language model to use like "en_core_web_sm" etc.
            None would mean use a blank english model, by default None
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        Raises
        ------
        OSError
            If unable to download nlp model from spacy

        """
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

        if nlp_model is None:
            # If model specified is None, load a blank English model
            self.nlp = spacy.blank("en")
        else:
            # Else download model required and load
            ret = spacy_download_validate(nlp_model)
            if not ret:
                # TODO: Add a more comprehensive error report
                self.logger.error(f"Unable to download {nlp_model}")
                raise OSError(f"Unable to download {nlp_model}")
            self.nlp = spacy.load(nlp_model)

    def get_encoding(self, df: pd.DataFrame, label_col: str, enc_label_col: str = None):
        """get_encoding is an helper function used for converting dataframe with str labels to int labels.

        Parameters
        ----------
        df: pd.DataFrame
            dataframe without encoded label columns
        label_col: str
            name of label column in dataframe
        enc_label_col: str
            encoded label name to be used. Default None will add "_enc" to the label_col name

        Return
        ------
        df : pd.DataFrame
            Returns pandas dataframe with encoded label column.

        Raises
        ------
        TypeError
            raises type error if df is not dataframe or label is not str or enc_label_col is not str
        ValueError
            raises value error if the df is empty
        NameError
            raises name error if label col is not found in the dataframe

        Example
        -------
        >>> from tigernlp.text_classification.text_cat.api import TextCatSpacyDataPrep
        >>> textcat_dataprep = TextCatSpacyDataPrep()
        >>> df = pd.DataFrame({
        >>>                    'text': ['I like banana',
        >>>                            'This is a sentence about apples.',
        >>>                            'This is a sentence about cellphone.'],
        >>>                    'label': ['FRUIT',
        >>>                            'FRUIT',
        >>>                            'DEVICE'],
        >>>                    })
        >>> df = textcat_dataprep.get_encoding(df,'label')
        >>> df['text']
        >>> ['I like banana','This is a sentence about apples.','This is a sentence about cellphone.']
        >>> df['label']
        >>> ['FRUIT', 'FRUIT', 'DEVICE']
        >>> df['label_enc']
        >>> [0,0,1]



        """
        try:
            labelEncoder = LabelEncoder()
            if not isinstance(df, pd.DataFrame):
                self.logger.error("df must be a pd.DataFrame.")
                raise TypeError("Input df should be of pd.DataFrame type.")
            if not (df.shape[0]) > 0:
                self.logger.error("Input df is empty")
                raise ValueError("Input df is empty")
            if isinstance(label_col, str):
                if label_col not in df.columns:
                    self.logger.error(f"label_col {label_col} not found in input df.")
                    raise NameError(f"label_col {label_col} not found in input df.")
            else:
                self.logger.error("label_col must be of string type.")
                raise TypeError("label_col must be of string type.")
            if enc_label_col is None:
                enc_label_col = label_col + "_enc"
            else:
                if not isinstance(enc_label_col, str):
                    raise TypeError("enc_label_col must be of string type.")
            df[enc_label_col] = labelEncoder.fit_transform(df[label_col])
            self.target_names = labelEncoder.classes_.tolist()
            return df
        except Exception as e:
            self.logger.error(f"Error occurred during encoding labels.\n {e}")
            raise Exception(f"Error occurred during encoding labels.\n {e}")

    def generate_corpous(
        self,
        texts: Union[List[str], np.ndarray],
        labels: Union[List[int], np.ndarray],
        basename: str,
        corpus_path: str,
        target_names: List[str] = None,
        pipe_batch_size: int = 10,
    ):
        """Process data for spacy training and save it.

        Parameters
        ----------
        texts : Union[List[str], np.ndarray]
            List of texts to train
        labels : Union[List[str], np.ndarray]
            List of labels
        basename : str
            name for the generated corpus file. Example - "train", "test", "val"
        corpus_path : str
            Path to save the generated corpus. Example - 'project_folder/data/corpus/'
        target_names : List[str]
            Names of targets ordered by index in labels
        pipe_batch_size : int
            How many texts to batch process with the spacy nlp model to generate docs, by default 10

        Returns
        -------
            The function does not return any value. It saves the corpus in the specified corpus_path.

        Raises
        ------
        Exception
            raises exception if an error occurs during the generation of the corpus.
        TypeError
            raises type error if text is not of Union[List[str], np.ndarray] type.

        Example
        -------
        >>> from tigernlp.text_classification.textcat.api import TextCatSpacyDataPrep
        >>> textcat_dataprep = TextCatSpacyDataPrep()
        >>> df = pd.DataFrame({
        >>>                    'text': ['I like banana',
        >>>                            'This is a sentence about apples.',
        >>>                            'This is a sentence about cellphone.'],
        >>>                    'label': ['FRUIT',
        >>>                            'FRUIT',
        >>>                            'DEVICE'],
        >>>                    })
        >>> df = textcat_dataprep.get_encoding(df,'label')
        >>> df['text']
        >>> ['I like banana','This is a sentence about apples.','This is a sentence about cellphone.']
        >>> df['label']
        >>> ['FRUIT', 'FRUIT', 'DEVICE']
        >>> df['label_enc']
        >>> [0,0,1]
        >>> textcat_dataprep.generate_corpous(texts = df['text'], labels = df['label_enc'], basename = 'train', corpus_path= 'project_folder/data')



        """
        if not (
            isinstance(texts, np.ndarray)
            or isinstance(texts, pd.core.series.Series)
            or isinstance(texts, list)
            or isinstance(texts, str)
        ):
            self.logger.error(
                f"expected string or list of strings or np.ndarray or pd.core.series.Series for texts parameter got {type(texts)}."
            )
            raise TypeError(
                f"expected string or list of strings or np.ndarray or pd.core.series.Series for texts parameter got {type(texts)}."
            )
        if not (isinstance(target_names, list)):
            self.logger.error(
                f"expected list for target_names parameter got {type(target_names)}."
            )
            raise TypeError(f"expected list for target_names parameter got {type(target_names)}.")
        if not isinstance(texts, str):
            if not all(isinstance(item, str) for item in texts):
                self.logger.error("list texts items is of incorrect type.")
                raise TypeError("list texts items is of incorrect type.")
        if not all(isinstance(item, str) for item in target_names):
            self.logger.error("list target_names items is of incorrect type.")
            raise TypeError("list target_names items is of incorrect type.")

        if not os.path.exists(corpus_path):
            os.makedirs(corpus_path)
        try:
            labels = np.array(labels)
            db = DocBin()
            if target_names is None:
                target_names = self.target_names
            target_dict = dict(enumerate(target_names))

            for doc, label in tqdm(
                zip(self.nlp.pipe(texts, batch_size=pipe_batch_size), labels), total=len(texts)
            ):
                # For each doc and label, create a dictionary with target variable depicting 1 if label matches and 0 if not
                doc.cats = {
                    target: (1 if target == target_dict[label] else 0) for target in target_names
                }
                db.add(doc)

            db.to_disk(os.path.join(corpus_path, f"{basename}.spacy"))
        except Exception as e:
            self.logger.error(
                f"An error occurred while generating the corpus in the spacy format. The error message is: {e}."
            )
            raise Exception(
                f"An error occurred while generating the corpus in the spacy format. The error message is: {e}."
            )

import numpy as np
import spacy
from typing import Dict, List, Union

from tigernlp.core.utils import MyLogger


class TextCatInference:
    """TextCatInference class is utility class that provides functionalities for generating config and training text categorization.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "WARNING"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.text_classification.text_cat.api import TextCatInference
    >>> textcat_inference = TextCatInference()
    >>> textcat_inference.predict(model_path='project_folder/model/model-best',text="I like mango")
    >>> [{'DEVICE': 0.06908, 'FRUIT': 0.93092}]
    """

    def __init__(self, log_level="WARNING", log_file_path=None, verbose=True):
        """TextCatInference class initialization.

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        Raises
        ------
        Exception
            raises exception if error occurs while loading mode.
        """
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def predict(
        self, model_path: str, texts: Union[List[str], str], batch_size: int = 10
    ) -> List[Dict[str, float]]:
        """Takes in string or list of strings to return batch output

        Parameters
        ----------
        model_path : str
            Path containing spacy saved model, can be model-best or model-last. Example - "project_folder/model/model-best"
        texts : Union[List[str], str]
            String or list of strings to predict. Example - "I like mango"
        batch_size : int, optional
            Batch size to batch process prediction, by default 10

        Returns
        -------
        List[Dict[str, float]]
            List of dictionaries containing prediction output

        Example
        -------
        >>> from tigernlp.text_classification.text_cat.api import TextCatInference
        >>> textcat_inference = TextCatInference('project_folder/model/model-best')
        >>> textcat_inference.predict(model_path='project_folder/model/model-best',text="I like mango")
        >>> [{'DEVICE': 0.06908, 'FRUIT': 0.93092}]
        """
        try:
            self.nlp = spacy.load(model_path)
        except Exception as e:
            self.logger.error(f"Following error occurred during loading model - {e}")
            raise Exception(f"Following error occurred during loading model - {e}")
        try:
            if isinstance(texts, str):
                texts = [texts]
            cat_list = []
            for doc in self.nlp.pipe(texts, batch_size=batch_size):
                cats = doc.cats
                for cat in cats:
                    cats[cat] = np.round(cats[cat], 5)
                cat_list.append(cats)

            return cat_list
        except Exception as e:
            self.logger.error(f"Error occurred during prediction.\n {e}")
            raise Exception(f"Error occurred during prediction.\n {e}")

"""
This module contains scripts for data preparation, training, evaluation and inference of Spacy Text Categorizer.
"""

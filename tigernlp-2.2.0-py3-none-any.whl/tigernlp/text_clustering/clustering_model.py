import numpy as np
import pandas as pd
import pyLDAvis.gensim_models as gensimvis
import random
from bertopic import BERTopic
from collections import OrderedDict
from hdbscan import HDBSCAN
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer
from umap import UMAP

from tigernlp.core.api import MyLogger, get_db_index, get_silhouette_score, tsne_components
from tigernlp.core.visualization import tsne_2d_visualization, visualize_topics
from tigernlp.embeddings.api import SentenceEmbedding, WordEmbedding

from .hyper_parameter_tuning import HyperParameterTuning
from .utils import (
    action_object_to_text_mapping,
    action_object_to_topic_words_mapping,
    bertopic_compute_coherence_values,
    gsdmm_compute_coherence_values,
    lda_compute_coherence_values,
)


class ClusteringModel:
    """Clusering models utility class.

    Groups a set of unlabelled text document such that similar context documents are in the same cluster.

    Three types of clustering algorithms are available:

    *Option 1*: Gibbs Sampling Dirichlet Multinomial Mixture (GSDMM)
        - This option uses Gibbs sampling algorithm for a Dirichlet Mixture Model. GSDMM is a Bag Of Words based model. It requires only an upper bound K on the number of clusters, i.e. number of clusters are not fixed it can take any number less than upper bound value. With good parameter selection, the model converges quickly. This option is space efficient and scalable
    *Option 2*: Latent Dirichlet Allocation (LDA)
        - Latent Dirichlet Allocation (LDA) classifies or categorizes the text into a document and the words per topic, these are modeled based on the Dirichlet distributions and processes. LDA is a Bag Of Words based model. Documents are a mixture of topics, and topics are a mixture of tokens (or words)
    *Option 3*: K-Means
        - k-means clustering is a method of vector quantization. It is a word embedding based model. This option uses word2vec or fasttext to get word feature vectors of input text. K-Means aims to partition ``n`` observations into ``k`` clusters in which each observation belongs to the cluster with the nearest mean (cluster centers or cluster centroid)
    *Option 4*: Bertopic
        - Bertopic clustering is a method that leverages transformers and c-TF-IDF to create dense clusters allowing for easily interpretable topics whilst keeping important words in the topic descriptions.

    Parameters
    ----------
    input_text : list
        list of sentences with cleaned text
    corpus: list
        list with list of tuples, where each list represents one text entry, each tuple represents word ID and it's number of occurences in that text entry.

        For example: ``[[(0,1), (1,1), (2,1), (3,1)], [(0,1), (1,1), (4,1), (5,1)]]``
    dictionary: dictionary
        ID to word dictionary where IDs are keys and words are values.

        For example ``{0 : "this", 1 : "is", 2 : "datawords", 3 : "sample", 4 : "one", 5 : "more"}``
    data_words: list
        list of data words/tokens list for each text entry.

        For example: ``[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]``
    log_level : str, optional
        level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.text_processing.api import cluster_model_data_preparation
    >>> from tigernlp.text_clustering.api import ClusteringModel
    >>> import numpy as np
    >>> import pyLDAvis
    >>> import matplotlib.pyplot as plt
    >>> cleaned_text_for_clustering = ["this is datawords sample", "this is one more", "this is to increase the list"] # Large dataset required
    >>> input_text, corpus, id2word, data_words = (
    >>>    cluster_model_data_preparation(
    >>>        input_text=cleaned_text_for_clustering,
    >>>        operation="only_unigram",
    >>>        phrase_level=2,
    >>>        min_count=1,
    >>>        threshold=3)
    >>> )
    >>> clustering_model_object = ClusteringModel(input_text, corpus, id2word, data_words)
    >>> # Option 1 - Gibbs Sampling Dirichlet Multinomial Mixture (GSDMM)
    >>> # Without hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.gsdmm(
    >>>         alpha=0.5,
    >>>         beta=0.1,
    >>>         max_n_topics=80,
    >>>         itr=20,
    >>>         n_words=5000,
    >>>         run_document_to_topics_mapping=True,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=False
    >>>     )
    >>> )
    >>> # With hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.gsdmm(
    >>>         alpha=0.5,
    >>>         beta=0.1,
    >>>         max_n_topics=80,
    >>>         itr=20,
    >>>         n_words=5000,
    >>>         run_document_to_topics_mapping=True,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=True,
    >>>         hyper_parameter_tuning_parameters={
    >>>             "alpha": list(np.arange(0.31, 0.6, 0.1)),
    >>>             "beta": list(np.arange(0.31, 0.6, 0.1)),
    >>>         }
    >>>     )
    >>> )
    >>> # Option 2 - Latent Dirichlet Allocation (LDA)
    >>> # Without hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.lda(
    >>>         n_topics=40,
    >>>         itr=40,
    >>>         alpha=0.25,
    >>>         beta=0.1,
    >>>         run_document_to_topics_mapping=True,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=False
    >>>     )
    >>> )
    >>> # With hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.lda(
    >>>         n_topics=40,
    >>>         itr=40,
    >>>         alpha=0.25,
    >>>         beta=0.1,
    >>>         run_document_to_topics_mapping=True,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=True,
    >>>         hyper_parameter_tuning_parameters={
    >>>                 "alpha": list(np.arange(0.25, 0.4, 0.15)),
    >>>                 "beta": list(np.arange(0.25, 0.4, 0.15)),
    >>>                 "n_topics_list": list(range(2,3,1))
    >>>             }
    >>>     )
    >>> )
    >>> # Option 3 - K-Means
    >>> # Without hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.kmeans(
    >>>         n_topics=10,
    >>>         run_document_to_topics_mapping=True,
    >>>         embeddings="word2vec",
    >>>         feature_size=300,
    >>>         window_context=5,
    >>>         min_word_count=1,
    >>>         n_iteration=5,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=False
    >>>     )
    >>> )
    >>> # With hyper parameter tuning
    >>> metrics_df, dfx, n_topics, topic_vis, graph = (
    >>>     clustering_model_object.kmeans(
    >>>         n_topics=10,
    >>>         run_document_to_topics_mapping=True,
    >>>         embeddings="word2vec",
    >>>         feature_size=300,
    >>>         window_context=5,
    >>>         min_word_count=1,
    >>>         n_iteration=5,
    >>>         tsne_plot=True,
    >>>         hyper_parameter_tuning=True,
    >>>         hyper_parameter_tuning_parameters={
    >>>             "n_topics_list": list(range(2,30,1)),
    >>>             "metric" : "wcss"
    >>>         }
    >>>     )
    >>> )
    >>> # Saving Topic Visualization Plots
    >>> topic_vis["intertopic_distance_map"].write_html("interactive_topic_visualization.html")
    >>> # for LDA
    >>> LDAvis_prepared = topic_vis['intertopic_distance_map']
    >>> pyLDAvis.save_html(LDAvis_prepared, "interactive_topic_visualization.html")
    >>> topic_vis["tsne_topic_visualization"].figure.savefig("tsne_topic_visualization.png")
    >>> topic_vis["tsne_hyperparameters_visualization"].figure.savefig("tsne_hyperparameter_topic_visualization.png")
    """

    def __init__(self, input_text, corpus=None, dictionary=None, data_words=None, log_level="WARNING", log_file_path=None, verbose=True):
        """ClusteringModel class initialization"""
        text_col = "text"
        # Create DataFrame from given series.
        frame = {text_col: input_text}
        input_text = pd.DataFrame(frame)
        input_text.fillna("", inplace=True)
        self.input_text = input_text
        self.data_words = data_words
        self.input_text["stems"] = self.data_words

        def join_stems(s):
            return " ".join(s)

        if self.data_words is not None:
            self.input_text["stem_text"] = self.input_text["stems"].apply(join_stems)

        self.corpus = corpus
        self.dictionary = dictionary

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    @staticmethod
    def _get_topic_name(t):
        return "Topic " + str(t)

    def gsdmm(
        self,
        alpha=0.5,
        beta=0.1,
        max_n_topics=80,
        itr=100,
        n_words=5000,
        run_document_to_topics_mapping=True,
        tsne_plot=False,
        hyper_parameter_tuning=False,
        hyper_parameter_tuning_parameters={
            "alpha": np.around(list(np.arange(0.31, 0.6, 0.1)), 3),
            "beta": np.around(list(np.arange(0.31, 0.6, 0.1)), 3),
        },
    ):
        """Function to run GSDMM clustering using MovieGroupProcess model.

        A MovieGroupProcess is a conceptual model introduced by Yin and Wang 2014 to
        describe their Gibbs sampling algorithm for a Dirichlet Mixture Model for the
        clustering short text documents.
        Reference: http://dbgroup.cs.tsinghua.edu.cn/wangjy/papers/KDD14-GSDMM.pdf

        Imagine a professor is leading a film class. At the start of the class, the students
        are randomly assigned to K tables. Before class begins, the students make lists of
        their favorite films. The teacher reads the role n_iters times. When
        a student is called, the student must select a new table satisfying either:

            1) The new table has more students than the current table.

        OR

            2) The new table has students with similar lists of favorite movies.

        Parameters
        ----------
        alpha : float between 0 and 1, optional
            alpha controls the probability that a student will join a table that is currently empty.
            When alpha is 0, no one will join an empty table, by default 0.5
        beta : float between 0 and 1, optional
            beta controls the student's affinity for other students with similar interests. A low beta means
            that students desire to sit with students of similar interests. A high beta means they are less
            concerned with affinity and are more influenced by the popularity of a table, by default 0.1
        max_n_topics : int, optional
            upper bound on the number of possible clusters, by default 80
        itr : int, optional
            upper limit for the number of iterations to perform. The function will terminate earlier if a stable solution is found, by default 100
        n_words : int, optional
            max number of words to show for each cluster, by default 5000
        run_document_to_topics_mapping : bool, optional
            if True, maps the input documents to topics name, by default True
        tsne_plot : bool, optional
            if True, will generate 2d tsne plots for the clustering/hyperparameter tuning outputs
        hyper_parameter_tuning : bool, optional
            if True hyperparameter tuning is performed using hyper_parameter_tuning_parameters, best parameters are used to create final clusters, by default False
        hyper_parameter_tuning_parameters : dict, optional
            hyper parameter tuning parameters if hyper_parameter_tuning is True, by default { "alpha": list(np.arange(0.31,0.62, 0.1)), "beta": list(np.arange(0.31,0.62, 0.1)) }

        Returns
        -------
        pd.DataFrame
            dataframe with coherence score as Metric and Score columns.
            Any score between 0.45 and 0.70 is considered a good score, whereas 0.3 is bad, 0.4 is low, 0.55 is okay, 0.65 might be as good as it is going to get, 0.7 is nice, 0.8 is unlikely and 0.9 is probably wrong.
        pd.DataFrame
            dataFrame with input text and mapped topics/clusters
        int
            number of clusters created by the GSDMM model. The value will be less than or equal to the max_n_topic feature
        dict
            topic visualization dictionary with "intertopic_distance_map", "tsne_topic_visualization", "tsne_hyperparameters_visualization" graphs
        graph
            None, if hyper_parameter_tuning = False else, matplotlib graph of topic coherence score vs alpha and beta
        """
        np.random.seed(42)
        random.seed(42)
        graph = None
        tsne_plot_hyp = None

        if hyper_parameter_tuning:
            self.logger.info("-----GSDMM model hyperparameter tuning start-----")
            hpt = HyperParameterTuning(
                input_text=self.input_text.copy(),
                corpus=self.corpus,
                id2word=self.dictionary,
                data_words=self.data_words,
                hyper_parameter_tuning_parameters=hyper_parameter_tuning_parameters,
                logger=self.logger,
            )
            best_param_dict, graph, tsne_plot_hyp = hpt.gsdmm_hyper_parameter_tuning(
                max_n_topics=max_n_topics, n_iteration=itr, n_words=n_words, tsne_plot=tsne_plot
            )

            alpha, beta = best_param_dict["alpha"], best_param_dict["beta"]

        self.logger.info("-----GSDMM model run start-----")

        cm_gsdmm, mgp, top_index = gsdmm_compute_coherence_values(
            corpus=self.corpus,
            dictionary=self.dictionary,
            data_words=self.data_words,
            max_num_topics=max_n_topics,
            alpha=alpha,
            beta=beta,
            itr=itr,
            n_words=n_words,
        )
        n_topics = len(cm_gsdmm._topics)
        self.logger.info("Coherence Value: " + str(round(cm_gsdmm.get_coherence(), 3)))

        metrics_df = pd.DataFrame({"Metric": ["Coherence Value"], "Score": [round(cm_gsdmm.get_coherence(), 3)]})

        if run_document_to_topics_mapping:
            self.logger.info("-----document to topics mapping running-----")
            topic_dict = {}
            for i, topic_num in enumerate(top_index):
                topic_dict[topic_num] = i  # "Topic " + str(topic_num)

            prob = self.input_text["stems"].apply(lambda x: mgp.choose_best_label(x))
            topic_maping_df = self.input_text.copy()
            topic_maping_df["topic_number"] = prob

            def topic_mapping(x, topic_dict):
                if x[1] >= 0:  # threshold:
                    return topic_dict[x[0]]
                else:
                    return -1

            # check for continuous topic number
            topic_maping_df["topic_number"] = topic_maping_df["topic_number"].apply(lambda x: topic_mapping(x, topic_dict))

            topic_maping_df["topic"] = topic_maping_df["topic_number"].apply(ClusteringModel._get_topic_name)

        gsdmm_vis = dict()
        gsdmm_vis["intertopic_distance_map"] = visualize_topics(topic_maping_df[["stem_text", "topic"]])
        gsdmm_vis["tsne_topic_visualization"] = None
        gsdmm_vis["tsne_hyperparameters_visualization"] = tsne_plot_hyp

        if tsne_plot:
            model = TfidfVectorizer()
            matrix = model.fit_transform(topic_maping_df["stem_text"]).toarray()

            gsdmm_vis["tsne_topic_visualization"] = tsne_2d_visualization(
                feature_array=matrix, feature_array_2d=False, labels=topic_maping_df["topic_number"]
            )
            title_to_append = " with alpha = " + str(alpha) + ", beta = " + str(beta)
            title = gsdmm_vis["tsne_topic_visualization"].get_title() + title_to_append
            gsdmm_vis["tsne_topic_visualization"].set_title(title)

        topic_maping_df.drop(labels=["stems", "stem_text"], axis=1, inplace=True)
        return (metrics_df, topic_maping_df, n_topics, gsdmm_vis, graph)

    def lda(
        self,
        n_topics=40,
        itr=40,
        alpha=0.25,
        beta=0.1,
        run_document_to_topics_mapping=True,
        tsne_plot=False,
        hyper_parameter_tuning=False,
        hyper_parameter_tuning_parameters={
            "alpha": np.around(list(np.arange(0.31, 0.62, 0.1)), 3),
            "beta": np.around(list(np.arange(0.31, 0.62, 0.1)), 3),
            "n_topics_list": [10, 20, 30],
        },
    ):
        """Function to cluster text documents using LDA clustering algorithm

        Parameters
        ----------
        n_topics : int, optional
            number of topics to be extracted from the training corpus, by default 40
        itr : int, optional
            number of iterations through the corpus during training, by default 40
        alpha : float between 0 and 1, optional
            alpha represents document-topic density. Higher the value of alpha, documents are composed of more topics.
            Lower the value of alpha, documents contain fewer topics., by default 0.25
        beta : float between 0 and 1, optional
            Beta represents topic-word density. Higher the beta, topics are composed of a large number of words in the corpus.
            Lower value of beta, they are composed of few words, by default 0.1
        run_document_to_topics_mapping : bool, optional
            if True, maps the input documents to topics name, by default True
        tsne_plot : bool, optional
            if True, will generate 2d tsne plots for the clustering/hyperparameter tuning outputs
        hyper_parameter_tuning : bool, optional
            if True hyperparameter tuning is performed using hyper_parameter_tuning_parameters, best parameters are used to create final clusters, by default False
        hyper_parameter_tuning_parameters : dict, optional
            hyper parameter tuning parameters if hyper_parameter_tuning is True, by default { "alpha": list(np.arange(0.31, 0.62, 0.1)), "beta": list(np.arange(0.31, 0.62, 0.1)), "n_topics_list": [10, 20, 30], }

        Returns
        -------
        pd.DataFrame
            dataframe with coherence score as Metric and Score columns.
            Any score between 0.45 and 0.70 is considered a good score, whereas 0.3 is bad, 0.4 is low, 0.55 is okay, 0.65 might be as good as it is going to get, 0.7 is nice, 0.8 is unlikely and 0.9 is probably wrong.
        pd.DataFrame
            dataFrame with input text and mapped topics/clusters
        int
            Number of clusters created by LDA
        dict
            topic visualization dictionary with "intertopic_distance_map", "tsne_topic_visualization", "tsne_hyperparameters_visualization" graphs
        matplotlib.pyplot.figure:
            None, if hyper_parameter_tuning = False else, matplotlib graph of topic coherence score vs number of topics
        """
        np.random.seed(42)
        random.seed(42)
        graph = None
        tsne_plot_hyp = None
        if hyper_parameter_tuning:

            self.logger.info("-----LDA model hyperparameter tuning start-----")

            hpt = HyperParameterTuning(
                input_text=self.input_text.copy(),
                corpus=self.corpus,
                id2word=self.dictionary,
                data_words=self.data_words,
                hyper_parameter_tuning_parameters=hyper_parameter_tuning_parameters,
                logger=self.logger,
            )
            best_param_dict, graph, tsne_plot_hyp = hpt.lda_hyper_parameter_tuning(n_iteration=itr, tsne_plot=tsne_plot)

            alpha, beta, n_topics = best_param_dict["alpha"], best_param_dict["beta"], best_param_dict["n_topics"]

        self.logger.info("LDA model running---------------------------------------")

        cm_lda, lda_model = lda_compute_coherence_values(self.corpus, self.dictionary, self.data_words, n_topics, alpha, beta, itr)

        self.logger.info("-----LDA model run finish-----")

        self.logger.info("Coherence Value: " + str(cm_lda.get_coherence()))

        self.logger.info("-----Preparing pyLDAvis vizualization-----")

        LDAvis_prepared = gensimvis.prepare(lda_model, self.corpus, self.dictionary, mds="mmds", R=1000)

        if run_document_to_topics_mapping:
            self.logger.info("-----document to topics mapping running-----")
            temp = lda_model[self.corpus]
            topic_maping_df = self.input_text.copy()
            topic_maping_df["topic_number"] = np.arange(len(topic_maping_df))

            def topic_mapping(x, temp):
                return max(temp[x], key=lambda a: a[1])[0]

            topic_maping_df["topic_number"] = topic_maping_df["topic_number"].apply(lambda x: topic_mapping(x, temp))

        metrics_df = pd.DataFrame({"Metric": ["Coherence Value"], "Score": [round(cm_lda.get_coherence(), 3)]})
        topic_maping_df["topic"] = topic_maping_df["topic_number"].apply(ClusteringModel._get_topic_name)

        lda_vis = dict()
        lda_vis["intertopic_distance_map"] = LDAvis_prepared  # visualize_topics(dfx[["stem_text", "topic"]])
        lda_vis["tsne_topic_visualization"] = None
        lda_vis["tsne_hyperparameters_visualization"] = tsne_plot_hyp

        if tsne_plot:
            top_dist = []
            for d in self.corpus:
                tmp = {i: 0 for i in range(topic_maping_df["topic_number"].nunique())}
                tmp.update(dict(lda_model[d]))
                vals = list(OrderedDict(tmp).values())
                top_dist += [np.array(vals)]
            top_dist = np.array(top_dist)

            feature_array = tsne_components(top_dist, 2)  # , init="pca")
            # matrix = model.fit_transform(topic_maping_df["stem_text"]).toarray()
            lda_vis["tsne_topic_visualization"] = tsne_2d_visualization(
                feature_array=feature_array, feature_array_2d=True, labels=topic_maping_df["topic_number"]
            )
            title_to_append = " with alpha = " + str(alpha) + ", beta = " + str(beta)
            title = lda_vis["tsne_topic_visualization"].get_title() + title_to_append
            lda_vis["tsne_topic_visualization"].set_title(title)

        topic_maping_df.drop(labels=["stems", "stem_text"], axis=1, inplace=True)
        return metrics_df, topic_maping_df, n_topics, lda_vis, graph

    def kmeans(
        self,
        n_topics=10,
        embeddings="word2vec",
        feature_size=300,
        window_context=5,
        min_word_count=1,
        n_iteration=5,
        run_document_to_topics_mapping=True,
        tsne_plot=False,
        hyper_parameter_tuning=False,
        hyper_parameter_tuning_parameters={"n_topics_list": list(range(5, 50, 1)), "metric": "wcss"},
    ):
        """Function to cluster text documents using KMeans clustering algorithm

        Parameters
        ----------
        n_topics : int, optional
            number of topics to be extracted from the training corpus, by default 10
        embeddings : {word2vec, fasttext}, optional
            word embedding algorithm to use, supports word2vec/fasttext, by default "word2vec"
        feature_size : int, optional
            dimensionality of the word vectors, by default 300
        window_context : int, optional
            number of words before and after a given word are included as context words of the given word, by default 5
        min_word_count : int, optional
            minimun word count to consider the word, by default 1
        n_iteration : int, optional
            Number of iterations (epochs) over the corpus while getting features , by default 5
        run_document_to_topics_mapping : bool, optional
            if True, maps the input documents to topics name, by default True
        tsne_plot : bool, optional
            if True, will generate 2d tsne plots for the clustering/hyperparameter tuning outputs
        hyper_parameter_tuning : bool, optional
            if True hyperparameter tuning is performed using hyper_parameter_tuning_parameters, best parameters are used to create final clusters, by default False
        hyper_parameter_tuning_parameters : dictionary, optional
            hyper parameter tuning parameters if hyper_parameter_tuning is True, by default {"n_topics_list": list(range(5, 50, 1)), "metric": "wcss"}

            Currently supports "wcss" and "silhouette" score metrics

        Returns
        -------
        pd.DataFrame
            dataframe with silhouette score, DB index, wcss score as Metric and Score columns.
        pd.DataFrame
            dataFrame with input text and mapped topics/clusters
        int
            Number of clusters created by K-means
        dict
            topic visualization dictionary with "intertopic_distance_map", "tsne_topic_visualization", "tsne_hyperparameters_visualization" graphs
        matplotlib.pyplot.figure:
            None, if hyper_parameter_tuning = False else, matplotlib graph of selected score metric vs number of topics

        Raises
        ------
        ValueError
            Current pipeline supports "word2vec" and "fasttext" embeddings. Provided embedding model is not included in the pipeline
        """
        self.logger.info("-----K-Means Clustering running-----")

        graph = None
        tsne_plot_hyp = None

        we = WordEmbedding()
        input_text_list = self.input_text["text"].to_list()
        if embeddings == "word2vec":
            self.logger.info("-----Word2Vec vectorize running-----")
            feature_array = we.Word2Vec(
                input_text=input_text_list,
                data_words=self.data_words,
                feature_size=feature_size,
                window_context=window_context,
                min_word_count=min_word_count,
                n_iteration=n_iteration,
            )
        elif embeddings == "fasttext":
            self.logger.info("-----FastText vectorize running-----")
            feature_array = we.fast_text(
                input_text=input_text_list,
                data_words=self.data_words,
                feature_size=feature_size,
                window_context=window_context,
                min_word_count=min_word_count,
                n_iteration=n_iteration,
            )
        else:
            self.logger.error(
                f"""Current pipeline supports "word2vec" and "fasttext" embeddings. Provided {embeddings} model is not included in the pipeline"""
            )
            raise ValueError(
                f"""Current pipeline supports "word2vec" and "fasttext" embeddings. Provided {embeddings} model is not included in the pipeline"""
            )

        if hyper_parameter_tuning:
            self.logger.info("-----Kmeans model hyper parameter tuning start-----")

            hpt = HyperParameterTuning(
                input_text=self.input_text.copy(),
                corpus=self.corpus,
                id2word=self.dictionary,
                data_words=self.data_words,
                hyper_parameter_tuning_parameters=hyper_parameter_tuning_parameters,
                logger=self.logger,
            )
            n_topics, graph, tsne_plot_hyp = hpt.kmeans_hyper_parameter_tuning(feature_array=feature_array, tsne_plot=tsne_plot)

        # random_state Determines random number generation for centroid initialization. Use
        # an int to make the randomness deterministic. Works as seed, to replicate same result on same data.
        Kmean = KMeans(n_clusters=n_topics, random_state=42)
        Kmean.fit(feature_array)

        self.logger.info("-----Cluster Labels Prediction running-----")
        cluster_labels = Kmean.predict(feature_array)

        # Calculating metrics
        silhouette_score = round(get_silhouette_score(feature_array, cluster_labels), 3)
        self.logger.info("{}{}".format("Silhouette Score: ", silhouette_score))

        db_index = round(get_db_index(feature_array, cluster_labels), 3)
        self.logger.info("{}{}".format("DB Index: ", db_index))

        wcss = round(Kmean.inertia_, 3)
        self.logger.info("{}{}".format("WCSS score: ", wcss))

        metrics_df = pd.DataFrame({"Metric": ["Silhouette Score", "DB Index", "wcss score"], "Score": [silhouette_score, db_index, wcss]})

        if run_document_to_topics_mapping:
            self.logger.info("-----document to topics mapping running-----")
            topic_maping_df = self.input_text.copy()
            topic_maping_df["topic_number"] = cluster_labels

        topic_maping_df["topic"] = topic_maping_df["topic_number"].apply(ClusteringModel._get_topic_name)

        kmeans_vis = dict()

        kmeans_vis["intertopic_distance_map"] = visualize_topics(topic_maping_df[["stem_text", "topic"]])
        kmeans_vis["tsne_topic_visualization"] = None
        kmeans_vis["tsne_hyperparameters_visualization"] = tsne_plot_hyp

        if tsne_plot:
            kmeans_vis["tsne_topic_visualization"] = tsne_2d_visualization(
                feature_array=feature_array, feature_array_2d=False, labels=topic_maping_df["topic_number"]
            )

        topic_maping_df.drop(labels=["stems", "stem_text"], axis=1, inplace=True)
        return metrics_df, topic_maping_df, n_topics, kmeans_vis, graph

    def bert(
        self,
        nr_topics="auto",
        min_topic_size=10,
        n_gram_range=(1, 2),
        embedding_model="all-MiniLM-L6-v2",
        embedding=None,
        run_document_to_topics_mapping=True,
        calculate_probabilities=False,
        verbose=False,
        hdbscan_default=True,
        hdbscan_parameters={"min_samples": 5, "metric": "euclidean", "cluster_selection_epsilon": 0.0},
        vectorizer_model=None,
        random_state=42,
        tsne_plot=False,
        input_text_action_object_mapping=False,
        input_text_action_object_parameters={"data": None, "input_text_column": None, "action_object_column": None},
        hyper_parameter_tuning=False,
        hyper_parameter_tuning_parameters={"min_topic_size_list": [5, 10], "n_topics_list": [10, "auto", None]},
    ):
        """Function to run BERTopic clustering

        Parameters
        ----------
        nr_topics : int, optional
            the number of topics to be created, by default None. Set it to 'auto' to automatically reduce topics using HDBSCAN
        min_topic_size: int, optional
            The minimum size of the topic. Increasing this value will lead to a lower number of clusters/topics. by default 10
        n_gram_range : (int,int), optional
            gram range parameter for modelling, by default (1,1)
        embedding_model : str, optional
            pre-trained sentence transformer models
        embedding: array, optional
            sentence embedding vectors for clustering, embedding model will not be used, by default None
        run_document_to_topics_mapping : bool, optional
            if True, maps the input documents to topics name, by default True
        calculate_probabilities : bool, optional
            Whether to calculate the probabilities of all topics per document instead of the probability of the assigned topic per document. by default False
        verbose : bool, optional
            Changes the verbosity of the model. if True, it tracks the stages of the model, by default False
        hdbscan_default: bool, optional
            Whether to use default HDBSCAN Model or user defined HDBSCAN Model,by default True
        hdbscan_parameters:dictionary, optional
            hdbscan parameters if hdbscan_default is False, by default {"min_samples":5,"metric":'euclidean',"cluster_selection_epsilon":0,}
                min_samples:The number of samples in a neighbourhood for a point to be considered a core point
                metric:The metric to use when calculating distance between instances in a feature array. If metric is a string or callable, it must be one of the options allowed by metrics.pairwise.pairwise_distances for its metric parameter.by default 'euclidean'
                cluster_selection_epsilon: A distance threshold. Clusters below this value will be merged.by default 0
        vectorizer_model: CountVectorizer, optional
            Pass in a CountVectorizer to be used, by default None
        random_state: int , optional
            it sets a seed to the random generator, by default 42
        tsne_plot: bool, optional
            if True, will generate 2d tsne plots for the clustering/hyperparameter tuning outputs
        input_text_action_object_mapping: bool, optional
            Whether to map the input sentence text with the corresponding topics, by default False. If the input_text_action_object_mapping is set to True, then the user need to provide the input_text_action_object_parameters values.
        input_text_action_object_parameters: dictionary, optional
            if input_text_action_object_mapping is True, the dataframe (action object pair mapped to the corresponding input text), input text column, action object text column need to be passed,by default {'data':None,'input_text_column':None, 'action_object_column':None}. If the data is not passed, an empty dataset will be returned.
        hyper_parameter_tuning : bool, optional
            if True hyperparameter tuning is done, by default False
        hyper_parameter_tuning_parameters : dictionary, optional
            hyper parameter tuning parameters if hyper_parameter_tuning is True, by default {"min_topic_size_list": [5, 10], "n_topics_list": [10, 20] }


        Returns
        -------
        pd.DataFrame
            dataframe with Metric and Score as columns.
            It will contain Coherence Value in metric and that score.
        pd.DataFrame
            dataFrame with input text and mapped topics/clusters
        int
            Number of clusters.
        dict
            topic visualization dictionary with "intertopic_distance_map", "tsne_topic_visualization", "tsne_hyperparameters_visualization" ,"topic_to_text_2d_visualisation
        matplotlib.pyplot.figure:
            None, if hyper_parameter_tuning = False else, matplotlib graph of coherence vs number of topics
        pd.DataFrame
            dataFrame with input text, mapped topics/clusters, topic labels and topic words
        pd.DataFrame
            if input_text_action_object_mapping = True, dataFrame with input text (action object pair), corresponding sentence text, and mapped topics
        """
        self.logger.info("-----BERTopic Clustering running-----")

        se = SentenceEmbedding()
        if embedding is not None:
            sentence_model = None
        else:
            sentence_model = se.sentence_transformer_model(embedding_model=embedding_model)
            self.logger.info("-----Creating the embeddings-----")
            embedding = se.embedding_vector(
                model_object=sentence_model, sentences=self.input_text.copy().text.to_list(), convert_to_tensor=False
            )
            self.logger.info("-----Embeddings creation completed-----")

        if hdbscan_default:
            hdbscan_model = None
        else:
            hdbscan_model = HDBSCAN(
                min_cluster_size=min_topic_size,
                metric=hdbscan_parameters["metric"],
                min_samples=hdbscan_parameters["min_samples"],
                cluster_selection_epsilon=hdbscan_parameters["cluster_selection_epsilon"],
            )

        umap_model = UMAP(random_state=random_state)

        if hyper_parameter_tuning:
            self.logger.info("BERTopic model hyper parameter tuning running---------------------------------------")

            hpt = HyperParameterTuning(
                input_text=self.input_text.copy(),
                corpus=self.corpus,
                id2word=self.dictionary,
                data_words=self.data_words,
                hyper_parameter_tuning_parameters=hyper_parameter_tuning_parameters,
                logger=self.logger,
            )
            best_param_dict, graph, tsne_plot_hyp = hpt.bert_hyper_parameter_tuning(
                bertopic_parameters={
                    "n_gram_range": n_gram_range,
                    "embedding": embedding,
                    "umap_model": umap_model,
                    "hdbscan_model": hdbscan_model,
                    "vectorizer_model": vectorizer_model,
                    "verbose": verbose,
                },
                tsne_plot=tsne_plot,
            )

            nr_topics, min_topic_size = best_param_dict["n_topics"], best_param_dict["min_topic_size"]
        else:
            graph = None
            tsne_plot_hyp = None

        bertopic_model = BERTopic(
            nr_topics=nr_topics,
            min_topic_size=min_topic_size,
            n_gram_range=n_gram_range,
            calculate_probabilities=calculate_probabilities,
            umap_model=umap_model,
            hdbscan_model=hdbscan_model,
            vectorizer_model=vectorizer_model,
            verbose=verbose,
        )
        self.logger.info("-----Fitting the BERTopic Model-----")
        topics, _ = bertopic_model.fit_transform(self.input_text.text.to_list(), embeddings=embedding)
        self.logger.info("-----BERTopic model run finish-----")

        if run_document_to_topics_mapping:
            self.logger.info("-----Document to topics mapping running-----")
            topic_mapping_df = pd.DataFrame({"text": self.input_text.text.to_list(), "topic_number": topics})
            topic_mapping_df["topic"] = "Topic " + topic_mapping_df["topic_number"].astype(str)
            topic_mapping_df = topic_mapping_df[["text", "topic", "topic_number"]]
            topic_labels = bertopic_model.generate_topic_labels(nr_words=n_gram_range[-1])
            topic_words = bertopic_model.get_topics()
            topic_words_df = action_object_to_topic_words_mapping(topic_mapping_df, topic_words, topic_labels)

            if input_text_action_object_mapping:

                if (input_text_action_object_parameters["data"]).shape[0] < 1:
                    raise ValueError("The input text to action object dataframe is empty")
                else:
                    input_text_action_object_data = input_text_action_object_parameters["data"]
                    input_text_action_object_data.rename(
                        columns={
                            input_text_action_object_parameters["input_text_column"]: "input_text",
                            input_text_action_object_parameters["action_object_column"]: "action_object_pair",
                        },
                        inplace=True,
                    )
                    input_text_topic_df = action_object_to_text_mapping(topic_mapping_df, input_text_action_object_data)
            else:
                input_text_topic_df = pd.DataFrame()
        else:
            topic_mapping_df = pd.DataFrame()

        self.logger.info("-----Calculating the BERTopic Coherence-----")
        BERTopic_coherence_model = bertopic_compute_coherence_values(self.input_text.text.to_list(), topics, bertopic_model)

        self.logger.info("-----Coherence Value: " + str(BERTopic_coherence_model.get_coherence()))

        metrics_df = pd.DataFrame({"Metric": ["Coherence Value"], "Score": [round(BERTopic_coherence_model.get_coherence(), 3)]})

        n_topics = len(bertopic_model.get_topics())

        bert_vis = dict()
        bert_vis["intertopic_distance_map"] = None
        bert_vis["tsne_topic_visualization"] = None
        bert_vis["tsne_hyperparameters_visualization"] = tsne_plot_hyp
        bert_vis["topic_to_text_2d_visualisation"] = None

        if tsne_plot:

            feature_array = tsne_components(embedding, 2)
            bert_vis["tsne_topic_visualization"] = tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=topics)

            reduced_embedding = UMAP(n_neighbors=10, n_components=2, min_dist=0.0, metric="cosine").fit_transform(embedding)
            bert_vis["topic_to_text_2d_visualisation"] = bertopic_model.visualize_documents(
                self.input_text.text.to_list(), reduced_embeddings=reduced_embedding, hide_annotations=True
            )

        if n_topics > 4:
            bert_vis["intertopic_distance_map"] = bertopic_model.visualize_topics()

        else:
            self.logger.info(
                "----- Topic Visualisation can't be produced with number of topics less than 5.Increase the nr_topics or decrease the min_topic_size to get the topic visualisation-----"
            )

        topic_mapping_df.drop_duplicates(inplace=True)
        input_text_topic_df.drop_duplicates(inplace=True)

        return metrics_df, topic_mapping_df, n_topics, bert_vis, graph, topic_words_df, input_text_topic_df

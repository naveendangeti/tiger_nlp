import gensim
import numpy as np
import pandas as pd
import random
from gensim.models import CoherenceModel
import gensim.corpora as corpora

from .gsdmm import MovieGroupProcess


def gsdmm_compute_coherence_values(corpus, dictionary, data_words, max_num_topics, alpha, beta, itr, n_words):
    """Function to create GSDMM models and compute coherence score.

    Refer MovieGroupProcess class in gsdmm.py for the understanding of the alpha and beta parameter.

    Parameters
    ----------
    corpus : list
        list contains list of tuples, where each list represents one sentence, and each tuple represents word ID and number of occurences for word id in the sentence.

        For example: ``[[(0,1), (1,1), (2,1), (3,1)], [(0,1), (1,1), (4,1), (5,1)]]``
        In first sentence, word ID "2" occurs once whereas it is not present in second sentence
    dictionary : dictionary
        ID to word dictionary where IDs are keys and words are values.
        Each word will have unique ID associated with it.

        For example ``{0 : "this", 1 : "is", 2 : "datawords", 3 : "sample", 4 : "one", 5 : "more"}``
    data_words : list
        list of tokenized sentences generated using input_text.

        For example: ``[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]``
    max_num_topics : int
        maximum number of clusters to populate. GSDMM will populate less than or equal number of clusters than max_n_topics
    alpha : float between 0 and 1
        alpha controls the probability that a student will join a table that is currently empty.
        When alpha is 0, no one will join an empty table
    beta : float between 0 and 1
        beta controls the student's affinity for other students with similar interests.
        A low beta means that students desire to sit with students of similar interests.
        A high beta means they are less concerned with affinity and are more influenced by the popularity of a table
    itr : int
        upper limit for the number of iterations to perform.
        The function will terminate earlier if a stable solution is found
    n_words : int
        max number of words to show for each cluster

    Returns
    -------
    CoherenceModel
        A model for topic coherence.
    MovieGroupProcess
        A MovieGroupProcess model for GSDMM.
    Array
        Array of max_num_topics clusters.
    """
    np.random.seed(42)
    random.seed(42)
    mgp = MovieGroupProcess(K=max_num_topics, alpha=alpha, beta=beta, n_iters=itr)
    n_terms = len(set(x for doc in data_words for x in doc))
    mgp.fit(data_words, n_terms)

    # Number of documents per topic
    doc_count = np.array(mgp.cluster_doc_count)
    # Most important clusters (by number of docs inside)
    top_index = doc_count.argsort()[-max_num_topics:][::-1]
    topics = []

    # iterate over top n clusters
    for cluster in top_index:
        # create sorted dictionary of word distributions
        sorted_dict = sorted(mgp.cluster_word_distribution[cluster].items(), key=lambda k: k[1], reverse=True)[:n_words]

        # create empty list to contain words
        topic = []

        # iterate over top n words in topic
        for k, v in sorted_dict:
            # append words to topic list
            topic.append(k)

        # append topics to topics list
        if not topic:
            continue
        topics.append(topic)

    cm_gsdmm = CoherenceModel(topics=topics, dictionary=dictionary, corpus=corpus, texts=data_words, coherence="c_v")
    return cm_gsdmm, mgp, top_index


# supporting function for lda
def lda_compute_coherence_values(corpus, dictionary, data_words, num_topics, alpha, beta, itr):
    """Function to create LDA model and compute coherence score.

    Parameters
    ----------
    corpus : list
        list contains list of tuples, where each list represents one sentence, and each tuple represents word ID and number of occurences for word id in the sentence.

        For example: ``[[(0,1), (1,1), (2,1), (3,1)], [(0,1), (1,1), (4,1), (5,1)]]``
        In first sentence, word ID "2" occurs once whereas it is not present in second sentence
    dictionary : dictionary
        ID to word dictionary where IDs are keys and words are values.
        Each word will have unique ID associated with it.

        For example ``{0 : "this", 1 : "is", 2 : "datawords", 3 : "sample", 4 : "one", 5 : "more"}``
    data_words : list
        list of tokenized sentences generated using input_text.

        For example: ``[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]``
    num_topics : int
        number of topics to be extracted from the training corpus
    alpha : float between 0 and 1
        alpha represents document-topic density. Higher the value of alpha, documents are composed of more topics.
        Lower the value of alpha, documents contain fewer topics.
    beta : float between 0 and 1
        Beta represents topic-word density. Higher the beta, topics are composed of a large number of words in the corpus.
        Lower value of beta, they are composed of few words.
    itr : int
        Maximum number of iterations through the corpus when inferring the topic distribution of a corpus.

    Returns
    -------
    CoherenceModel
        CoherenceModel for LDA model and given data.
    gensim.models.LdaMulticore
        LDA model for given data and parameters.
    """
    lda_model = gensim.models.LdaMulticore(
        corpus=corpus,
        id2word=dictionary,
        num_topics=num_topics,
        random_state=100,
        chunksize=100,
        passes=itr,
        alpha=alpha,
        eta=beta,
    )

    cm_lda = CoherenceModel(model=lda_model, texts=data_words, dictionary=dictionary, coherence="c_v")
    return cm_lda, lda_model

def bertopic_compute_coherence_values(docs,topics, bertopic_model):
    """Function to compute the BERTopic model coherence values.

    Parameters
    ----------
    docs : list
        list of the sentences 
    topics : list
        list of the topics corresponding to each sentence in the docs
    bertopic_model : topic model
        pre-trained topic model

    Returns
    -------
    CoherenceModel
        CoherenceModel for BERTopic model
    """

    # Preprocess Documents
    documents = pd.DataFrame({"Document": docs,
                            "ID": range(len(docs)),
                            "Topic": topics})
    documents_per_topic = documents.groupby(['Topic'], as_index=False).agg({'Document': ' '.join})
    cleaned_docs = bertopic_model._preprocess_text(documents_per_topic.Document.values)

    # Extract vectorizer and analyzer from BERTopic
    vectorizer = bertopic_model.vectorizer_model
    analyzer = vectorizer.build_analyzer()

    # Extract features for Topic Coherence evaluation
    words = vectorizer.get_feature_names()
    tokens = [analyzer(doc) for doc in cleaned_docs]
    dictionary = corpora.Dictionary(tokens)
    corpus = [dictionary.doc2bow(token) for token in tokens]
    topic_words = [[words for words, _ in bertopic_model.get_topic(topic)] 
                for topic in range(len(set(topics))-1)]

    # Evaluate
    cm_bertopic = CoherenceModel(topics=topic_words, 
                                 texts=tokens, 
                                 corpus=corpus,
                                 dictionary=dictionary, 
                                 coherence='c_v')

    return cm_bertopic

def action_object_to_topic_words_mapping(dfx,topic_words,topic_labels):
    """Function to create a dataframe with text mapped to corresponding topics, topic labels and the top topic words.

    Parameters
    ----------
    dfx : dataframe
        dataframe with each text mapped to coresponding topic
    topic_words : list
        list of the words per topic
    topic_labels : list
        A list of topic labels sorted from the lowest topic ID to the highest

    Returns
    -------
    Dataframe
        Dataframe with text mapped to corresponding topics, topic labels and the top topic words
    """
    topic_words_df=pd.DataFrame(columns=['topic_number','topic_words'])

    for i in range(list(topic_words.keys())[0],list(topic_words.keys())[-1]+1):
        words=[]
        for j in topic_words[i]:
            words.append(j[0])
        topic_words_df.loc[len(topic_words_df.index)] = [i, words] 
    topic_words_df['topic_label']=topic_labels
    return pd.merge(dfx,topic_words_df,on='topic_number')


def action_object_to_text_mapping(dfx,data):
    """Function to create a dataframe with input text mapped to corresponding action object pairs and topics.

    Parameters
    ----------
    dfx : dataframe
        dataframe with each text mapped to coresponding topic
    data : dataframe
        dataframe with action object pair mapped on the sentence text

    Returns
    -------
    Dataframe
        Dataframe with sentence text mapped to corresponding action object pair,topics.
    """
    return pd.merge(data,dfx,left_on='action_object_pair',right_on='text').drop('text',axis=1)

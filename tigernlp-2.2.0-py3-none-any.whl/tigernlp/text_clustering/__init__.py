"""The module contains text clustering algorithms like GSDMM, LDA, K-means using word embedding vectors and BERTopic using sentence embedding vectors.
This can be used to cluster similar documents, topic modeling.
"""

import json
import logging
import numpy as np
import os
import pandas as pd
from sklearn.manifold import TSNE
from typing import List


class MyLogger:
    r"""Logging utility using logging module

    Saves the logs in stream or file as per parameter values

    Parameters
    ----------
    level : str, optional
        level or severity of the events they are used to track, by default "WARNING"
    module : str, optional
        module name to save log files by creating same folder and file name , by default None
        If ``None``, StreamHandler else FileHandler
    """

    def __init__(self, level="WARNING", log_file_path=None, verbose=True):
        """MyLogger class initialization"""
        self.logger = logging.getLogger("TigerNLP")
        self.set_level(level)
        self._add_handler(log_file_path=log_file_path, verbose=verbose)
        self.logger.propagate = False

    def info(self, message):
        """Logs a message with level INFO on this logger

        Parameters
        ----------
        message : str
            Message to log
        """
        self.logger.info("{}".format(message))

    def warning(self, message):
        """Logs a message with level WARNING on this logger

        Parameters
        ----------
        message : str
            Message to log
        """
        self.logger.warning("{}".format(message))

    def error(self, message):
        """Logs a message with level ERROR on this logger

        Parameters
        ----------
        message : str
            Message to log
        """
        self.logger.error("{}".format(message))

    def debug(self, message):
        """Logs a message with level DEBUG on this logger

        Parameters
        ----------
        message : str
            Message to log
        """
        self.logger.debug("{}".format(message))

    def set_level(self, level):
        """Sets the threshold for this handler to level.Logging messages which are less severe than level will be ignored.
        When a handler is created, the level is set to NOTSET (which causes all messages to be processed).

        Parameters
        ----------
        level : str
            Level or severity of the events they are used to track
        """
        levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if level in levels:
            self.logger.setLevel(level)
        else:
            self.logger.warning(
                f"""{level} is not part of supported levels i.e.('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL').
                Setting WARNING as default level"""
            )
            self.logger.setLevel("WARNING")

    def _add_handler(self, log_file_path=None, verbose=False):
        """Adds handler to the logger.If module name is None uses StreamHandler else uses FileHandler.

        File name and path is generated using module name.

        Parameters
        ----------
        module :str, Optional
            Module name used to create folder and file name to save log files, by default None

            If ``None``, StreamHandler else FileHandler
        """
        self.logger.handlers.clear()
        if log_file_path is not None:
            if not os.path.exists(log_file_path):
                if not os.path.isdir(os.path.dirname(log_file_path)):
                    os.makedirs(os.path.dirname(log_file_path))

            fh = logging.FileHandler(log_file_path)
            fh.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(module)s - %(funcName)s - %(levelname)s - %(message)s"))
            self.logger.addHandler(fh)

        if verbose:
            sh = logging.StreamHandler()  # (sys.stdout)
            sh.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(module)s - %(funcName)s - %(levelname)s - %(message)s"))
            self.logger.addHandler(sh)
        if log_file_path is None and not verbose:
            self.logger.addHandler(logging.NullHandler())


def save_df_as_json(df, filepath="./spancat_inference.json"):
    """Save dataframe as a json format file

    Parameters
    ----------
    df : str
        dataframe to be saved as json
    filepath : str, optional
        file path with filename for the json output, example - "data/json_file_name.json", please make sure that the folder strucutre exists, by default None
        if None, will return parsed json file

    Returns
    -------
    dict
        if filepath is None, returns dataframe in json format dict

    """
    try:
        df_json = df.to_json(orient="split", compression="infer", index="true")
        if filepath is None:
            raise Exception("Filepath for JSON output is None")
        else:
            with open(os.path.normpath(filepath), "w", encoding="utf-8") as f:
                json.dump(df_json, f, ensure_ascii=False, indent=4)
    except Exception:
        raise Exception


# def read_json(filepath):
#     """Reads the json file which user ask for return during inference_func call."""
#     with open(filepath, "r", encoding="utf-8") as f:
#         data = json.load(f)
#     return data


def rank_func(df):
    """Function to rank the keywords in descending order within a cluster acording to score column (count/tfidf).
    It it used in keyword extraction module

    Parameters
    ----------
    df : pd.DataFrame
        datframe containing keyword phrase and score of one cluster.

        columns - "keyword", "score"

    Returns
    -------
    pd.DataFrame
        datframe with "rank" column added based on count/tfidf score value present in input data
    """
    df = df.sort_values(["score"], ascending=False)
    df["rank"] = 1
    df["rank"] = df["rank"].cumsum()
    return df


def k_func(df):
    """Funtion to concatenate keyword and score column as keyword-score pair values.

    Example - (check, 480) where "check" is the keyword column value, and "480" is the score column value.
    It it used in keyword extraction module

    Parameters
    ----------
    df : pd.DataFrame
        datframe containing keyword phrase and score column

        columns - "keyword", "score"

    Returns
    -------
    tuple
        tuple containing keywords and score pair concatenated for the respective rows

        example - (check, 480)
    """
    return (df["keyword"], df["score"])


def tsne_components(feature_array, n_components=2, metric="euclidean", random_state=42, init="random"):
    """T-distributed Stochastic Neighbor Embedding.

    Parameters
    ----------
    feature_array : np.array
        high dimensional array for embedding.
    n_components : int, optional
        dimension of the embedded space, by default 2
    metric : str, optional
        the metric to use when calculating distance between instances in a feature array.
        If metric is a string, it must be one of the options allowed by scipy.spatial.distance.pdist for its metric parameter,
        or a metric listed in pairwise.PAIRWISE_DISTANCE_FUNCTIONS, by default "euclidean"
    random_state : int, optional
        determines the random number generator. Pass an int for reproducible results across multiple function calls.
        Note that different initializations might result in different local minima of the cost function, by default 42
    init : str, optional
        Initialization of embedding. Possible options are 'random', 'pca', and a numpy array of shape (n_samples, n_components)

    Returns
    -------
    np.array
        n_components dimensional embeded array
    """
    if isinstance(feature_array, list):
        feature_array = np.array(feature_array)
    X = TSNE(n_components=n_components, metric=metric, random_state=random_state, init=init).fit_transform(
        feature_array
    )  # init="pca", learning_rate="auto"

    return X


def load_data(filename: str, **kwargs) -> pd.DataFrame:
    """
    Loads data for csv, parquet or excel files and returns a pandas dataframe.

    Parameters
    ----------
    filename : str
        Filename of the data

    Returns
    -------
    pd.DataFrame
        Pandas dataframe of data from file specified

    Raises
    ------
    ValueError
        If file doesn't exist at path
    ValueError
        If file is not csv, parquet or excel
    """
    if not os.path.isfile(filename):
        raise ValueError(f"File does not exist at path {filename}")

    extension = os.path.splitext(filename)[1]
    if extension == ".csv":
        return pd.read_csv(filename, **kwargs)
    elif extension == ".parquet":
        return pd.read_parquet(filename, **kwargs)
    elif extension.startswith(".xls"):
        return pd.read_excel(filename, **kwargs)
    else:
        raise ValueError(f'Expected ".csv", ".parquet", or ".xls" files. Got "{extension}" which is not supported.')


def convert_df_column_list_values_to_rows(
    df: pd.DataFrame,
    columns_to_split: List = ["aspect", "position", "sentiment", "probs"],
    log_level: str = "WARNING",
    log_file_path: str = None,
    verbose: bool = True,
):
    """Converts dataframe in required format. Splits dataframe rows as per columns in list.

    Parameters
    ----------
    df : pd.DataFrame
        Dataframe should contain the columns given in columns_to_split.
        Columns in columns_to_split list must be present in df
        Columns in columns_to_split list are arrays of length 0 or more.
    columns_to_split : List, optional
        List of columns to split, by default ["aspect", "position", "sentiment", "probs"]
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Returns
    -------
    pd.DataFrame
        Dataframe contains same number columns given as input.
        Rows are splitted as per columns_to_split.

    Raises
    ------
    ValueError
        Raises ValueError if type of data is other than pd.Dataframe
    ValueError
        Raises ValueError if input dataframe is empty
    ValueError
        Raises ValueError if any column in `columns_to_split` not present in DF
    TypeError
        Raises TypeError if any column in `columns_to_split` contains value other that List
    ValueError
        Raises ValueError if each row length of lists in `columns_to_split` does not match

    Example
    -------
    >>> import pandas as pd
    >>> from tigernlp.core.api import convert_df_column_list_values_to_rows
    >>> data = [{"sentence":"This is as good as it gets for a 1 point margarita . The strawberry margarita is all I have been able to get because my local store is always sold out of plain margarita .","aspect":["margarita","strawberry margarita","margarita"],"sentiment":["Positive","Positive","Positive"],"probs":[[0.0001992222,0.0023974767,0.9974033237],[0.0000945071,0.0007024581,0.9992030263],[0.0001992222,0.0023974767,0.9974033237]],"aspect_identifier":1},{"sentence":"I love the margarita but had all the calories .","aspect":["margarita"],"sentiment":["Positive"],"probs":[[0.0000592522,0.0006469754,0.9992938042]],"aspect_identifier":1}]
    >>> df = pd.DataFrame(data)
    >>> out_df = convert_df_column_list_values_to_rows(df, columns_to_split=["aspect", "sentiment", "probs"])
    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    try:
        if df is None or not isinstance(df, pd.DataFrame):
            raise ValueError("Input dataframe is of incorrect type in this method")
        if not (df.shape[0]) > 0:
            raise ValueError("Input dataframe is empty")

        for c in columns_to_split:
            if c not in df.columns:
                raise ValueError("{column_name} column not found in dataframe".format(column_name=c))

        df.reset_index(drop=True, inplace=True)

        all = []
        for row in range(df.shape[0]):

            row_data = json.loads(df.iloc[row].to_json())
            split_data = []

            length = -1
            for c in columns_to_split:
                if not isinstance(row_data[c], List):
                    raise TypeError("Only List allowed in {column_name}. {t} provided".format(column_name=c, t=type(row_data[c])))
                if length == -1:
                    length = len(row_data[c])
                elif length == len(row_data[c]):
                    pass
                else:
                    raise ValueError("For one row length of all columns to split should be same")
                split_data.append(row_data[c])
                del row_data[c]

            if len(split_data[0]) == 0:
                continue

            for a in zip(*split_data):
                d1 = row_data.copy()
                for c, a1 in zip(columns_to_split, a):
                    d1[c] = a1

                all.append(d1)

        data = pd.DataFrame(all)
        return data
    except Exception as e:
        logger.error(f"Error occurred during splitting multiple aspects and sentiments.\n {e}")

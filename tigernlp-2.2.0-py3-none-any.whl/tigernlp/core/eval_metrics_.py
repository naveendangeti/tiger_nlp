import numpy as np
import pandas as pd
import warnings
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    davies_bouldin_score,
    f1_score,
    precision_score,
    recall_score,
    silhouette_score,
)
from sklearn.preprocessing import MultiLabelBinarizer
from statistics import mean
from typing import Tuple, Union

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")


def get_silhouette_score(feature_array, cluster_labels):
    """Compute silhouette score for the clusters.

    Silhouette score of 1 is acceptable whereas a score of -1 unfavourable. Score near 0 indicates overlapping clusters.
    Negative values indicates that the samples are assigned to incorrect clusters.

    Parameters
    ----------
    feature_array : np.array
        word embbeding feature vector.
    cluster_labels : np.array
        array of cluster lables for given feature array

    Returns
    -------
    float
        silhouette score
    """
    return silhouette_score(feature_array, cluster_labels)


def get_db_index(feature_array, cluster_labels):
    """Function to get db index for clusters.
    Lower value of DB index value indicates distinct clusters.

    Parameters
    ----------
    w2v_feature_array : np.array
        word embbeding feature vector.
    cluster_labels : np.array
        array of cluster lables for given feature array

    Returns
    -------
    float
        db index.
    """
    return davies_bouldin_score(feature_array, cluster_labels)


class EvaluationMetrics:
    """
    Class to generate the evaluation metrics when  there are two target columns.

    Parameters
    -----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    ---------
    >>> from tigernlp.core.eval_metrics import EvaluationMetrics
    >>> eval_metric = EvaluationMetrics()
    """

    def __init__(
        self,
        logging_level: str = "INFO",
        log_file_path=None,
        verbose=True,
    ) -> None:
        # Create logger object
        self.logger = MyLogger(
            level=logging_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def __micro_confusion_matrix(
        self, df, entity_column, pred_entity_column, category_column, pred_category_column
    ):
        """For a given dataframe, This function returns micro confusion matrix usig two target column values.

        Parameters
        ----------

        df : pd.DataFrame
            Input Dataframe

        entity_column : str
            This is the first actual target column present in dataframe.

        pred_entity_column : str
            This is the first predicted target column present in dataframe.

        category_column : str
            This is the second actual target column present in dataframe where values are categorical.

        pred_categorical_column : str
            This is the second predicted target column present in dataframe where values are categorical.


        Returns
        -------
        tn,fp,fn,tp: numerical values
            true negatives, false positives ,false negatives,true positives. A tuple of values present in the confusion matrix.

        """
        try:
            tp = 0
            fp = 0
            fn = 0
            tn = 0
            for row in range(df.shape[0]):
                entity = str(df.iloc[row][entity_column])
                pred_entity = str(df.iloc[row][pred_entity_column])
                category = str(df.iloc[row][category_column])
                pred_category = str(df.iloc[row][pred_category_column])
                if (entity == pred_entity) and (category == pred_category):
                    tp += 1
                elif (entity == "0") and (pred_entity == "0"):
                    tn += 1
                elif (entity == "0") and (pred_entity != "0"):
                    fp += 1
                elif (entity != "0") and (pred_entity == "0"):
                    fn += 1
                elif (entity == pred_entity) and (category != pred_category):
                    fp += 1

            return tn, fp, fn, tp
        except Exception as e:
            self.logger.error(f"Error occurred during evaluation micro confusion score . {e}")

    def __macro_confusion_metrix(
        self, df, entity_column, pred_entity_column, category_column, pred_category_column
    ):
        """For a given dataframe, This function returns macro confusion matrix usig two target column values.

        Parameters
        ----------

        df : pd.DataFrame
            Input Dataframe

        entity_column : str
            This is the first actual target column present in dataframe.

        pred_entity_column : str
            This is the first predicted target column present in dataframe.

        category_column : str
            This is the second actual target column present in dataframe where values are categorical.

        pred_categorical_column : str
            This is the second predicted target column present in dataframe where values are categorical.


        Returns
        -------
        confusion_matrix: Dictionary
        A dictionary where keys are categories and values are tuple of true negatives, false positives ,false negatives,true positives for each categories.
        """
        try:

            categories = df[category_column][df[category_column].notna()].unique().tolist()
            confusion_matrix = {}
            for category in categories:
                data1 = df[df[category_column] == category]
                data2 = df[df[pred_category_column] == category]
                data2 = data2[data2[category_column] != category]
                data = pd.concat([data1, data2])
                data = data.drop_duplicates()
                tp = 0
                fp = 0
                fn = 0
                tn = 0
                for row in range(data.shape[0]):
                    entity = str(data.iloc[row][entity_column])
                    pred_entity = str(data.iloc[row][pred_entity_column])
                    pred_category = str(data.iloc[row][pred_category_column])
                    category1 = str(data.iloc[row][category_column])
                    if (entity == pred_entity) and (category1 == pred_category):
                        tp += 1
                    elif (entity == "0") and (pred_entity == "0"):
                        tn += 1
                    elif (entity == "0") and (pred_entity != "0"):
                        fp += 1
                    elif (entity != "0") and (pred_entity == "0"):
                        fn += 1
                    elif (entity == pred_entity) and (category1 != pred_category):
                        if pred_category == category:
                            fp += 1
                confusion_matrix[category] = (tn, fp, fn, tp)

            return confusion_matrix
        except Exception as e:
            self.logger.error(f"Error occurred during evaluation macro confusion score . {e}")

    def evaluation_metrics(
        self,
        df,
        entity_column,
        pred_entity_column,
        category_column,
        pred_category_column,
        method="macro",
    ):
        """For a given dataframe, This function returns confusion metric, accuracy, precision, recall, f1_score based on the option macro or micro chose by user.

        Parameters
        ----------

        df : pd.DataFrame
            Input Dataframe

        entity_column : str
            This is the first actual target column present in dataframe.

        pred_entity_column : str
            This is the first predicted target column present in dataframe.

        category_column : str
            This is the second actual target column present in dataframe where values are categorical.

        pred_categorical_column : str
            This is the second predicted target column present in dataframe where values are categorical.

        method: str
            categorical value ( micro or macro). if macro then all macro evaluation metrics calculated otherwise micro.

        Returns
        -------
        evaluation_matrix: Dictionary
         A dictionary where keys are evaluation metrices like confusion metrics, accuracy , precision, recall and f1 score, and values are all these metrices values.

        Example
        ---------
        >>> from tigernlp.core.eval_metrics import EvaluationMetrics
        >>> eval_metric = EvaluationMetrics()
        >>> evaluation_matrix = eval_matrix.evaluation_metrics(df, entity_column, pred_entity_column, category_column, pred_category_column, method='macro')
        """
        try:

            if df is None or not isinstance(df, pd.DataFrame):
                raise ValueError("Input dataframe is not set or incorrect type in this method")

            elif entity_column not in df.columns.to_list():
                self.logger.error(
                    f"Given column is not a valid column in the dataframe - {entity_column}"
                )
                raise ValueError(f" {entity_column} is not present in the dataframe.")

            elif pred_entity_column not in df.columns.to_list():
                self.logger.error(
                    f"Given column is not a valid column in the dataframe - {pred_entity_column}"
                )
                raise ValueError(f" {pred_entity_column} is not present in the dataframe.")

            elif category_column not in df.columns.to_list():
                self.logger.error(
                    f"Given column is not a valid column in the dataframe - {category_column}"
                )
                raise ValueError(f" {category_column} is not present in the dataframe.")

            elif pred_category_column not in df.columns.to_list():
                self.logger.error(
                    f"Given column is not a valid column in the dataframe - {pred_category_column}"
                )
                raise ValueError(f" {pred_category_column} is not present in the dataframe.")

            df[entity_column] = df[entity_column].fillna("0")
            df[pred_entity_column] = df[pred_entity_column].fillna("0")
            df[category_column] = df[category_column].fillna("Blank")
            df[pred_category_column] = df[pred_category_column].fillna("Blank")

            if not all(isinstance(item, str) for item in df[entity_column]):
                self.logger.error(
                    f"{entity_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(f"{entity_column} is not set or incorrect type in this method")

            elif not all(isinstance(item, str) for item in df[pred_entity_column]):
                self.logger.error(
                    f"{pred_entity_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(
                    f"{pred_entity_column} is not set or incorrect type in this method"
                )

            elif not all(isinstance(item, str) for item in df[category_column]):
                self.logger.error(
                    f"{category_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(f"{category_column} is not set or incorrect type in this method")

            elif not all(isinstance(item, str) for item in df[pred_category_column]):
                self.logger.error(
                    f"{pred_category_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(
                    f"{pred_category_column} is not set or incorrect type in this method"
                )

            elif not all(isinstance(item, str) for item in df[pred_category_column]):
                self.logger.error(
                    f"{pred_category_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(
                    f"{pred_category_column} is not set or incorrect type in this method"
                )

            elif not all(isinstance(item, str) for item in df[pred_category_column]):
                self.logger.error(
                    f"{pred_category_column} is of incorrect type . Cannot proceed further"
                    "Requires correct column"
                )
                raise ValueError(
                    f"{pred_category_column} is not set or incorrect type in this method"
                )

            elif not (method == "micro" or method == "macro"):
                self.logger.error(f"{method}. wrong input given. It can either be micro or macro")
                raise ValueError(f"{method}. wrong input given. It can either be micro or macro")

            evaluation_matrix = {}
            if method == "macro":
                confusion_matrix = self.__macro_confusion_metrix(
                    df, entity_column, pred_entity_column, category_column, pred_category_column
                )
                precision = 0
                recall = 0
                accuracy = 0
                precision_matrix = {}
                recall_matrix = {}
                accuracy_matrix = {}
                for key, values in confusion_matrix.items():
                    ac = 0
                    pr = 0
                    re = 0
                    if (values[3] + values[1]) > 0:
                        pr = values[3] / (values[3] + values[1])
                        pr = round(pr, 2)
                        precision_matrix[key] = pr
                        precision += pr
                    else:
                        precision_matrix[key] = 0
                    if (values[3] + values[2]) > 0:
                        re = values[3] / (values[3] + values[2])
                        re = round(re, 2)
                        recall_matrix[key] = re
                        recall += re
                    else:
                        recall_matrix[key] = 0
                    if (values[3] + values[2] + values[1] + values[0]) > 0:
                        ac = (values[3] + values[0]) / (
                            values[3] + values[2] + values[1] + values[0]
                        )
                    else:
                        ac
                    ac = round(ac, 2)
                    accuracy_matrix[key] = ac
                    accuracy += ac

                for key, values in confusion_matrix.items():
                    value_matrix = {}
                    value_matrix["true_negatives"] = values[0]
                    value_matrix["false_positives"] = values[1]
                    value_matrix["false_negatives"] = values[2]
                    value_matrix["true_positives"] = values[3]
                    confusion_matrix[key] = value_matrix
                pr = precision / len(confusion_matrix)
                re = recall / len(confusion_matrix)

                evaluation_matrix["confusion_matrix"] = confusion_matrix
                evaluation_matrix["precision_category"] = precision_matrix
                evaluation_matrix["recall_category"] = recall_matrix
                evaluation_matrix["accuracy_category"] = accuracy_matrix
                evaluation_matrix["accuracy"] = round(accuracy / len(confusion_matrix), 2)
                evaluation_matrix["precision"] = round(pr, 2)
                evaluation_matrix["recall"] = round(re, 2)
                evaluation_matrix["f1_score"] = round((2 * (pr * re)) / (pr + re), 2)

                return evaluation_matrix

            else:
                tn, fp, fn, tp = self.__micro_confusion_matrix(
                    df, entity_column, pred_entity_column, category_column, pred_category_column
                )

                evaluation_matrix["confusion_matrix"] = {
                    "true_negatives": tn,
                    "false_positives": fp,
                    "false_negatives": fn,
                    "true_positives": tp,
                }
                evaluation_matrix["accuracy"] = (tp + tn) / (tp + fn + fp + tn)
                evaluation_matrix["precision"] = tp / (tp + fp)
                evaluation_matrix["recall"] = tp / (tp + fn)
                evaluation_matrix["f1_score"] = tp / (tp + (1 / 2 * (fp + fn)))

                return evaluation_matrix
        except Exception as e:
            self.logger.error(
                f"Error occurred in getting the evaluation scores for actual and predicted component. {e}"
            )



def partial_match_metrics(
    y_true: list,
    y_pred: list,
) -> Tuple[float, float, float]:
    """
    Calculate the match and missing ratios to evaluate the performance of multilabel predictor.

    1. Actual match ratio: ratio of number of labels that are common in predictions and the ground truth, to the number of ground truth label(s).
        Example: Actual labels = [1, 5, 3], Predicted labels = [2, 5, 3, 4, 9]
        Actual match ratio = 2/3 label(s) (5, 3) are there in predicted labels.

    2. Actual missing ratio: ratio of number of ground truth labels that are not present in predictions, to the number of ground truth label(s).
        Example: Actual labels = [1, 5, 3], Predicted labels = [2, 5, 3, 4, 9]
        Actual missing ratio = 1/3 label(s) (1) is not there in predicted labels.

    3. Predicted missing ratio: ratio of number of predicted label(s) that are not present in ground truth, to the number of predicted label(s).
        Example: Actual labels = [1, 5, 3], Predicted labels = [2, 5, 3, 4, 9]
        Predicted missing ratio = 3/5 label(s) (2, 4, 9) are not there in actual labels.

    Parameters
    ----------
    y_true : list
        List of actual labels.
    y_pred : list
        List of predicted labels.

    Returns
    -------
    Tuple[float, float, float]
        Average actual match ratio, Average actual missing ratio, Average predicted missing ratio.

    Example
    -------
    >>> y_true = [[1], [1], [2], [2], [1], [1]]
    >>> y_pred = [[1], [2], [1, 2], [1], [1, 2], [1]]
    >>> match, missing, missing_pred = partial_match_metrics(y_true=y_true, y_pred=y_pred)
    >>> match, missing, missing_pred
    (0.6666666666666666, 0.3333333333333333, 0.5)
    """

    if len(y_true) != len(y_pred):
        raise ValueError("Number of data points in prediction and actual are different.")

    # metric 1
    # ratio of all actual labels that are in predicted labels to the number of all actual label
    match_ratio = []
    for i in range(len(y_true)):
        counter = 0
        for j in range(len(y_true[i])):
            if y_true[i][j] in y_pred[i]:
                counter += 1
        match_ratio.append(round(counter / len(y_true[i]), 3))

    # metric 2
    # ratio of actual labels that are missing from predictions to the number of all actual labels
    missing_actual_ratio = []
    for i in range(len(y_true)):
        counter = 0
        for j in range(len(y_true[i])):
            if y_true[i][j] not in y_pred[i]:
                counter += 1
        missing_actual_ratio.append(round(counter / len(y_true[i]), 3))

    # metric 3
    # ratio of predicted labels that are missing from actual labels to the number of all predicted labels
    missing_predicted_ratio = []
    for i in range(len(y_true)):
        counter = 0
        for j in range(len(y_pred[i])):
            if y_pred[i][j] not in y_true[i]:
                counter += 1
        try:
            missing_predicted_ratio.append(round(counter / len(y_pred[i]), 3))
        except ZeroDivisionError:
            missing_predicted_ratio.append(0.0)

    return mean(match_ratio), mean(missing_actual_ratio), mean(missing_predicted_ratio)


def _hamming_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Calculates label based accuracy/Hamming score based on the below formula.

        hamming score = 1/n * sum over n { ( |set intersection between ground truth and prediction| ) / ( |set union between ground truth and prediction| ) }

    where n is number of rows.

    Parameters
    ----------
    y_true : np.ndarray
        Ground truth that contains binary encoding of classes for each row

    y_pred : np.ndarray
        Predictions that contains binary encoding of classes for each row

    Returns
    -------
    float
        hamming score / label based accuracy
    """
    return ((y_true & y_pred).sum(axis=1) / (y_true | y_pred).sum(axis=1)).mean()


def _coverage_metrics(y_true: list, y_pred: list) -> float:
    """Metrics that depicts the below information is evaluated.

    1. How much data did the model was able to predict aka Coverage
    2. Out of the data that was covered (i.e., data points that model actually predicted), how many of them are correct aka Covered Accuracy

    Parameters
    ----------
    y_true : list
        Ground truth
    y_pred : list
        Model predictions

    Returns
    -------
    float
        Covered accuracy
    """
    cov_acc = []
    predicted_count = 0
    for i in range(len(y_true)):
        counter = 0
        if len(y_pred[i]) == 0:
            cov_acc.append(counter)
        else:
            predicted_count += 1
            for j in range(len(y_true[i])):
                if y_true[i][j] in y_pred[i]:
                    counter += 1
            cov_acc.append(round(counter / len(y_true[i]), 3))

    return round(predicted_count / len(y_true), 3), round(sum(cov_acc) / predicted_count, 3)


def classification_model_report(
    y_true: Union[list, pd.Series, np.ndarray],
    y_pred: Union[list, pd.Series, np.ndarray],
    all_classes: list,
) -> Tuple[pd.DataFrame, dict]:
    """
    Creates a dataframe containing precision, recall, and f1-score at class level with aggregated performance metrics. It works for both multiclass and multilabel problems along with multiple predictions for multiclass problem (i.e., if we have a single ground truth for each data point but the model predicted top n classes).

    Parameters
    ----------
    y_true : Union[list, pd.Series, np.ndarray]
        List of actual labels, it can be either 1D or 2D i.e., each input can have 1(multiclass) or more(multilabel) ground truths. For example::

            1D - [1, 2, 1, 1]
            2D - [[1, 2], [1], [2], [1, 3]]

    y_pred : Union[list, pd.Series, np.ndarray]
        List of predicted labels, it can be either 1D or 2D i.e., each input can have 1 or more prediction. For example::

            1D - [1, 2, 1, 1]
            2D - [[1, 2], [1], [2], [1, 3]]

    all_classes : list
        List containing all possible classes.

    Return
    ------
        pd.DataFrame
            Dataframe containing the performance metrics at label level.

        Dict
            Dictionary of aggregated performance metrics.

    Example
    -------
    >>> # Multilclass
    >>> y_true = [1, 1, 2, 2, 1, 1]
    >>> y_pred = [1, 2, 1, 2, 1, 1]
    >>> rpt, metrics = classification_model_report(y_true=y_true, y_pred=y_pred, all_classes=[1,2])
    >>> metrics
    {'accuracy': 0.667, 'precision': 0.625, 'recall': 0.625, 'f1_score': 0.625}
    >>> rpt
                precision    recall  f1-score   support
    1              0.750000  0.750000  0.750000  4.000000
    2              0.500000  0.500000  0.500000  2.000000
    accuracy       0.666667  0.666667  0.666667  0.666667
    macro avg      0.625000  0.625000  0.625000  6.000000
    weighted avg   0.666667  0.666667  0.666667  6.000000

    >>> # Multiclass with multiple predictions
    >>> y_true = [1, 1, 2, 2, 1, 1]
    >>> y_pred = [[1], [2], [1, 2], [1], [1, 2], [1]]
    >>> rpt, metrics = classification_model_report(y_true=y_true, y_pred=y_pred, all_classes=[1,2])
    >>> metrics
    {'match_ratio': 0.667, 'missing_actual_ratio': 0.333, 'missing_predicted_ratio': 0.5, 'label_based_acc': 0.5, 'coverage': 1.0, 'covered_accuracy': 0.667}
    >>> rpt
                precision    recall  f1-score  support
    1              0.600000  0.750000  0.666667      4.0
    2              0.333333  0.500000  0.400000      2.0
    micro avg      0.500000  0.666667  0.571429      6.0
    macro avg      0.466667  0.625000  0.533333      6.0
    weighted avg   0.511111  0.666667  0.577778      6.0
    samples avg    0.500000  0.666667  0.555556      6.0

    >>> # Multilabel
    >>> y_true = [[1], [1], [1, 2], [2], [1, 3], [1]]
    >>> y_pred = [[1], [2], [1, 2], [1], [1, 2], [1]]
    >>> rpt, metrics = classification_model_report(y_true=y_true, y_pred=y_pred, all_classes=[1,2,3])
    >>> metrics
    {'match_ratio': 0.583, 'missing_actual_ratio': 0.417, 'missing_predicted_ratio': 0.417, 'label_based_acc': 0.556, 'coverage': 1.0, 'covered_accuracy': 0.583}
    >>> rpt
                precision    recall  f1-score  support
    1              0.800000  0.800000  0.800000      5.0
    2              0.333333  0.500000  0.400000      2.0
    3              0.000000  0.000000  0.000000      1.0
    micro avg      0.625000  0.625000  0.625000      8.0
    macro avg      0.377778  0.433333  0.400000      8.0
    weighted avg   0.583333  0.625000  0.600000      8.0
    samples avg    0.583333  0.583333  0.583333      8.0

    """
    # Error handling of inputs
    if (
        not isinstance(y_true, list)
        and not isinstance(y_true, pd.Series)
        and not isinstance(y_true, np.ndarray)
    ):
        raise ValueError(
            "Incorrect type of 'y_true'. Expected a valid list/Series/ndarray, provided : {}".format(
                type(y_true)
            )
        )
    elif (
        not isinstance(y_pred, list)
        and not isinstance(y_pred, pd.Series)
        and not isinstance(y_pred, np.ndarray)
    ):
        raise ValueError(
            "Incorrect type of 'y_pred'. Expected a valid list/Series/ndarray, provided : {}".format(
                type(y_pred)
            )
        )
    elif len(y_true) != len(y_pred) or len(y_true) == 0:
        raise ValueError(
            "Number of data points in prediction and actual are different or there are no data points. Provide lists of same number of data points."
        )
    elif not isinstance(all_classes, list):
        raise ValueError(
            "Incorrect type of 'all_classes'. Expected a valid list, provided : {}".format(
                type(all_classes)
            )
        )

    # Data handling
    # If its numpy array or pd series, convert them to list.
    if isinstance(y_true, np.ndarray):
        y_true = y_true.tolist()
    elif isinstance(y_true, pd.Series):
        y_true = y_true.to_list()

    if isinstance(y_pred, np.ndarray):
        y_pred = y_pred.tolist()
    elif isinstance(y_pred, pd.Series):
        y_pred = y_pred.to_list()

    # If y_true and y_pred are both 1d, use sklearn functions for metrics.
    # TODO: make average parameter to accept micro as well for both sklearn and custom metrics. Currently both of them are using macro.
    if (
        isinstance(y_true, list)
        and not isinstance(y_true[0], list)
        and isinstance(y_pred, list)
        and not isinstance(y_pred[0], list)
    ):
        # it is 1D
        acc = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average="macro")
        recall = recall_score(y_true, y_pred, average="macro")
        f1 = f1_score(y_true, y_pred, average="macro")

        metrics = {
            "accuracy": round(acc, 3),
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1_score": round(f1, 3),
        }

        report = classification_report(y_true=y_true, y_pred=y_pred, output_dict=True)
        report = pd.DataFrame(report).transpose()

        return report, metrics
    else:
        # MultilabelBinarizer and Partial match metrics works with string only.
        all_classes = list(map(str, all_classes))

        if isinstance(y_true, list) and not isinstance(y_true[0], list):
            y_true = [[elem] for elem in y_true]
            y_true = [list(map(str, elem)) for elem in y_true]
        elif isinstance(y_true, list) and isinstance(y_true[0], list):
            y_true = [list(map(str, elem)) for elem in y_true]

        if isinstance(y_pred, list) and not isinstance(y_pred[0], list):
            y_pred = [[elem] for elem in y_pred]
            y_pred = [list(map(str, elem)) for elem in y_pred]
        elif isinstance(y_pred, list) and isinstance(y_pred[0], list):
            y_pred = [list(map(str, elem)) for elem in y_pred]

        match_ratio, missing_actual_ratio, missing_predicted_ratio = partial_match_metrics(
            y_true=y_true, y_pred=y_pred
        )

        coverage, covered_acc = _coverage_metrics(y_true=y_true, y_pred=y_pred)

        mlb = MultiLabelBinarizer(classes=all_classes)
        y_true = mlb.fit_transform(y_true)  # This converts to np array
        y_pred = mlb.transform(y_pred)  # This converts to np array

        label_based_acc = _hamming_score(y_true=y_true, y_pred=y_pred)

        metrics = {
            "match_ratio": round(match_ratio, 3),
            "missing_actual_ratio": round(missing_actual_ratio, 3),
            "missing_predicted_ratio": round(missing_predicted_ratio, 3),
            "label_based_acc": round(label_based_acc, 3),
            "coverage": coverage,
            "covered_accuracy": covered_acc,
        }

        report = classification_report(
            y_true, y_pred, output_dict=True, target_names=all_classes, zero_division=0
        )
        report = pd.DataFrame(report).transpose()

        return report, metrics


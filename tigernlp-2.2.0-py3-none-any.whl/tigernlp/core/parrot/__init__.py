"""
This code has been taken from "https://github.com/PrithivirajDamodaran/Parrot_Paraphraser.git"
"""

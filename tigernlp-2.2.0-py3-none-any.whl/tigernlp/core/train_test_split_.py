import ast
import numpy as np
import pandas as pd
import warnings
from iterstrat.ml_stratifiers import MultilabelStratifiedKFold
from sklearn.model_selection import KFold, StratifiedKFold, train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
from skmultilearn.model_selection import iterative_train_test_split

from tigernlp.core.utils import MyLogger


class StratifiedDataManager:
    """StratifiedDataManager Class offers functionalities such as Train, Test and Validation split, Sampling data,
    Cross validation data generation for single label (binary class or multiclass) dataset and for Multilabel data set.
    All functions have stratification option as well.

    Parameters
    -----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.core.api import StratifiedDataManager
    >>> splitter = StratifiedDataManager()
    >>> # Example single label dataframe
    >>> df_single_label = pd.DataFrame({
    >>>                             'text': ['This is a sentence about apples.',
    >>>                                      'He like mango shake.',
    >>>                                      'Grapes are green in color.'
    >>>                                      'This is a sentence about cellphone'
    >>>                                      'My laptop is heating up.'],
    >>>                             'label': ['Fruit',
    >>>                                       'Fruit',
    >>>                                       'Fruit',
    >>>                                       'Device'
    >>>                                       'Device'],
    >>>                                 })
    >>> # for using train, test, and val split function for single label classification (binary class or multi class)
    >>> train, test, val = splitter.train_test_val_split(df = df_single_label, target_col = 'label')
    >>> #
    >>> # for using train, test, and val split function for only train and test data sets for single label classification (binary class or multi class)
    >>> train, test = splitter.train_test_val_split(df = df_single_label, target_col = 'label', val_size = 0)
    >>> #
    >>> # for sampling a fraction of dataframe from given dataframe for single label classification (binary class or multi class)
    >>> sample_df = splitter.sample_df(df = df_single_label, target_col = 'label')
    >>> #
    >>> # for generating cross validataion data from given dataframe for single label classification (binary class or multi class)
    >>> list_of_kfold_dataframes = splitter.cross_val_data_gen(data = df_single_label, k_folds = 5, target_col = 'label')
    >>> #
    >>> # Example multi label dataframe
    >>> df_multi_label = pd.DataFrame({
    >>>                             'text': ['Food is good, but the staff is horrible.',
    >>>                                      'I liked mango shake.',
    >>>                                      'Nice ambience and low price.'
    >>>                                      'Recommend for pizza.'
    >>>                                      'Took too much time, but the biryani was awesome.'],
    >>>                             'service': [1,0,0,1,1],
    >>>                             'food': [1,0,0,1,1],
    >>>                             'place' : [0,0,1,0,0]
    >>>                                 })
    >>> # for using train, test, and val split function for multi lable classification
    >>> train, test, val = splitter.train_test_val_split(df = df_multi_label, target_col = ['service','food','place'])
    >>> #
    >>> # for sampling a fraction of dataframe from given dataframe for single label classification (binary class or multi class)
    >>> sample_df = splitter.sample_df(df = df_multi_label, target_col = ['service','food','place'])
    >>> #
    >>> # for generating cross validataion data from given dataframe for single label classification (binary class or multi class)
    >>> list_of_kfold_dataframes = splitter.cross_val_data_gen(data = df_multi_label, k_folds = 5, target_col = ['service','food','place'])
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """StratifiedDataManager class initialization

        Parameters
        -----------
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True"""
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def __generate_X_y(
        self, df: pd.DataFrame, target_col: str, problem_type: str = "single_label_classification"
    ):
        """This function is used to generate the dependant and independant variables of a text classification problem.

        Parameters
        -----------
        df : pandas dataframe
            dataset containing the text dataset
        target_col : str, list
            column containing the independant variable(s).  Example - "label" for problem_type = "single_label_classification", ["label_1", "label_2"] for for problem_type = "multi_label_classification". Default "label".
        problem_type: str
            type of classification problem. Options - "single_label_classification", "multi_label_classification". Default "single_label_classification".

        Returns
        -------
        X0: pandas dataframe/numpy array
            the independant variables
        Y0: pandas dataframe/numpy array
            dependant variable
        """
        # Pre-processing and Generating X, y based on multi-label indicator
        try:
            if problem_type != "multi_label_classification":
                if type(target_col) == list:
                    X0 = df[df.columns.difference(target_col)]
                    y0 = df[target_col[0]]
                elif type(target_col) == str:
                    X0 = df[df.columns.difference([target_col])]
                    y0 = df[target_col]
                self.logger.info("X & Y are generated successfully")
                return X0, y0

            elif problem_type == "multi_label_classification":
                # Check if label column is in String format "['1', '2', '3']"
                if type(df[target_col][0]) == str:
                    df[target_col] = df[target_col].apply(ast.literal_eval)
                    onehot_labels = "binarized_" + target_col
                    df[onehot_labels] = list(MultiLabelBinarizer().fit_transform(df[target_col]))
                # Check if label column is in list format ['1', '2', '3']
                elif type(df[target_col][0]) == list:
                    onehot_labels = "binarized_" + target_col
                    df[onehot_labels] = list(MultiLabelBinarizer().fit_transform(df[target_col]))

                X_name = list(df[df.columns.difference([target_col, onehot_labels])].columns)
                Y_name = list(
                    pd.DataFrame(MultiLabelBinarizer().fit_transform(df[target_col])).columns
                )

                # check if input value is list of column header strings or just one string
                if type(target_col) == list:
                    X0 = np.matrix(
                        np.array(df[df.columns.difference([target_col, onehot_labels])])
                    )
                    y0 = np.matrix([i for i in df[onehot_labels]])
                elif type(target_col) == str:
                    X0 = np.matrix(
                        np.array(df[df.columns.difference([target_col, onehot_labels])])
                    )
                    y0 = np.matrix([i for i in df[onehot_labels]])

                self.logger.info("X & Y are generated successfully")
                return X0, y0, X_name, Y_name
        except Exception as e:
            self.logger.error(e)

    def StratifiedSplit_multiclass(self, X, y, get_size, random_state=42):
        # Stratified multi-class splitting using sklearn train_test_split
        X1, X2, y1, y2 = train_test_split(
            X, y, test_size=get_size, stratify=y, random_state=random_state
        )
        self.logger.info("Stratified Split for completed successfully")
        return X1, X2, y1, y2

    def StratifiedSplit_multilabel(self, X, y, get_size):
        # Stratified multi-label splitting using skmultilearn
        X1, y1, X2, y2 = iterative_train_test_split(X, y, test_size=get_size)
        self.logger.info("Stratified Split completed successfully")
        return X1, X2, y1, y2

    def train_test_val_split(
        self,
        df: pd.DataFrame,
        target_col: str,
        test_size: float = 0.1,
        val_size: float = 0.1,
        problem_type: str = "single_label_classification",
        random_state: int = None,
        stratify: bool = True,
    ):
        """This function is used to create train, test & validation dataset for a given pandas dataframe.

        Parameters
        ----------
        df: pandas dataframe
            dataset containing the text data and label column(s).
        target_col: str, list
            column containing the independant variable(s). Example - "label" for single_label_classification, ["label_1", "label_2"] for multi_label_classification. Default "label".
        test_size: float32
            size of the test datase. Default 0.1
        val_size: float32
            size of the validation dataset. Can be 0 for not generating val data set. Default 0.1.
        problem_type: str
            type of classification problem, options - single_label_classification, multi_label_classification. Default "single_label_classification".
        random_state: int32 (optional)
            the data shuffling state of the split. Default None.
        stratify : bool
            True if stratified split has to be done. Default True.

        Returns
        -------
        train: pandas dataframe
            training dataset
        test: pandas dataframe
            testing dataset
        val: pandas dataframe
            validation dataset

        Example
        -------
        >>> from tigernlp.core.api import StratifiedDataManager
        >>> splitter = StratifiedDataManager()
        >>> # Example single label dataframe
        >>> df_single_label = pd.DataFrame({
        >>>                             'text': ['This is a sentence about apples.',
        >>>                                      'He like mango shake.',
        >>>                                      'Grapes are green in color.'
        >>>                                      'This is a sentence about cellphone'
        >>>                                      'My laptop is heating up.'],
        >>>                             'label': ['Fruit',
        >>>                                       'Fruit',
        >>>                                       'Fruit',
        >>>                                       'Device'
        >>>                                       'Device'],
        >>>                                 })
        >>> # for using train, test, and val split function for single label classification (binary class or multi class)
        >>> train, test, val = splitter.train_test_val_split(df = df_single_label, target_col = 'label')
        >>> #
        >>> # for using train, test, and val split function for only train and test data sets for single label classification (binary class or multi class)
        >>> train, test = splitter.train_test_val_split(df = df_single_label, target_col = 'label', val_size = 0)
        >>> #
        >>> # Example multi label dataframe
        >>> df_multi_label = pd.DataFrame({
        >>>                             'text': ['Food is good, but the staff is horrible.',
        >>>                                      'I liked mango shake.',
        >>>                                      'Nice ambience and low price.'
        >>>                                      'Recommend for pizza.'
        >>>                                      'Took too much time, but the biryani was awesome.'],
        >>>                             'service': [1,0,0,1,1],
        >>>                             'food': [1,0,0,1,1],
        >>>                             'place' : [0,0,1,0,0]
        >>>                                 })
        >>> # for using train, test, and val split function for multi lable classification
        >>> train, test, val = splitter.train_test_val_split(df = df_multi_label, target_col = ['service','food','place'])

        Raises
        ------
        TypeError
            Raises type error if df is not in pd.DataFrame or stratify is not bool type or problem_type is not in str type.
        NameError
            Raises name error if target_col is not found in df.
        """

        if not isinstance(df, pd.DataFrame):
            self.logger.error("data must be a pd.DataFrame.")
            raise TypeError("data must be a pd.DataFrame.")

        if isinstance(problem_type, str):
            if problem_type not in ["single_label_classification", "multi_label_classification"]:
                problem_type = "single_label_classification"
                self.logger.warn(
                    f"{problem_type} was passed for problem_type, supported option are 'single_label_classification' or 'multi_label_classification'. Hence going for default 'single_label_classification'."
                )
                warnings.warn(
                    f"{problem_type} was passed for problem_type, supported option are 'single_label_classification' or 'multi_label_classification'. Hence going for default 'single_label_classification'."
                )

        else:
            self.logger.info("problem_type parameter must be of string type.")
            raise TypeError("problem_type parameter must be of string type.")

        if isinstance(stratify, bool):
            if stratify:
                if problem_type != "multi_label_classification":
                    if not isinstance(target_col, str):
                        self.logger.error("target_col must be a str.")
                        raise TypeError("target_col must be a str.")
                    if target_col not in df.columns:
                        self.logger.error("target_col column not present in data.")
                        raise NameError("target_col column not present in data.")
                else:
                    if not isinstance(target_col, list):
                        self.logger.error("target_col must be a list.")
                        raise TypeError("target_col must be a list.")
                    for tc in target_col:
                        if tc not in df.columns:
                            self.logger.error(f"{tc} column not present in data.")
                            raise NameError(f"{tc} column not present in data.")
        else:
            self.logger.error("stratify must be bool type.")
            raise TypeError("stratify must be bool type.")

        if not stratify:
            train, test = train_test_split(df, test_size=test_size, random_state=random_state)
            if val_size != 0:
                train, val = train_test_split(
                    train,
                    test_size=(val_size / (1 - test_size)),
                    random_state=random_state,
                )
                self.logger.info("Train, Test & Validation datasets generated successfully")
                return train, test, val
            else:
                self.logger.info("Train & Test datasets generated successfully")
                return train, test

        elif problem_type != "multi_label_classification":

            X, y = self.__generate_X_y(df, target_col, problem_type)
            X_remain, X_test, y_remain, y_test = self.StratifiedSplit_multiclass(
                X, y, test_size, random_state=random_state
            )
            if val_size != 0:
                X_train, X_val, y_train, y_val = self.StratifiedSplit_multiclass(
                    X_remain,
                    y_remain,
                    val_size / (len(X_remain) / len(X)),
                    random_state=random_state,
                )
            else:
                X_train = X_remain
                y_train = y_remain

        elif problem_type == "multi_label_classification":
            # check target_col
            X, y, X_name, Y_name = self.__generate_X_y(df, target_col, problem_type)
            X_remain, X_test, y_remain, y_test = self.StratifiedSplit_multilabel(X, y, test_size)
            if val_size != 0:
                X_train, X_val, y_train, y_val = self.StratifiedSplit_multilabel(
                    X_remain, y_remain, val_size
                )
            else:
                X_train = X_remain
                y_train = y_remain
            # convert the numpy arrays to pandas dataframe
            X_train = pd.DataFrame(X_train, columns=X_name)
            X_test = pd.DataFrame(X_test, columns=X_name)
            y_train = pd.DataFrame(y_train, columns=Y_name)
            y_test = pd.DataFrame(y_test, columns=Y_name)
            if val_size != 0:
                X_val = pd.DataFrame(X_val, columns=X_name)
                y_val = pd.DataFrame(y_val, columns=Y_name)
        # Combining the X & Y to create complete dataset
        train = pd.concat([X_train, y_train], axis=1)
        test = pd.concat([X_test, y_test], axis=1)
        if val_size != 0:
            val = pd.concat([X_val, y_val], axis=1)
            self.logger.info("Train, Test & Validation datasets generated successfully")
            return train, test, val
        else:
            self.logger.info("Train & Test datasets generated successfully")
            return train, test

    def cross_val_data_gen(
        self,
        df: pd.DataFrame,
        k_folds: int = 5,
        target_col: str = "label",
        problem_type: str = "single_label_classification",
        stratify: bool = False,
        shuffle: bool = True,
        random_state: int = None,
    ):
        """This function is used to generated cross validation data.

        Parameters
        ----------
        df : pd.DataFrame
            data frame to do cross validation splitting.
        k_folds : int
            number of folds for cross validation. Default 5.
        target_col: str, list
            column containing the independant variable(s), needed if stratify is true. Example - "label" for problem_type = "single_label_classification", ["label_1", "label_2"] for for problem_type = "multi_label_classification". Default "label".
        problem_type: str
            type of classification problem, options - "single_label_classification", "multi_label_classification". Default "single_label_classification".
        stratify : bool
            True if stratified split has to be done. Default False.
        shuffle : bool
            True if data needs to be shuffled before splitting. Default True.
        random_state : int
            set the random state for shuffling. Default None.

        Returns
        -------
        list_of_cross_val_df : list[(pd.DataFrame, pd.DataFrame)]
            The ouput is list of tuples, size of list is equal to k_folds number and for every tuple first element is Train dataframe and second is Val dataframe.

        Example
        -------
        >>> from tigernlp.core.api import StratifiedDataManager
        >>> splitter = StratifiedDataManager()
        >>> # Example single label dataframe
        >>> df_single_label = pd.DataFrame({
        >>>                                 'text': ['This is a sentence about apples.',
        >>>                                          'He like mango shake.',
        >>>                                          'Grapes are green in color.'
        >>>                                          'This is a sentence about cellphone'
        >>>                                          'My laptop is heating up.'],
        >>>                                 'label': ['Fruit',
        >>>                                           'Fruit',
        >>>                                           'Fruit',
        >>>                                           'Device'
        >>>                                           'Device'],
        >>>                                     })
        >>> # for generating cross validataion data from given dataframe for single label classification (binary class or multi class)
        >>> list_of_kfold_dataframes = splitter.cross_val_data_gen(data = df_single_label, k_folds = 5, target_col = 'label')
        >>> #
        >>> # Example multi label dataframe
        >>> df_multi_label = pd.DataFrame({
        >>>                                 'text': ['Food is good, but the staff is horrible.',
        >>>                                          'I liked mango shake.',
        >>>                                          'Nice ambience and low price.'
        >>>                                          'Recommend for pizza.'
        >>>                                          'Took too much time, but the biryani was awesome.'],
        >>>                                 'service': [1,0,0,1,1],
        >>>                                 'food':    [1,0,0,1,1],
        >>>                                 'place' :  [0,0,1,0,0]
        >>>                                     })
        >>> # for generating cross validataion data from given dataframe for single label classification (binary class or multi class)
        >>> list_of_kfold_dataframes = splitter.cross_val_data_gen(data = df_multi_label, k_folds = 5, target_col = ['service','food','place'])

        Raises
        ------
        TypeError
            raise type error if data is not a dataframe type or k_folds is not integer or shuffle or stratify are not in bool format.
        ValueError
            raises value error if k_folds is less than 2
        NameError
            raises name error if label column not found in data.
        """

        if not isinstance(df, pd.DataFrame):
            self.logger.error("Data must be a pd.DataFrame.")
            raise TypeError("Data must be a pd.DataFrame.")
        if isinstance(k_folds, int):
            if not k_folds > 1:
                self.logger.error("k_folds parameter must be greater than 1.")
                raise ValueError("k_folds parameter must be greater than 1.")
        else:
            self.logger.error("k_folds parameter must be integer.")
            raise TypeError("k_folds parameter must be integer.")
        if isinstance(stratify, bool):
            if stratify:
                if target_col not in df.columns:
                    self.logger.error("target_col column name not present in df.")
                    raise NameError("target_col column name not present in df.")
        else:
            self.logger.error("stratify parameter must be of bool type.")
            raise TypeError("stratify parameter must be of bool type.")
        if not isinstance(shuffle, bool):
            self.logger.error("shuffle parameter must be of bool type.")
            raise TypeError("shuffle parameter must be of bool type.")
        if isinstance(problem_type, str):
            if problem_type not in ["single_label_classification", "multi_label_classification"]:
                self.logger.warn(
                    f"{problem_type} was passed for problem_type, supported option are 'single_label_classification' or 'multi_label_classification'. Hence going for default 'single_label_classification'."
                )
                warnings.warn(
                    f"{problem_type} was passed for problem_type, supported option are 'single_label_classification' or 'multi_label_classification'. Hence going for default 'single_label_classification'."
                )
        else:
            self.logger.info("problem_type parameter must be of string type.")
            raise TypeError("problem_type parameter must be of string type.")

        list_of_cross_val_df = []

        if not stratify:
            kf = KFold(n_splits=k_folds, random_state=random_state, shuffle=shuffle)
            for train_index, val_index in kf.split(df, df[target_col]):
                list_of_cross_val_df.append((df.iloc[train_index], df.iloc[val_index]))
            self.logger.info("KFold cross validation datasets generated successfully")

        elif problem_type != "multi_label_classification":
            kfold = StratifiedKFold(n_splits=k_folds, shuffle=shuffle, random_state=random_state)
            for train_index, val_index in kfold.split(df, df[target_col]):
                list_of_cross_val_df.append((df.iloc[train_index], df.iloc[val_index]))
            self.logger.info("StratifiedKFold cross validation datasets generated successfully")

        elif problem_type == "multi_label_classification":
            X, y, X_name, Y_name = self.__generate_X_y(df, target_col, problem_type)
            kf = MultilabelStratifiedKFold(
                n_splits=k_folds, shuffle=shuffle, random_state=random_state
            )
            for train_index, val_index in kf.split(X, y):
                # convert the numpy arrays to pandas dataframe
                X_train, X_val = X[train_index], X[val_index]
                y_train, y_val = y[train_index], y[val_index]
                X_train = pd.DataFrame(X_train, columns=X_name)
                X_val = pd.DataFrame(X_val, columns=X_name)
                y_train = pd.DataFrame(y_train, columns=Y_name)
                y_val = pd.DataFrame(y_val, columns=Y_name)

                # Combining the X & Y to create complete dataset
                train = pd.concat([X_train, y_train], axis=1)
                val = pd.concat([X_val, y_val], axis=1)
                list_of_cross_val_df.append((train, val))
            self.logger.info(
                "MultilabelStratifiedKFold cross validation datasets generated successfully"
            )

        return list_of_cross_val_df

    def sample_df(
        self,
        df: pd.DataFrame,
        target_col: str,
        sample_size: float = 0.1,
        problem_type: str = "single_label_classification",
        random_state: int = None,
        stratify: bool = True,
    ):
        """Function to get a sampled dataframe from the input dataframe of the size given in sample_size.

        Parameters
        ----------
        df: pd.DataFrame
            The input dataframe.
        target_col: str, list
            Name of the column containing the independant variable(s) in the df, needed if stratify is true.
        sample_size: float
            The size of the sample to be returned, as a proportion of the original dataset. Default is 0.1.
        problem_type: str
            The type of the problem "single_label_classification" or "multi_label_classification". Default is "single_label_classification".
        random_state: int
            The seed to use when randomly sampling the data. Default is None.
        stratify: bool
            Whether to stratify the sample by the target column. Default is True.

        Return
        ------
        sample_df : pd.DataFrame
            A sampled dataframe from the input dataframe of the size given in sample_size.

        Example
        -------
        >>> from tigernlp.core.api import StratifiedDataManager
        >>> splitter = StratifiedDataManager()
        >>> # Example single label dataframe
        >>> df_single_label = pd.DataFrame({
        >>>                                 'text': ['This is a sentence about apples.',
        >>>                                          'He like mango shake.',
        >>>                                          'Grapes are green in color.'
        >>>                                          'This is a sentence about cellphone'
        >>>                                          'My laptop is heating up.'],
        >>>                                 'label': ['Fruit',
        >>>                                           'Fruit',
        >>>                                           'Fruit',
        >>>                                           'Device'
        >>>                                           'Device'],
        >>>                                     })
        >>> # for sampling a fraction of dataframe from given dataframe for single label classification (binary class or multi class)
        >>> sample_df = splitter.sample_df(df = df_single_label, target_col = 'label')
        >>> #
        >>> # Example multi label dataframe
        >>> df_multi_label = pd.DataFrame({
        >>>                                 'text': ['Food is good, but the staff is horrible.',
        >>>                                          'I liked mango shake.',
        >>>                                          'Nice ambience and low price.'
        >>>                                          'Recommend for pizza.'
        >>>                                          'Took too much time, but the biryani was awesome.'],
        >>>                                 'service': [1,0,0,1,1],
        >>>                                 'food':    [1,0,0,1,1],
        >>>                                 'place' :  [0,0,1,0,0]
        >>>                                     })
        >>> # for sampling a fraction of dataframe from given dataframe for multi label classification
        >>> sample_df = splitter.sample_df(df = df_multi_label, target_col = ['service', 'food', 'place'])

        """
        # Reusing train test val split function to take only test dataframe.
        _, sample_df = self.train_test_val_split(
            df=df,
            target_col=target_col,
            test_size=sample_size,
            val_size=0,
            problem_type=problem_type,
            random_state=random_state,
            stratify=stratify,
        )
        self.logger.info("Sample datasets generated successfully.")
        return sample_df

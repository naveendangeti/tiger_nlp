from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import SpacyTrainer

from .data_prepare import SpanCatSpacyDataPrep


class SpanCatTrainer(SpacyTrainer, SpanCatSpacyDataPrep):
    """
    A class for training span categorizer models using SpacyTrainer and SpanCatSpacyDataPrep classes.
    It inherits all the methods of SpacyTrainer and SpanCatSpacyDataPrep classes.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.api import SpanCatTrainer
    >>> # Initialize the SpanCatTrainer class
    >>> span_cat_trainer = SpanCatTrainer()
    >>> # Prepare the training data
    >>> df = pd.DataFrame({
    >>>                'text': ['This is a sentence about apples.', 'This is a sentence about cellphone'],
    >>>                'fruit': ['apples', []],
    >>>                'device': [[], 'cellphone']
    >>>                })
    >>> lst = [
    >>>        {'col_name': 'fruit', 'entity_label': 'FRUIT'},
    >>>        {'col_name': 'device', 'entity_label': 'DEVICE'}
    >>>        ]
    >>> df_with_index = span_cat_trainer.get_span_cat_index(df, 'text', span_category_details=lst)
    >>> # Generate the corpus
    >>> corpus_path = 'project_folder/corpus/'
    >>> basename = 'train'
    >>> nlp = spacy.load('en_core_web_sm')
    >>> span_cat_trainer.generate_corpus(df_with_index, 'text', 'spans_index', basename, nlp, corpus_path)
    >>> # Generate the configuration file
    >>> config_save_path = 'project_folder/config/scat_config.cfg'
    >>> optimize = 'efficiency'
    >>> gpu = False
    >>> pretrained_model_path = 'project_folder/models/scat_model_v1'
    >>> span_cat_trainer.generate_config(config_save_path, optimize, gpu, pretrained_model_path)
    >>> # Train the model
    >>> train_path = 'project_folder/corpus/train.spacy'
    >>> validation_path = 'project_folder/corpus/validation.spacy'
    >>> config_path = 'project_folder/config/scat_config.cfg'
    >>> model_save_path = 'project_folder/models/scat_model'
    >>> span_cat_trainer.train(train_path, validation_path, config_path, model_save_path)
    """

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """SpanCatTrainer class initialization

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_config(
        self,
        config_save_path: str,
        optimize: str = "efficiency",
        gpu: bool = False,
        pretrained_model_config_path: str = None,
    ):
        """Generates a configuration file for the span cat model training.

        Parameters
        ----------
        config_save_path : str
            Filepath to save the generated configuration file. Example - "project_folder/config/config.cfg"
        optimize : str, optional
            Model optimization strategy to use. Can be "efficiency" or "speed". Defaults "efficiency"
        gpu : bool, optional
            Flag to indicate whether to use GPU for training, Defaults False
        pretrained_model_config_path : str, optional
            The config path for the pretrained_model. Should be provided for retraining model. When provided, it will read the config file and fill/update the given parameter and save it in config_save_path. Example - "project_folder/config/config_version_old.cfg". Default None.

        Raises
        ------
        Exception
            raises exception if an error occurs while generating the configuration file.

        Examples
        --------
        >>> from tigernlp.entity_categorizer.api import SpanCatTrainer
        >>> span_cat_trainer = SpanCatTrainer()
        >>> config_save_path = 'project_folder/config/scat_config.cfg'
        >>> optimize = 'efficiency'
        >>> gpu = False
        >>> pretrained_model_config_path = 'project_folder/models/scat_model_v1/config.cfg'
        >>> span_cat_trainer.generate_config(config_save_path, optimize, gpu, pretrained_model_config_path)
        >>> The generated configuration file will be saved at 'project_folder/config/scat_config.cfg'


        """
        return super().generate_config(config_save_path, "spancat", optimize, gpu, pretrained_model_config_path)

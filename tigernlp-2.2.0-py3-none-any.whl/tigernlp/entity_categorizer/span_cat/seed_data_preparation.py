import numpy as np
import os
import pandas as pd
import random
import tqdm

from tigernlp.core.utils import MyLogger
from tigernlp.text_matching.api import FuzzyWuzzyMatching
from tigernlp.text_processing.api import TextProcessor


class SeedDataPreparation:
    """NER - Span Categorizer training model data preparation class.
    This can be used to create an initial seed data for training NER - Span Categorizer

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.entity_categorizer.span_cat.api import SeedDataPreparation
    >>> import pandas as pd
    >>> df_sample = pd.read_csv('sentence_processed_data_sample.csv')
    >>> config={
    >>>     "DataPreparation": {
    >>>         "processed_text_col": "processed_text_sentence",
    >>>         "category_df_path": cat_path,
    >>>         "substring_match": True,
    >>>         "span_category_details": [
    >>>             {'category_name': 'product', 'sheet_name': 'list_of_products','col_name': 'Products','method_type': 'fuzzywuzzy'},
    >>>             {'category_name': 'ingredient','sheet_name': 'list_of_ingredients','col_name': 'Ingredients','method_type': 'direct'},
    >>>             {'category_name': 'flavor','sheet_name': 'list_of_flavors','col_name': 'Flavors','method_type': 'fuzzywuzzy'},
    >>>             {'category_name': 'brand','sheet_name': 'list_of_brands','col_name': 'Brands','method_type': 'direct'},
    >>>             {'category_name': 'benefit','sheet_name': 'list_of_benefits','col_name': 'Benefits','method_type': 'fuzzywuzzy'},
    >>>             {'category_name': 'ocassion','sheet_name': 'list_of_occasions','col_name': 'Occasions','method_type': 'fuzzywuzzy'},
    >>>         ],
    >>>     }
    >>> }
    >>> seed_data_obj = SeedDataPreparation(log_level="WARNING")
    >>> df_seed_sample = seed_data_obj.get_span_cat_seed_df(input_df=df_sample.copy(), config=config)
    """

    def __init__(
        self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True
    ):
        """SeedDataPreparation class class initialization

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """
        random.seed(23)
        np.random.seed(seed=23)
        self.verbose = verbose
        self.log_file_path = log_file_path
        self.log_level = log_level
        self.logger = MyLogger(
            level=self.log_level, log_file_path=self.log_file_path, verbose=self.verbose
        ).logger
        self.fuzzy_wuzzy_obj = FuzzyWuzzyMatching(
            log_level=self.log_level, log_file_path=self.log_file_path, verbose=self.verbose
        )
        self.text_processor_obj = TextProcessor(
            log_level=self.log_level, log_file_path=self.log_file_path, verbose=self.verbose
        )

    def _substring_entities_match(self, df: pd.DataFrame):
        """Function to do substring entities matching on dataframe

        Returns
        -------
        pd.DataFrame
        """
        # TODO: one function for all kind of matching
        df.reset_index(drop=True, inplace=True)

        pbar = tqdm.tqdm(total=len(self.span_category_details))
        for key in self.span_category_details:
            pipe_category_col = key["category_name"]
            # print(pipe_category_col)
            self.logger.debug(f"Cleaning span phrases for the {pipe_category_col} category")
            temp_df = pd.read_excel(self.category_df_path, sheet_name=key["sheet_name"])
            noun_phrase_col = key["col_name"]
            # assigning all the span phrases related to category name in this pipe_category_col column
            tp_temp_obj = TextProcessor(
                df=temp_df,
                log_level=self.log_level,
                log_file_path=self.log_file_path,
                verbose=self.verbose,
            )

            tp_temp_obj.remove_blank_space(col_in=noun_phrase_col, col_out=noun_phrase_col)
            tp_temp_obj.to_lower(col_in=noun_phrase_col, col_out=noun_phrase_col)
            tp_temp_obj.remove_misc_characters(
                col_in=noun_phrase_col, col_out=noun_phrase_col, char_list="""[()]"""
            )
            strings = temp_df[noun_phrase_col].unique()
            strings = ["\\b" + f + "\\b" for f in strings]
            df["nouns1"] = df[self.processed_text_col].str.findall(f'(?i)({"|".join(strings)})')

            tp_temp_obj.lemmatization(pos="v", col_in=noun_phrase_col, col_out=noun_phrase_col)
            strings = temp_df[noun_phrase_col].unique()
            strings = ["\\b" + f + "\\b" for f in strings]
            df["nouns2"] = df[self.processed_text_col].str.findall(f'(?i)({"|".join(strings)})')

            df[pipe_category_col] = df["nouns1"] + df["nouns2"]
            del df["nouns1"]
            del df["nouns2"]

            df[pipe_category_col] = df[pipe_category_col].apply(lambda x: list(set(x)))

            pbar.update(1)
        pbar.close()

        return df

    def _noun_chunks_entities_matching_func(self, df: pd.DataFrame):
        """Function to get the entities for each dataframe in noun form

        Parameters
        ----------
        df: pd.DataFrame
            seed data with noun chunks and text columns

        Returns
        -------
        pd.DataFrame
        """
        # TODO - parallel processing for categories/data
        df.reset_index(drop=True, inplace=True)
        entity_dict = dict()
        for key in self.span_category_details:
            pipe_category_col = key["category_name"]
            # print(pipe_category_col)
            self.logger.info(f"Cleaning span phrases for the {pipe_category_col} category")
            temp_df = pd.read_excel(self.category_df_path, sheet_name=key["sheet_name"])
            noun_phrase_col = key["col_name"]
            # assigning all the span phrases related to category name in this pipe_category_col column
            tp_temp_obj = TextProcessor(
                df=temp_df,
                log_level=self.log_level,
                log_file_path=self.log_file_path,
                verbose=self.verbose,
            )
            tp_temp_obj.to_lower(col_in=noun_phrase_col, col_out=noun_phrase_col)
            tp_temp_obj.lemmatization(pos="v", col_in=noun_phrase_col, col_out=noun_phrase_col)

            # temp_df[noun_phrase_col] = temp_df[noun_phrase_col].apply(lambda a: self.text_processor_obj.to_lower(text=a))
            # temp_df[noun_phrase_col] = temp_df[noun_phrase_col].apply(lambda a: self.text_processor_obj.lemmatization(text=a, pos="v"))
            temp_df = temp_df.drop_duplicates(subset=[noun_phrase_col]).reset_index(drop=True)
            entity_dict[pipe_category_col] = list(temp_df[noun_phrase_col])
            entity_dict[pipe_category_col] = []

        # print("Entity_dict", entity_dict.shape)
        df_shape = len(df[self.noun_chunk_col])
        # print("df_shape", df_shape)
        pbar = tqdm.tqdm(total=df_shape)
        for i in range(df_shape):
            # print("category details",self.span_category_details)
            for key in self.span_category_details:
                # print("key", key)
                # print("method_tyoe", key["method_type"])
                pipe_category_col = key["category_name"]
                self.logger.info(f"Started entities match for {pipe_category_col} category")

                nc = df[self.noun_chunk_col][i]
                processed_nc_df = pd.DataFrame({"nc": nc})

                # processing for noun chunks and span category phrases should be same
                # we have converted all span category phrases to lower and lemmatized them only to compare the noun chunks
                # original noun chunks should not be disturbed

                # print("processed_df")
                # print(processed_nc_df)
                tp_proc_obj = TextProcessor(
                    df=processed_nc_df,
                    log_level=self.log_level,
                    log_file_path=self.log_file_path,
                    verbose=self.verbose,
                )
                tp_proc_obj.to_lower(col_in="nc", col_out="text_doc1")
                tp_proc_obj.lemmatization(pos="v", col_in="text_doc1", col_out="text_doc1")

                if key["method_type"] == "direct":

                    temp_fuz_wuz_df = self.fuzzy_wuzzy_obj.fuzzywuzzy_similarity(
                        text_doc1=list(processed_nc_df["text_doc1"].unique()),
                        text_doc2=entity_dict[pipe_category_col],
                        scorer_type="direct",
                    )

                if key["method_type"] == "fuzzywuzzy":
                    # TODO - replace return dataframe with return score list and create your own dataframe with column name
                    # This will remove dependency of column name change in fuzzywuzzy module

                    temp_fuz_wuz_df = self.fuzzy_wuzzy_obj.fuzzywuzzy_similarity(
                        text_doc1=list(processed_nc_df["text_doc1"].unique()),
                        text_doc2=entity_dict[pipe_category_col],
                        scorer_type=self.score_type,
                    )

                # print("Fuzz Data")
                # print(temp_fuz_wuz_df)

                # print("processed_nc_df")
                # print(processed_nc_df)

                # print("columns", temp_fuz_wuz_df.columns, processed_nc_df.columns)

                temp_fuz_wuz_df = pd.merge(
                    temp_fuz_wuz_df, processed_nc_df, on="text_doc1", how="outer"
                )

                # print("Merged Fuzz Data")
                # print(temp_fuz_wuz_df)
                # print(temp_fuz_wuz_df.isna().sum())

                if temp_fuz_wuz_df.isna().sum().sum() > 0:
                    raise ValueError(
                        f"NA present in entity matching dataframe {temp_fuz_wuz_df.isna().sum()}"
                    )

                if key["method_type"] == "direct":
                    temp_fuz_wuz_df["predicted"] = np.where(temp_fuz_wuz_df["scores"] >= 1, 1, 0)

                if key["method_type"] == "fuzzywuzzy":
                    temp_fuz_wuz_df["predicted"] = np.where(
                        temp_fuz_wuz_df["scores"] >= self.score_threshold, 1, 0
                    )
                # print(temp_fuz_wuz_df.shape)

                temp_fuz_wuz_df = temp_fuz_wuz_df[temp_fuz_wuz_df["predicted"] == 1]
                # print(temp_fuz_wuz_df)
                # print(temp_fuz_wuz_df.shape)
                # print(list(set(temp_fuz_wuz_df["nc"])))
                # print(list(temp_fuz_wuz_df["nc"]))

                # temp_fuz_wuz_df will contain repeating noun chunks due to matches with multiple span phrases from Entity_Phrase excel
                # for example -> chip is matched with both vegetable chip and chip, which means it belongs to product category
                # set is to take all the noun chunks that belong to the span category
                potential_category_spans = list(set(temp_fuz_wuz_df["nc"]))
                # print(potential_category_spans)
                entity_dict[pipe_category_col].append(potential_category_spans)
                # print(entity_dict)

            pbar.update(1)
        pbar.close()

        for key in self.span_category_details:
            df[key["category_name"]] = entity_dict[key["category_name"]]
            # print(df)

        return df

    def _func_to_concat_all_entities(self, x):
        """Combines all span phrases across provided span categories.
        It used to compute the noun chunks associated with the "Other" category which does not belong to the provided span categories.

        Parameters
        ----------
        x : pd.DataFrame
            row wise element of pandas dataframe

        Returns
        -------
        list
            list of all spans associated with the provided span categories
        """
        all_entity = []
        for pipeline in self.span_category_details:
            all_entity = all_entity + x[pipeline["category_name"]]
        all_entity = list(set(all_entity))
        # print("All Entity", all_entity)
        return all_entity

    def get_span_cat_seed_df(
        self,
        input_df=pd.DataFrame,
        config={
            "DataPreparation": {
                "processed_text_col": "text_clean",
                "substring_match": True,
                "noun_chunk_col": "noun_chunk_col",
                "category_df_path": os.path.join(
                    "data",
                    "output",
                    "entity_categorizer",
                    "span_cat",
                    "support_files",
                    "Entities_phrases.xlsx",
                ),
                "span_category_details": [
                    {
                        "category_name": "product",
                        "sheet_name": "list_of_products",
                        "col_name": "Products",
                        "method_type": "fuzzywuzzy",
                    },
                    {
                        "category_name": "ingredient",
                        "sheet_name": "list_of_ingredients",
                        "col_name": "Ingredients",
                        "method_type": "direct",
                    },
                ],
                "score_type": "partial_token_sort_ratio",
                "score_threshold": 90,
            }
        },
    ):
        """Function to associate potential spans to span categories.
        Potential spans can be identified using two methods -

        1. Substring match - it is a faster way of computing potential spans. It helps in quicker outputs for training and prodigy annotations.
        It extracts the exact phrases provided in span_category_details excel from the text for respective span categories.
        Note - It does not match phrase for lemmatization, spelling mistake or partial match.

        2. Noun chunks match - it is a time consuming way of computing potential spans.
        It should be used when you are not planning to use prodigy annotations and want to include partial matches.
        Function to identify potential noun chunks (spans) for the span categories mentioned in the config and
        get span index for the indentified spans from the data
        Note - It does not include exact match phrase outside of noun chunks and would result in higher False Positives in train data.

        Parameters
        ----------
        input_df : pd.DataFrame
            pandas dataframe with processed text and noun chunk column (if substring_match=False)

            Example -
                * processed text column = ['sentences from which we need to extract noun chunks', 'second sentence for noun extraction']
                * noun chunk column =  [['sentences', 'noun chunks'], ['second sentence', 'noun extraction']]

        config: dict
            configuration required to identify potential noun chunks (spans) for the span categories

            processed_text_col: str, optional
                text column name with processed text, by default "text_clean"
            substring_match: str, optional
                if True, will identify potential spans using substring method. It will ignore the noun_chunk_col, score_type, score_threshold etc paramters
            noun_chunk_col: str, optional
                column name with noun chunks, by default "noun_chunk_col".
                Please make sure the noun chunks in the column is in the same order of text.
                Example - if "text" = 'sentences from which we need to extract noun chunks', noun_chunk_column = ['sentences', 'noun chunks'].
                It should NOT be equal to ['noun chunks', 'sentences']
                It will not be used if substring_match=True
            category_df_path: str, optional
                path to excel with the example phrases for each of the category which will be used for training, by default os.path.join("data", "output", "entity_categorizer", "span_cat", "support_files", "Entities_phrases.xlsx")
            span_category_details: list
                list of dictionary with details for each category as the following dictionary keys - category_name, sheet_name, col_name, method_type

                category_name: str
                    span category name for spans. Example - ingredient, flavor, benefit etc

                sheet_name: str
                    excel sheet name in category_df_path file which has details of the mentioned category.
                    Example - "list_of_ingredients" excel sheet contains list of all noun phrases to be categorized as category "ingredient"

                col_name: str
                    column name of the category noun phrases in the sheet name.
                    Example - column name "Ingredients" contains all ingridient noun phrases in the sheet "list_of_ingredients"

                method_type: str ('fuzzywuzzy' OR 'direct')
                    similarity method type to be used when comparing "noun_chunk_col" noun chunks with the category noun phrases.
                    if fuzzywuzzy, fuzzywuzzy ratio based on score_type will be computed
                    if direct, direct match will be taken into account
            score_type: str, optional
                score type to be used for fuzzywuzzy matching, by default partial_token_sort_ratio.
                For more information on score type check https://tigeranalytics-code-templates.readthedocs-hosted.com/projects/tigernlp/en/latest/index.html
            score_threshold: int, optional
                score_threshold for fuzzywuzzy match, by default 90


        Returns
        -------
        pd.DataFrame
            Prepared dataset for train the spancat model

        Examples
        ---------
        >>> from tigernlp.entity_categorizer.span_cat.api import SeedDataPreparation
        >>> import pandas as pd
        >>> df_sample = pd.read_csv('sentence_processed_data_sample.csv')
        >>> config={
        >>>     "DataPreparation": {
        >>>         "processed_text_col": "processed_text_sentence",
        >>>         "category_df_path": cat_path,
        >>>         "substring_match": True,
        >>>         "span_category_details": [
        >>>             {'category_name': 'product', 'sheet_name': 'list_of_products','col_name': 'Products','method_type': 'fuzzywuzzy'},
        >>>             {'category_name': 'ingredient','sheet_name': 'list_of_ingredients','col_name': 'Ingredients','method_type': 'direct'},
        >>>             {'category_name': 'flavor','sheet_name': 'list_of_flavors','col_name': 'Flavors','method_type': 'fuzzywuzzy'},
        >>>             {'category_name': 'brand','sheet_name': 'list_of_brands','col_name': 'Brands','method_type': 'direct'},
        >>>             {'category_name': 'benefit','sheet_name': 'list_of_benefits','col_name': 'Benefits','method_type': 'fuzzywuzzy'},
        >>>             {'category_name': 'ocassion','sheet_name': 'list_of_occasions','col_name': 'Occasions','method_type': 'fuzzywuzzy'},
        >>>         ],
        >>>     }
        >>> }
        >>> seed_data_obj = SeedDataPreparation(log_level="WARNING")
        >>> df_seed_sample = seed_data_obj.get_span_cat_seed_df(input_df=df_sample.copy(), config=config)
        """
        try:
            # TODO - Include exact match phrase in noun chunks as well
            # TODO - add option to provide category vocab as a list in addition to reading from an excel file path
            self.logger.debug("Seed Data Preparation Started")
            self.config = config

            if (input_df is None) or (input_df.shape[0] <= 0):
                raise ValueError(f"Bad input passed to df {input_df}")

            if not isinstance(input_df, pd.DataFrame):
                raise ValueError(
                    f"{type(input_df)} is not a dataframe. Please provide a dataframe as an input"
                )

            if self.config is None:
                raise ValueError(f"Bad input passed to config {self.config}")

            self.processed_text_col = self.config["DataPreparation"]["processed_text_col"]
            if self.processed_text_col not in input_df.columns:
                raise ValueError(
                    f"Processed text column name {self.processed_text_col} is either incorrect or not present in the dataframe"
                )

            self.category_df_path = self.config["DataPreparation"]["category_df_path"]
            if not os.path.isfile(self.category_df_path):
                raise ValueError(f"File path {self.category_df_path} does not exist")

            self.substring_match = self.config["DataPreparation"]["substring_match"]

            self.span_category_details = self.config["DataPreparation"]["span_category_details"]
            if not isinstance(self.span_category_details, list):
                raise ValueError(
                    f"Input span_category_details is of incorrect type - {type(self.span_category_details)} in this method. Requires an input list"
                )

            if len(self.span_category_details) == 0:
                raise ValueError(
                    "Input span_category_details list is empty. Can not proceed further, Requires at least 1 span category"
                )

            self.logger.debug("Identifying potential span categories")

            if self.substring_match:
                input_df = self._substring_entities_match(input_df)
                return input_df
            else:
                self.noun_chunk_col = self.config["DataPreparation"]["noun_chunk_col"]
                if self.noun_chunk_col not in input_df.columns:
                    raise ValueError(
                        f"Noun chunk column name {self.noun_chunk_col} is either incorrect or not present in the dataframe"
                    )

                self.score_type = self.config["DataPreparation"]["score_type"]
                self.logger.debug(
                    "For more information on score type check https://tigeranalytics-code-templates.readthedocs-hosted.com/projects/tigernlp/en/latest/index.html"
                )
                if not isinstance(self.score_type, str):
                    raise ValueError(
                        f"Input score_type is of incorrect type - {type(self.score_type)} in this method. Requires an input string"
                    )

                self.score_threshold = self.config["DataPreparation"]["score_threshold"]
                if not (0 < self.score_threshold <= 100):
                    raise ValueError(
                        f"Score threshold {self.score_threshold} is not between 0 to 100."
                    )

                self.logger.debug(
                    "Identifying potential span categories for the provided noun chunks"
                )

                # phrase extraction is already tokenizing the sentence
                # simple mismatch can happen if nltk is used as model in phrase extraction vs spacy in here
                input_df[self.processed_text_col] = input_df[self.processed_text_col].apply(
                    lambda x: " ".join(
                        self.text_processor_obj.get_tokens(text=x, tokenizer="spacy")
                    )
                )
                input_df = self._noun_chunks_entities_matching_func(input_df)
                # print("Before")
                # print(input_df)

                input_df["all_entity"] = input_df.apply(
                    lambda a: self._func_to_concat_all_entities(a), axis=1
                )
                # print("After")
                # print(input_df)

                self.logger.debug("Marking unidentified noun chunks as Other")
                input_df["other_nouns"] = input_df.apply(
                    lambda a: list(set(a[self.noun_chunk_col]) - set(a["all_entity"])), axis=1
                )
                input_df = input_df.drop(["all_entity"], axis=1)

                return input_df
        except Exception as e:
            self.logger.error(
                f"Error {e} occurred while generating training dataset for span categorizer model"
            )

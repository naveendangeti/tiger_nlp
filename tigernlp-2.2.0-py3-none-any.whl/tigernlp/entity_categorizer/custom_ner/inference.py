import os
import pandas as pd
import spacy
import warnings
from joblib import Parallel, delayed

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")


class NERInference:
    """NERInference class to generate the predicted values from custom NER models

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "WARNING"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Example
    ---------
    >>> from tigernlp.entity_categorizer.custom_ner.api import NERInference
    >>> infer = NERInference()
    >>> sentence = 'The Indian Space Research Organisation is the national space agency of India, headquartered in Bengaluru.'
    >>> output_df = infer.predict_ner_entity_labels(sentences = sentence,
    >>>                                             spacy_model = 'en_core_web_sm',
    >>>                                             parallel_process = False,
    >>>                                             n_jobs = -1,
    >>>                                             json_output = False,
    >>>                                             json_path = None)
    >>> # Output dataframe with below columns (sentence, entity, label) and values associated with these columns
    >>> output_df['sentence']
    >>> ["The Indian Space Research Organisation or is the national space agency of India, headquartered in Bengaluru."]
    >>> output_df['entity']
    >>> ["The Indian Space Research Organisation","India","Bengaluru"]
    >>> output_df['label']
    >>> ["ORG","GPE","GPE"]

    """

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """NERInference class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def __predict(self, sentence: str, nlp: spacy.language.Language):
        """For a given dataframe, this function returns the entities and label associated with them from the text.

        Parameters
        ----------
        sentence : str, list of str
            sentence on which nodel will predict the entity and label. Example - 'The Indian Space Research Organisation is the national space agency of India, headquartered in Bengaluru.'
        spacy_model : spacy.language.Language
            spacy model object

        Returns
        -------
        list
            list[0] is entity predicted, list[1] is labels predicted and list[2] is sentence.
        """
        try:
            doc = nlp(sentence)
            entities = list(map(lambda ent: ent.text, doc.ents))
            labels = list(map(lambda ent: ent.label_, doc.ents))
            return [entities, labels, sentence]
        except Exception as e:
            self.logger.error(f"Error occurred during predicting NER entities and labels for sentence {e}")
            raise Exception(f"Error occurred during predicting NER entities and labels for sentence {e}")

    def predict_ner_entity_labels(
        self,
        sentences,
        spacy_model: str = "en_core_web_sm",
        parallel_process: bool = False,
        n_jobs: int = -1,
        json_output: bool = False,
        json_path: bool = None,
    ):
        """The function predict_ner_entity_labels is used to predict entities and labels from a given sentence or list of sentences.

        Parameters
        ----------
        sentences : str or list of str
            It can be a string or list of sentences against which entities and labels are fetched. If list, then it should be unique. Example - 'The Indian Space Research Organisation is the national space agency of India, headquartered in Bengaluru.'
        spacy_model : str
            An optional string parameter to specify which Spacy english model is to be used. Valid options are "en_core_web_sm", "en_core_web_md", "en_core_web_lg". If unable to download en_core_web model, if a custom model is trained, then path of model will be provided('path_of_the_model/model_name'). Default "en_core_web_sm"
        parallel_process : bool
            If Provided True, function will use parallel processing based on n_jobs value to predict entities and labels. Default False.
        n_jobs : int
            Using default value parallel processing function will use all cores to train. Otherwise provide value based on number of cores to avail for the function. Default -1
        json_output : bool
            If provided True, output format will be in json. Default False
        json_path : str
            If json_ouput is True then provide the path to save it. Default None.

        Returns
        -------
        dataframe
            Pandas dataframe with columns name sentences, entities, and labels.
        dataframe['sentence']
            sentences against in which entities are present.
        dataframe['entity']
            Entities which are fetched from text.
        dataframe['label']
            Labels of the entities which are fetched from text.

        Raises
        -------
        Exception
            If error occured during predicting entities and labels for the input sentence or list of sentences.
        TypeError
            raises type error if the sentence parameter is not in string or list of string type.
        OSError
            raises OS error when unable to load model.

        Example
        ---------
        >>> from tigernlp.entity_categorizer.custom_ner.api import NERInference
        >>> infer = NERInference()
        >>> sentence = 'The Indian Space Research Organisation is the national space agency of India, headquartered in Bengaluru.'
        >>> output_df = infer.predict_ner_entity_labels(sentences = sentence,
        >>>                                             spacy_model = 'en_core_web_sm',
        >>>                                             parallel_process = False,
        >>>                                             n_jobs = -1,
        >>>                                             json_output = False,
        >>>                                             json_path = None)
        >>> # Output dataframe with below columns (sentence, entity, label) and values associated with these columns
        >>> output_df['sentence']
        >>> ["The Indian Space Research Organisation or is the national space agency of India, headquartered in Bengaluru."]
        >>> output_df['entity']
        >>> ["The Indian Space Research Organisation","India","Bengaluru"]
        >>> output_df['label']
        >>> ["ORG","GPE","GPE"]


        """
        try:
            if not isinstance(sentences, list):
                if not isinstance(sentences, str):
                    self.logger.error(f"expected string or list of strings for sentences parameter got {type(sentences)}.")
                    raise TypeError(f"expected string or list of strings for sentences parameter got {type(sentences)}.")

            elif not all(isinstance(item, str) for item in sentences):
                self.logger.error("list sentences items is of incorrect type.")
                raise TypeError("list sentences items is of incorrect type.")

            elif not (os.path.exists(spacy_model) or spacy.util.is_package(spacy_model)):
                self.logger.error(
                    f"Can't find model {spacy_model}. It doesn't seem to be a spacy_model or a valid path to a data directory"
                )
                raise OSError(f"Can't find model {spacy_model}. It doesn't seem to be a spacy_model or a valid path to a data directory")

            elif not (isinstance(json_output, bool)):
                self.logger.error(f"expected bool datatype for json_output got {type(json_output)}")
                raise TypeError(f"expected bool datatype for json_output got {type(json_output)}")

            if type(sentences) is str:
                sentences = [sentences]

            nlp = spacy.load(spacy_model)
            test = pd.DataFrame()

            if parallel_process:
                self.logger.info(f"[Parallel(n_jobs={n_jobs})]: Using backend LokyBackend with {n_jobs} concurrent workers.")
                output = Parallel(n_jobs=n_jobs, verbose=50, backend="loky")(
                    delayed(self.__predict)(sentence, nlp) for sentence in sentences
                )
            else:
                output = [self.__predict(sentence, nlp) for sentence in sentences]

            test["sentence"] = list(zip(*output))[2]
            test["entity"] = list(zip(*output))[0]
            test["labels"] = list(zip(*output))[1]

            if json_output:
                return test.to_json(json_path, orient="index")
            else:
                return test
        except Exception as e:
            self.logger.error(f"Error occurred during predicting NER entities and labels. The error message is: {e}")
            raise Exception(f"Error occurred during predicting NER entities and labels. The error message is: {e}")

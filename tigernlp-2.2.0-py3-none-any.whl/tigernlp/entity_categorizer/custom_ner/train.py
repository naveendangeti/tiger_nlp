from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import SpacyTrainer

from .data_prepare import NERSpacyDataPrep


class NERTrainer(SpacyTrainer, NERSpacyDataPrep):
    """A class for training custom Named Entity recognition models using SpacyTrainer and NERSpacyDataPrep classes.
    It inherits all the methods of SpacyTrainer and NERSpacyDataPrep classes.

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.custom_ner.api import NERTrainer
    >>> # Initialize the NERTrainer class
    >>> ner_trainer = NERTrainer()
    >>> # Prepare the training data
    >>> df = pd.DataFrame({
    >>>                  'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
    >>>                  'entity': ['apples', 'apples'],
    >>>                  'label': ['FRUIT', 'FRUIT']
    >>>                  })
    >>> df_with_index = ner_trainer.get_ner_index(df, 'text', 'entity', 'label')
    >>> # Generate the corpus
    >>> corpus_path = 'project_folder/corpus/'
    >>> basename = 'train'
    >>> nlp = spacy.load('en_core_web_sm')
    >>> ner_trainer.generate_corpus(df_with_index, 'text', 'entity_index', basename, nlp, corpus_path)
    >>> # Generate the configuration file
    >>> config_save_path = 'project_folder/config/ner_config.cfg'
    >>> optimize = 'efficiency'
    >>> gpu = False
    >>> ner_trainer.generate_config(config_save_path, optimize, gpu)
    >>> # Train the model
    >>> train_path = 'project_folder/corpus/train.spacy'
    >>> validation_path = 'project_folder/corpus/validation.spacy'
    >>> config_path = 'project_folder/config/ner_config.cfg'
    >>> model_save_path = 'project_folder/output/models/ner_model'
    >>> ner_trainer.train(train_path, validation_path, config_path, model_save_path)
    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """NERTrainer class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_config(
        self,
        config_save_path: str,
        optimize: str = "efficiency",
        gpu: bool = False,
        pretrained_model_config_path: str = None,
    ):
        """Generates a configuration file for the named entity recognition (NER) model training.

        Parameters
        ----------
        config_save_path : str
            The file path where the generated configuration file will be saved. Example - "project_folder/config/config_version.cfg".
        optimize : str, optional
            The optimization method to be used. Options "efficiency", "accuracy". Default "efficiency".
        gpu : bool, optional
            Whether to use GPU for processing. Default False.
        pretrained_model_config_path : str, optional
            The config path for the pretrained_model. Should be provided for retraining model. When provided, it will read the config file and fill/update the given parameter and save it in config_save_path. Example - "project_folder/config/config_version_old.cfg". Default None.

        Raises
        ------
        Exception
            If an error occurs while generating the configuration file.

        Examples
        --------
        >>> from tigernlp.entity_categorizer.api import NERTrainer
        >>> ner_trainer = NERTrainer()
        >>> config_save_path = 'project_folder/config/config_version.cfg'
        >>> optimize = 'efficiency'
        >>> gpu = False
        >>> pretrained_model_config_path = 'project_folder/config/config_old.cfg'
        >>> ner_trainer.generate_config(config_save_path, optimize, gpu, pretrained_model_config_path)
        >>> The generated configuration file will be saved at 'project_folder/config/config_version.cfg'



        """
        return super().generate_config(config_save_path, "ner", optimize, gpu, pretrained_model_config_path)

"""
This module provides functionality for custom Named Entity Recognition including data preparation, training, and inferencing.
"""

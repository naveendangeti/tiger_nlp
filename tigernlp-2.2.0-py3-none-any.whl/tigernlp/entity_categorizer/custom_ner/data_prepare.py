import os
import pandas as pd
import spacy
from spacy.tokens import DocBin

from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import generate_index_labels


class NERSpacyDataPrep:
    """The NERSpacyDataPrep class is a utility class that provides functionalities for preparing data in the spacy format for custom NER.
    It has the following methods:

    1. get_ner_index: Adds a column to the dataframe containing a list of tuples, with each tuple containing the start index, end index, and label associated with an entity.

    2. generate_corpus: Generates a corpus in spacy format from a dataframe.

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "WARNING"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    ---------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.custom_ner.api import NERSpacyDataPrep
    >>> df = pd.DataFrame({
    >>>                   'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
    >>>                   'entity': ['apples', 'apples'],
    >>>                   'label': ['FRUIT', 'FRUIT']
    >>>                  })
    >>> ner_data_prep = NERSpacyDataPrep()
    >>> df_with_index = ner_data_prep.get_ner_index(dataframe = df,
    >>>                                             textcol = 'text',
    >>>                                             entitycol = 'entity',
    >>>                                             labelcol = 'label')
    >>> df_with_index['text']
    >>> ['This is a sentence about apples.', 'Apples are a type of fruit.']
    >>> df_with_index['entity']
    >>> ['apples', 'apples']
    >>> df_with_index['label']
    >>> ['FRUIT', 'FRUIT']
    >>> df_with_index['entity_index']
    >>> [[(10, 16, 'FRUIT')], (0, 6, 'FRUIT')]
    >>> nlp = spacy.load("en_core_web_sm")
    >>> ner_data_prep.generate_corpus(dataframe = df_with_index,
    >>>                               textcol = 'text',
    >>>                               entity_index_col = 'entity_index',
    >>>                               basename = 'train',
    >>>                               nlp = nlp,
    >>>                               corpus_path = 'project_folder/corpus')

    """

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """NERSpacyDataPrep class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def get_ner_index(
        self,
        dataframe: pd.DataFrame,
        textcol: str,
        entitycol: str,
        labelcol: str,
        spacy_model: str = "en_core_web_sm",
    ):
        """This function adds a column to the dataframe containing a list of tuples, with each tuple containing the start index, end index, and label associated with an entity.

        Note: Can be computationally heavy for large datasets.

        Parameters
        ----------
        dataframe : pd.DataFrame
            Dataframe containing the text, entity and label column.
        textcol : str
            Column name of the text column in the dataframe.
        entitycol : str
            Column name of the entity column in the dataframe.
        labelcol : str
            Column name of the label column in the dataframe.
        spacy_model : str
            The spacy model to be loaded, default is 'en_core_web_sm'.

        Returns
        -------
        dataframe : pd.DataFrame
            Dataframe with additional column 'entity_index' which contains the tuple of start_index,end_index and label of an entity.

        Raises
        ------
        TypeError
            raises type error when dataframe is not of pd.DataFrame type.
        NameError
            raises name error when textcol, labelcol, entitycol not present in dataframe.
        ValueError
            raises value error when dataframe is empty.
        Exception
            raises exception when error occurs while adding the 'entity_index' column to the dataframe.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.custom_ner.api import NERSpacyDataPrep
        >>> df = pd.DataFrame({
        >>>                   'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
        >>>                   'entity': ['apples', 'apples'],
        >>>                   'label': ['FRUIT', 'FRUIT']
        >>>                  })
        >>> ner_data_prep = NERSpacyDataPrep()
        >>> df_with_index = ner_data_prep.get_ner_index(dataframe = df,
        >>>                                             textcol = 'text',
        >>>                                             entitycol = 'entity',
        >>>                                             labelcol = 'label')
        >>> df_with_index['text']
        >>> ['This is a sentence about apples.', 'Apples are a type of fruit.']
        >>> df_with_index['entity']
        >>> ['apples', 'apples']
        >>> df_with_index['label']
        >>> ['FRUIT', 'FRUIT']
        >>> df_with_index['entity_index']
        >>> [[(10, 16, 'FRUIT')], (0, 6, 'FRUIT')]


        """
        try:
            if not isinstance(dataframe, pd.DataFrame):
                self.logger.error("Input dataframe is of incorrect type in get_ner_index")
                raise TypeError("Input dataframe is of incorrect type in get_ner_index")
            if not (dataframe.shape[0]) > 0:
                self.logger.error("Recieved empty dataframe.")
                raise ValueError("Recieved empty dataframe.")
            elif textcol not in dataframe.columns.to_list():
                self.logger.error(f"Given column is not a valid column in the dataframe - {textcol}")
                raise NameError(f" {dataframe} is not present in the dataframe.")
            elif entitycol not in dataframe.columns.to_list():
                self.logger.error(f"Given column is not a valid column in the dataframe - {entitycol}")
                raise NameError(f" {entitycol} is not present in the dataframe.")
            elif labelcol not in dataframe.columns.to_list():
                self.logger.error(f"Given column is not a valid column in the dataframe - {labelcol}")
                raise NameError(f" {labelcol} is not present in the dataframe.")

            nlp = spacy.load(spacy_model)
            dataframe["entity_index"] = dataframe.apply(

                lambda row: generate_index_labels(
                    row[textcol], list(row[entitycol]), list(row[labelcol]), nlp
                ),
                axis=1,
            )
            return dataframe

        except Exception as e:
            self.logger.error(
                f"An error occurred while adding the 'entity_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )
            raise Exception(
                f"An error occurred while adding the 'entity_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )

    def generate_corpus(
        self,
        dataframe: pd.DataFrame,
        textcol: str,
        entity_index_col: str,
        basename: str,
        nlp: spacy.language.Language,
        corpus_path: str,
    ):
        """This function generates a corpus in spacy format from a dataframe.

        Parameters
        ----------
        dataframe : pd.DataFrame
            Dataframe containing the text and entity_index column.
        textcol : str
            Column name of the text column in the dataframe.
        entity_index_col : str
            Column name of the entity_index column in the dataframe.
        basename : str
            Name for the generated corpus file. Example - "train", "test", "val".
        nlp : spacy.language.Language
            Spacy language model.
        corpus_path : str
            Path to save the generated corpus. Example - 'project_folder/corpus'

        Returns
        -------
            The function does not return any value. It saves the corpus in the specified corpus_path.

        Raises
        ------
        ValueError
            raises value error when data frame is empty.
        NameError
            raises name error if textcol or entity_index_col is not present in dataframe.
        Exception
            raises exception if an error occurs during the generation of the corpus.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.custom_ner.api import NERSpacyDataPrep
        >>> df = pd.DataFrame({
        >>>                   'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
        >>>                   'entity_index': [[(10, 16, 'FRUIT')], [(0, 6, 'FRUIT')]]
        >>>                  })
        >>> ner_data_prep = NERSpacyDataPrep()
        >>> nlp = spacy.load("en_core_web_sm")
        >>> ner_data_prep.generate_corpus(dataframe = df_with_index,
        >>>                             textcol = 'text',
        >>>                             entity_index_col = 'entity_index',
        >>>                             basename = 'train',
        >>>                             nlp = nlp,
        >>>                             corpus_path = 'project_folder/corpus')



        """
        try:
            if not isinstance(dataframe, pd.DataFrame):
                self.logger.error("dataframe must be a pd.DataFrame.")
                raise TypeError("dataframe must be a pd.DataFrame.")
            if not (dataframe.shape[0]) > 0:
                self.logger.error("Input dataframe is empty")
                raise ValueError("Input dataframe is empty")
            elif textcol not in dataframe.columns.to_list():
                self.logger.error(f"Given column is not a valid column in the dataframe - {textcol}")
                raise NameError(f"{textcol} is not present in the dataframe.")
            elif entity_index_col not in dataframe.columns.to_list():
                self.logger.error(f"Given column is not a valid column in the dataframe - {entity_index_col}")
                raise NameError(f" {entity_index_col} is not present in the dataframe.")

            if not os.path.exists(corpus_path):
                os.makedirs(corpus_path)

            db = DocBin()
            for text, annotations in zip(dataframe[textcol], dataframe[entity_index_col]):
                doc = nlp.make_doc(text)
                ents = []
                for start, end, label in annotations:
                    span = doc.char_span(start, end, label=label)
                    if span is not None:
                        ents.append(span)
                if len(ents) == 0:
                    continue
                doc.ents = ents
                db.add(doc)
            db.to_disk(os.path.join(corpus_path, f"{basename}.spacy"))

        except Exception as e:
            self.logger.error(f"An error occurred while generating the corpus in the spacy format. The error message is: {e}.")
            raise ValueError(f"An error occurred while generating the corpus in the spacy format. The error message is: {e}.")

"""This module is for action object post processing.
"""

import os
import pandas as pd
import spacy
import traceback
from typing import Dict, List, Optional, Tuple, Union

from tigernlp.core.api import MyLogger, spacy_download_validate

from .utils import get_ao_frequency


def _match_spacy_labels(
    entity_list_and_labels: List[Tuple[str, str]], spacy_labels: list, aopp_logger: MyLogger
) -> bool:
    """Helper function which iterates through entity list and their labels. Returns true if the entity matches any label from the specified spacy labels, else false.

    Parameters
    ----------
    entity_list_and_labels : List[Tuple[str, str]]
        List of tuples of entities and their labels for a single action object pair

    spacy_labels : list
        List of spacy labels for NER to match

    aopp_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    bool
        True, if label matches. Else, returns False.
    """
    # TODO: Maybe moved to text processing if there is a wider need.
    if spacy_labels is None:
        spacy_labels = [
            "CARDINAL",
            "DATE",
            "ORDINAL",
            "NORP",
            "PERCENT",
            "PERSON",
            "QUANTITY",
            "TIME",
            "WORK_OF_ART",
        ]

    for entity, label in entity_list_and_labels:
        if label in spacy_labels:
            aopp_logger.debug(f"Entity {entity} having label {label} is considered as stopword.")
            return True

    return False


def _has_stopwords(
    ao_pairs: Tuple[str, str],
    stopwords: list,
    ignore_context_words: dict,
    aopp_logger: MyLogger,
) -> bool:
    """Checks whether any stop words are present in our entity list. If yes, return true, else return false.

    Parameters
    ----------
    ao_pairs : Tuple[str, str]
        List of tuples containing entities and their entity spacy labels for all action object pairs identified (output of action object pair detection)

    stopwords : list
        List of user defined stopwords

    ignore_context_words: dict
        A dictionary containing key as stopword and value as a list of words to ignore.
        Example `ignore_context_words={'check':'video'}`. This means that when removing stop word 'check',
        if a word 'video' is present then don't remove that action object pair.

    aopp_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    bool
        True, if it has stopword. Else, returns False
    """
    # TODO to be moved to text processing after merge to /dp/initial branch is done.
    if stopwords is None:
        stopwords = []
    if ignore_context_words is None:
        ignore_context_words = {}

    all_words = " ".join(ao_pairs).lower().strip().split()
    for stopword in stopwords:
        if stopword in all_words and all(
            word not in all_words for word in ignore_context_words[stopword]
        ):
            aopp_logger.debug(f"Stopword {stopword} is found in the pair {ao_pairs}.")
            return True

    return False


def _has_stoppairs(
    ao_pairs: Tuple[str, str],
    stop_pairs: list,
) -> bool:
    """Checks whether any stop pairs are present in our aop list. If yes, return true, else return false.

    Parameters
    ----------
    ao_pairs : Tuple[str, str]
        List of tuples containing entities and their entity spacy labels for all action object pairs identified (output of action object pair detection)

    stop_pairs : list
        List of user defined stop pairs

    Returns
    -------
    bool
        True, if it has stopword. Else, returns False
    """
    if stop_pairs is None:
        stop_pairs = []

    ao_pairs = " ".join(ao_pairs).lower()
    return ao_pairs in stop_pairs


def _check_action_object(
    act_obj_pairs: List[dict],
    user_defined_stopwords: list,
    custom_rules_stopwords: list,
    ignore_context_words: dict,
    stop_pairs: list,
    lemmatize: bool,
    aopp_logger: MyLogger,
) -> List[dict]:
    """Helper method that sets a key 'to_remove' in the input act_obj_pairs for available stopwords or labels for stopwords

    Parameters
    ----------
    act_obj_pairs : List[dict]
        Same format as the caller's

    user_defined_stopwords : list
        User defined Stopwords in the form of a list, by default None

    custom_rules_stopwords : list
        Rules defined as Spacy labels in the form of a list. It can also be given by the user., by default ["CARDINAL", "DATE", "ORDINAL", "NORP", "PERCENT", "PERSON", "QUANTITY",   "TIME", "WORK_OF_ART"]

    ignore_context_words: dict
        A dictionary containing key as stopword and value as a list of words to ignore.
        Example `ignore_context_words={'check':'video'}`. This means that when removing stop word 'check',
        if a word 'video' is present then don't remove that action object pair.

    stop_pairs: list
        List of pairs to remove from act_obj_pairs

    lemmatize: Optional[bool], optional, by default False
        If true, uses lemmatized column in the dataframe for processing. It also lemmatizes the user defined stopwords or stopwords if it's not None. If false, it assumes user defined stopwords or stopwords are not lemmatized and will be used as is to filter action object pair.

    aopp_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    List[dict]
        Same format as the act_obj_pairs with one additional key 'to_remove'
    """
    for act_obj in act_obj_pairs:
        # Check for user given stop words
        if user_defined_stopwords:
            if lemmatize:
                # List with blank is so that tuple creation doesn't fail when act obj pair has missing key.
                user_stopwords_test = _has_stopwords(
                    ao_pairs=act_obj.get("pairs_lemma", tuple()),
                    stopwords=user_defined_stopwords,
                    ignore_context_words=ignore_context_words,
                    aopp_logger=aopp_logger,
                )
            else:
                user_stopwords_test = _has_stopwords(
                    ao_pairs=act_obj.get("pairs", tuple()),
                    stopwords=user_defined_stopwords,
                    ignore_context_words=ignore_context_words,
                    aopp_logger=aopp_logger,
                )
        else:
            user_stopwords_test = False

        if stop_pairs is not None and not user_stopwords_test:
            # No need to check for stop pair if stop word already exists above
            # As it will get removed anyway
            user_stopwords_test = _has_stoppairs(
                ao_pairs=act_obj.get("pairs_lemma", tuple())
                if lemmatize
                else act_obj.get("pairs", tuple()),
                stop_pairs=stop_pairs,
            )

        # If user doesn't give stop words or failed the test, check against custom rules
        if not user_stopwords_test:
            act_obj["to_remove"] = _match_spacy_labels(
                entity_list_and_labels=act_obj.get("named_entities", []),
                spacy_labels=custom_rules_stopwords,
                aopp_logger=aopp_logger,
            )
        else:
            act_obj["to_remove"] = True

    return act_obj_pairs


def _filter_action_object_pairs(
    act_obj_pairs: List[dict],
    aopp_logger: MyLogger,
    user_defined_stopwords: Optional[list] = None,
    custom_rules_stopwords: Optional[list] = None,
    ignore_context_words: Optional[Dict[str, List[str]]] = None,
    stop_pairs: Optional[list] = None,
    return_pairs_only: Optional[bool] = True,
    lemmatize: Optional[bool] = False,
) -> list:
    """For given action object pairs, it filters based on user defined stopwords and custom rule based stopwords using entity types.

    Parameters
    ----------
    act_obj_pairs : List[dict]

        It is of the form::

        [
                {'pairs': ('ANNOUNCEMENT AAA of BBB', 'joins'),
           'pairs_lemma': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                 'named_entities': [('ANNOUNCEMENT AAA', 'PERSON')],
                 'pairs_pos_lemma': [('ANNOUNCEMENT AAA', 'PROPN'), ('of', 'ADP'), ('BBB', 'PROPN'), ('join', 'VERB')]},
            {'pairs': ('CCC', 'joins'),
           'pairs_lemma': ('CCC', 'joins'),
                'named_entities': [('CCC', 'GPE')],
                'pairs_pos_lemma': [('CCC', 'PROPN'), ('join', 'VERB')]},
            {'pairs': ('joins as', 'Advisory Board Member'),
           'pairs_lemma': ('join as', 'Advisory Board Member'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Advisory Board Member', 'PROPN')]},
                {'pairs': ('joins as', 'Investor'),
           'pairs_lemma': ('join as', 'Investor'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Investor', 'PROPN')]}
        ]

    aopp_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    user_defined_stopwords : Optional[list], optional
        User defined Stopwords in the form of a list, by default None

    custom_rules_stopwords : Optional[list], optional
        Rules defined as Spacy labels in the form of a list. It can also be given by the user., by default ["CARDINAL", "DATE", "ORDINAL", "NORP", "PERCENT", "PERSON", "QUANTITY",   "TIME", "WORK_OF_ART"]

    ignore_context_words: Optional[Dict[str, List[str]]]
        A dictionary containing key as stopword and value as a list of words to ignore.
        Example `ignore_context_words={'check':'video'}`. This means that when removing stop word 'check',
        if a word 'video' is present then don't remove that action object pair.

    stop_pairs: Optional[list], optional
        List of pairs to remove from act_obj_pairs

    return_pairs_only: Optional[bool], optional, by default True
        If True, each row will contain action object pair as list of tuples. Format::

        [
            ('ANNOUNCEMENT AAA of BBB', 'joins'),
            ('joins as', 'Advisory Board Member')
        ]

        else, format will be same as the input action object pair.

    lemmatize: Optional[bool], optional, by default False
        If true, uses lemmatized column in the dataframe for processing. It also lemmatizes the user defined stopwords or stopwords if it's not None. If false, it assumes user defined stopwords or stopwords are not lemmatized and will be used as is to filter action object pair.


    Returns
    -------
    list
        if return_pairs_only is false, format will be same as input action object pair format (i.e., list of dicts) . Otherwise, format will be list of action object pairs (i.e., list of tuples).


    Raises
    ------
    ValueError
        If any of the mandatory argument is missing or invalid
    """
    if act_obj_pairs is None:
        raise ValueError("Action object pair is not entered or empty.")
    elif not isinstance(act_obj_pairs, list):
        raise ValueError("Action object pair must be given as a list.")
    elif user_defined_stopwords is not None and not isinstance(user_defined_stopwords, list):
        raise ValueError("stop words must be of list type or None.")
    elif custom_rules_stopwords is not None and not isinstance(custom_rules_stopwords, list):
        raise ValueError("custom_rules_stopwords must be of list type or None.")
    elif (
        isinstance(act_obj_pairs, list)
        and len(act_obj_pairs) > 0
        and not isinstance(act_obj_pairs[0], dict)
    ):
        raise ValueError(
            "Action object pairs must be list of dictionary. Check docstrings of post_process_action_object_pairs function for the format."
        )

    # For empty pair, return empty
    if not act_obj_pairs:
        return []

    act_obj_pairs = _check_action_object(
        act_obj_pairs=act_obj_pairs,
        user_defined_stopwords=user_defined_stopwords,
        custom_rules_stopwords=custom_rules_stopwords,
        ignore_context_words=ignore_context_words,
        stop_pairs=stop_pairs,
        lemmatize=lemmatize,
        aopp_logger=aopp_logger,
    )

    # Now create the filtered action object pair result and return it
    filtered_act_obj_pairs = []
    if return_pairs_only:
        for act_obj in act_obj_pairs:
            if not act_obj.get("to_remove", True):
                if lemmatize:
                    # pair_pos_lemma is list of lemma phrases with pos tags. if key is missing, we pass empty list.
                    filtered_act_obj_pairs.append(act_obj.get("pairs_lemma", tuple()))
                else:
                    filtered_act_obj_pairs.append(act_obj.get("pairs", tuple()))
            # Remove "to_remove" key
            act_obj.pop("to_remove", None)
    else:
        for act_obj in act_obj_pairs:
            # Remove the to_remove which we added as part of this filtering logic.
            if not act_obj.get("to_remove", True):
                # Build a new dict that needs to have only necessary information
                current_act_obj = {
                    k: v for k, v in act_obj.items() if k not in ["to_remove", "named_entities"]
                }
                filtered_act_obj_pairs.append(current_act_obj)

            # Remove "to_remove" key
            act_obj.pop("to_remove", None)

    if len(act_obj_pairs) != len(filtered_act_obj_pairs):
        aopp_logger.debug(
            f"For the current action object pair, number of pairs is reduced from {len(act_obj_pairs)} to {len(filtered_act_obj_pairs)}"
        )

    return filtered_act_obj_pairs


def _remove_pairs_based_on_rules(
    act_obj_pairs: List[dict], based_on: str, ao_pair_freq: dict, return_pairs_only: bool = True
) -> list:
    """Helper function to remove the action object pair which is not present in ``ao_pair_freq``.

    Parameters
    ----------
    act_obj_pairs : List[dict]

        It is of the form::

        [
                {'pairs': ('ANNOUNCEMENT AAA of BBB', 'joins'),
           'pairs_lemma': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                 'named_entities': [('ANNOUNCEMENT AAA', 'PERSON')],
                 'pairs_pos_lemma': [('ANNOUNCEMENT AAA', 'PROPN'), ('of', 'ADP'), ('BBB', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('CCC', 'joins'),
           'pairs_lemma': ('CCC', 'joins'),
                'named_entities': [('CCC', 'GPE')],
                'pairs_pos_lemma': [('CCC', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('joins as', 'Advisory Board Member'),
           'pairs_lemma': ('join as', 'Advisory Board Member'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Advisory Board Member', 'PROPN')]},
                {'pairs': ('joins as', 'Investor'),
           'pairs_lemma': ('join as', 'Investor'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Investor', 'PROPN')]}
        ]

    based_on: str, optional
        Consider either the pairs or pairs_lemma to drop less frequent action object pair.

    ao_pair_freq : dict
        Dictionary where key is action object pair and value is the count of its occurrence.

    return_pairs_only: Optional[bool], optional, by default True
        If True, each row will contain action object pair as list of tuples. Format::

        [
            ('ANNOUNCEMENT AAA of BBB', 'joins'),
            ('joins as', 'Advisory Board Member')
        ]

        else, format will be same as the input action object pair.

    Returns
    -------
    list
        if return_pairs_only is false, format will be same as input action object pair format (i.e., list of dicts) . Otherwise, format will be list of action object pairs (i.e., list of tuples).
    """
    # For empty pair, return empty
    if not act_obj_pairs:
        return []

    # Now create the filtered action object pair result and return it
    filtered_act_obj_pairs = []
    if return_pairs_only:
        for act_obj in act_obj_pairs:
            if act_obj.get(based_on) in ao_pair_freq.keys():
                filtered_act_obj_pairs.append(act_obj.get(based_on))
    else:
        for act_obj in act_obj_pairs:
            if act_obj.get(based_on) in ao_pair_freq.keys():
                filtered_act_obj_pairs.append(act_obj)

    return filtered_act_obj_pairs


def _drop_less_frequent_pairs(
    act_obj_df: pd.DataFrame,
    act_obj_col: str = "processed_action_object_pairs",
    id_col: str = "id",
    based_on: str = "pairs_lemma",
    occurrence_threshold: int = 0,
    return_pairs_only: bool = True,
) -> Tuple[pd.DataFrame, dict]:
    """This calculates frequency of action object pair at call level i.e., if an action object pair occurs n times in one call, it will be counted as one occurrence only. Thus if a pair occurs less than ``occurrence_threshold`` in the given call corpus, then that particular pair is dropped. Before running this, ensure ``post_process_action_object_pairs`` is run with ``return_pairs_only=False`` parameter in that function.

    Parameters
    ----------
    act_obj_df : pd.DataFrame
        Our Action object dataframe with processed text, action object pairs for each conversation block. Output of action object pair where each row contains action object pair for a conversation block. It is of the format::

        [
                {'pairs': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                 'named_entities': [('ANNOUNCEMENT AAA', 'PERSON')],
                 'pairs_pos_lemma': [('ANNOUNCEMENT AAA', 'PROPN'), ('of', 'ADP'), ('BBB', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('CCC', 'joins'),
                'named_entities': [('CCC', 'GPE')],
                'pairs_pos_lemma': [('CCC', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('joins as', 'Advisory Board Member'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Advisory Board Member', 'PROPN')]},
                {'pairs': ('joins as', 'Investor'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Investor', 'PROPN')]}
        ]

    act_obj_col: str, optional
        Enter the column which will have processed action object pair. by default it's processed_action_object_pairs.

    id_col: str, optional
        Enter the column which has ID value. by default it's id.

    based_on: str, optional
        Consider either the pairs or pairs_lemma to drop less frequent action object pair.

    occurrence_threshold : int, optional
        if occurrence count of each pair falls below the threshold, pair is dropped, by default 5

    return_pairs_only: Optional[bool], optional, by default True
        If True, each row will contain action object pair as list of tuples. Format::

        [
            ('ANNOUNCEMENT AAA of BBB', 'joins'),
            ('joins as', 'Advisory Board Member')
        ]

        else, format will be same as the input action object pair.

    Returns
    -------
    pd.DataFrame
        Our Action object dataframe with processed text and action object pairs for each conversation block.

    dict
        Dictionary with action object pair as key and their count at call level as value.

        For example::

            {
                ("buy", "apple"): 10,
                ("sell", "pizza"): 5
            }

    Raises
    ------
    ValueError
        If any of the argument is missing or invalid.
    """
    if act_obj_df is None or not isinstance(act_obj_df, pd.DataFrame):
        raise ValueError("action object should be entered as valid pandas dataframe.")
    elif act_obj_col not in act_obj_df.columns:
        raise ValueError(f"column {act_obj_col} is not present in the input dataframe")
    elif occurrence_threshold is None or not isinstance(occurrence_threshold, int):
        raise ValueError("occurrence_threshold must be of integer type.")
    else:
        sample_valid_data = act_obj_df.iloc[0]
        # Check the format is list of dicts
        if isinstance(sample_valid_data[act_obj_col], list):
            if not sample_valid_data[act_obj_col]:
                if not all(isinstance(item, dict) for item in sample_valid_data[act_obj_col]):
                    raise ValueError(
                        "Input must be list of dictionaries as given in the docstrings of post_process_action_object_pairs function."
                    )
        else:
            raise ValueError(
                "Input must be list of dictionaries as given in the docstrings of post_process_action_object_pairs function."
            )

    # Create a temp column based on "based_on"
    temp_col = "final_" + based_on
    frequent_act_obj_df = act_obj_df.copy(deep=True)

    # Each row is list of dict
    # Each dict contains several keys. we are getting value of particular key either 'pairs' or 'pairs_lemma'
    # Value will be a tuple, We then sort the tuple so that pairs such as  (a, b) and (b, a) will be changed to (a,b).
    frequent_act_obj_df[temp_col] = frequent_act_obj_df[act_obj_col].apply(
        lambda x: [tuple(pair.get(based_on)) for pair in x]
    )

    # Set each pair as a row. This doesnt reset index.
    frequent_act_obj_df = frequent_act_obj_df.explode(column=temp_col)

    # If there is no ID column, then there is no need to find unique occurrence of AO pairs in each call.
    # If occurrence threshold is 0, it means we are not filtering any pairs, so no need to find unique occurrence of AO pairs in each call.
    if id_col is not None and occurrence_threshold > 0:
        # Count multiple occurrences of same action object pair as one in a single call.
        frequent_act_obj_df = frequent_act_obj_df[[id_col, temp_col]].drop_duplicates()

    # Count occurrence of each ao pair
    act_obj_pair_freq = frequent_act_obj_df[temp_col].value_counts()
    act_obj_pair_freq = act_obj_pair_freq.loc[act_obj_pair_freq >= occurrence_threshold].to_dict()

    # Create a new column for the final pair.
    act_obj_df[temp_col] = act_obj_df[act_obj_col].apply(
        _remove_pairs_based_on_rules,
        ao_pair_freq=act_obj_pair_freq,
        based_on=based_on,
        return_pairs_only=return_pairs_only,
    )

    # Drop the previous act_obj_col and rename the new column to act_obj_col
    act_obj_df = act_obj_df.drop(columns=act_obj_col)
    act_obj_df = act_obj_df.rename(columns={temp_col: act_obj_col})

    return act_obj_df, act_obj_pair_freq


def _is_subset(sub_list, main_list):
    return set(sub_list) <= set(main_list)


def _lemmatize_phrase(nlp, phrase):
    """Lemmatizes single word or phrase"""
    doc = nlp(phrase)
    return " ".join(token.lemma_ for token in doc).strip()


def post_process_action_object_pairs(
    act_obj_df: pd.DataFrame,
    act_obj_col: str = "action_object_pairs",
    new_act_obj_col: str = "processed_action_object_pairs",
    id_col: str = "id",
    user_defined_stopwords: Optional[list] = None,
    custom_rules_stopwords: Optional[list] = None,
    ignore_context_words: Optional[Dict[str, Union[str, List[str]]]] = None,
    stop_pairs: Optional[List[Union[Tuple[str, str], str]]] = None,
    return_pairs_only: Optional[bool] = True,
    lemmatize: Optional[bool] = False,
    spacy_or_nltk: Optional[str] = "spacy",
    occurrence_threshold: Optional[int] = 0,
    en_core_web_sm_path: Optional[str] = None,
    logging_level: str = "WARNING",
    log_file_path=None,
    verbose=True,
) -> Tuple[pd.DataFrame, dict]:
    """For the given input action object dataframe, use the column ``action_object_pairs`` to filter action object pairs that has user given stopwords (nouns and/or verbs) and custom rules (entity types) in them.

    Parameters
    ----------
    act_obj_df : pd.DataFrame
        Output of action object pair where each row contains action object pair for a conversation block. It is of the format::

            [
                {'pairs': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                'pairs_lemma': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                'named_entities': [('ANNOUNCEMENT AAA', 'PERSON')],
                'pairs_pos_lemma': [('ANNOUNCEMENT AAA', 'PROPN'), ('of', 'ADP'), ('BBB', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('CCC', 'joins'),
                'pairs_lemma': ('CCC', 'joins'),
                'named_entities': [('CCC', 'GPE')],
                'pairs_pos_lemma': [('CCC', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('joins as', 'Advisory Board Member'),
                'pairs_lemma': ('join as', 'Advisory Board Member'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Advisory Board Member', 'PROPN')]},
                {'pairs': ('joins as', 'Investor'),
                'pairs_lemma': ('join as', 'Investor'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Investor', 'PROPN')]}
            ]

        In this list, each dict contains information about one action object pair. Values of "pairs" gives the action object pair whereas "pairs_lemma" gives the lemmatized version of action object pair. Either of these two will be used for clustering. Value of "named_entities" gives the entity along with it's label if present. It is primarily used as criteria for dropping an action object pair. Value of "pairs_pos_lemma" gives us the pos tags of action object pair. This is primarily used in identifying stopwords by histogram.

    act_obj_col: str, optional
        Enter the column which has action object pair. by default it's action_object_pairs.

    new_act_obj_col: str, optional
        Enter the column which will have processed action object pair. by default it's processed_action_object_pairs.

    id_col: str, optional
        Enter the column which has ID value. by default it's id.

    user_defined_stopwords : Optional[list], optional
        User defined Stopwords in the form of a list, by default None

    custom_rules_stopwords : Optional[list], optional
        Rules defined as Spacy labels in the form of a list. It can also be given by the user., by default ["CARDINAL", "DATE", "ORDINAL", "NORP", "PERCENT", "PERSON", "QUANTITY",   "TIME", "WORK_OF_ART"]

    ignore_context_words: Optional[Dict[str, Union[str, List[str]]]]
        A dictionary containing key as stopword and value as a word or list of words to ignore.
        Example `ignore_context_words={'check':'video'}`. This means that when removing stop word 'check',
        if a word 'video' is present then don't remove that action object pair.

    stop_pairs: Optional[List[Union[Tuple[str, str], str]]], optional
        List of pairs to remove from act_obj_pairs. Item inside list can be a tuple or joined string.
        For example `stop_pairs=[('bring', 'item1'), 'bring item2']`.

    return_pairs_only: Optional[bool], optional, by default True
        If True, each row will contain action object pair as list of tuples. Format::

            [
                ('ANNOUNCEMENT AAA of BBB', 'joins'),
                ('joins as', 'Advisory Board Member')
            ]

        else, format will be same as the input action object pair.

    lemmatize: Optional[bool], optional, by default False
        If true, uses lemmatized column in the dataframe for processing. It also lemmatizes the user defined stopwords or stopwords if it's not None. If false, it assumes user defined stopwords or stopwords are not lemmatized and will be used as is to filter action object pair.

    spacy_or_nltk: Optional[str], optional, by default spacy
        if spacy, uses spacy's lemmatizer. Else uses nltk's lemmatizer.

    occurrence_threshold : int, optional
        if action object pair occurs in less than certain number (threshold) of calls, it is dropped, by default 0 i.e., don't drop any action object pair. When occurrence_threshold is 0, id column will not be considered for counting and we will get the term frequency of each action object pair.

    en_core_web_sm_path: str, optional, by default None
            If unable to download en_core_web_sm model, location can be provided manually here. Pass value to this parameter if ``lemmatize = True`` as we need spacy's lemmatizer. If ``lemmatize = False``, this parameter can be ignored.

    logging_level: str, optional
        Enter the level of logging. by default, its "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Returns
    -------
    Tuple[pd.DataFrame, dict]

        pd.DataFrame
            Dataframe with modified action object pairs as a new column ``processed_action_object_pairs``. New column format will be same as input action object pair format if ``return_pairs_only`` is false. Otherwise, each row in new column will be a list of action object pairs.

        dict
            Dictionary with action object pair as key and their count at call level as value.

            For example::

                {
                    ("buy", "apple"): 10,
                    ("sell", "pizza"): 5
                }

    Raises
    ------
    ValueError
        If any of the mandatory argument is missing or invalid.

    Example
    -------
    >>> final_ao_pairs_df, ao_pair_counts = post_process_action_object_pairs(act_obj_df=ip_df)
    """
    # TODO: Instead of dropping the ao pair, replace the stopword in ao pair. maybe it can be useful.

    # Set logging
    aopp_logger = MyLogger(
        level=logging_level, log_file_path=log_file_path, verbose=verbose
    ).logger

    # check if id_col is present in df, else set it to None.
    if id_col not in act_obj_df.columns:
        aopp_logger.info(
            f"ID column : {id_col} is not present in the dataframe. Thus, it will be set to None."
        )
        id_col = None

    # Validate spacy pipeline
    if spacy_or_nltk == "spacy" and lemmatize:
        # If en_core_web_sm is manually downloaded and its path is provided
        if en_core_web_sm_path:
            if not os.path.isdir(en_core_web_sm_path):
                # Raise an error in case of invalid directory
                raise ValueError(f"{en_core_web_sm_path} is not a valid directory")

            try:
                # Load the nlp model from given path
                nlp = spacy.load(en_core_web_sm_path, disable=["parser", "ner"])
            except Exception:
                aopp_logger.error(traceback.format_exc())
                aopp_logger.info(
                    "Download the en_core_web_sm 3.3.0 model from https://github.com/explosion/spacy-models/releases/tag/en_core_web_sm-3.3.0."
                )
                aopp_logger.info(
                    "Make sure the right en_core_web_sm path is passed to the module as follows"
                )
                aopp_logger.info(
                    ">>> final_ao_pairs_df, ao_pair_counts = post_process_action_object_pairs(act_obj_df=ip_df, en_core_web_sm_path='en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0')"
                )
        else:
            ret = spacy_download_validate("en_core_web_sm")

            if ret:  # If model is successfully downloaded or validated
                # Load the nlp model
                nlp = spacy.load("en_core_web_sm", disable=["parser", "ner"])
            else:
                aopp_logger.info(
                    "Model can be loaded as follows by specifying en_core_web_sm_path parameter"
                )
                aopp_logger.info(
                    ">>> final_ao_pairs_df, ao_pair_counts = post_process_action_object_pairs(act_obj_df=ip_df, en_core_web_sm_path='en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0')"
                )
                raise ValueError("Unable to find en_core_web_sm pipeline.")

    if act_obj_df is None or not isinstance(act_obj_df, pd.DataFrame):
        raise ValueError("action object should be entered as valid pandas dataframe.")
    elif act_obj_col not in act_obj_df.columns:
        raise ValueError(f"column {act_obj_col} is not present in the input dataframe")

    if stop_pairs is not None:
        if not isinstance(stop_pairs, list):
            raise ValueError(
                f'Expected parameter "stop_pairs" to be None or list. Got "{type(stop_pairs)}".'
            )

    # modified_act_obj_df = act_obj_df.copy(deep=True)

    if stop_pairs is not None:
        # Convert to a tuple of tuples with lower case to compare using _has_stoppairs func
        stop_pairs = tuple(
            pair.lower() if isinstance(pair, str) else " ".join(pair).lower()
            for pair in stop_pairs
        )

        freq_df = get_ao_frequency(act_obj_df, column=act_obj_col, lemma=lemmatize)
        freq_df[f"{act_obj_col}_string"] = freq_df[act_obj_col].apply(
            lambda x: " ".join(x).lower()
        )
        all_ao_pairs = freq_df[f"{act_obj_col}_string"].values
        if not _is_subset(stop_pairs, all_ao_pairs):
            raise ValueError('pairs in "stop_pairs" are not present in the dataset')

    if lemmatize:
        if user_defined_stopwords:  # checks for both None and empty list
            # TODO Replace with text processing call.
            lemmatized_stopwords = []
            for word in user_defined_stopwords:
                doc = nlp(word.lower())
                for token in doc:
                    lemmatized_stopwords.append(token.lemma_)

            user_defined_stopwords = list(set(lemmatized_stopwords))

    if user_defined_stopwords is not None:
        if ignore_context_words is None:
            ignore_context_words = {stopword: [] for stopword in user_defined_stopwords}
        else:
            if not isinstance(ignore_context_words, dict):
                raise ValueError(
                    f'Expected parameter "ignore_context_words" to be None or dict. Got "{type(ignore_context_words)}".'
                )

            # Create new dict to store lemmatized context words
            lemmatized_ignore_context_words = {}
            # Create a list to store stopwords not present in ignore_context_words
            stopwords_not_in_ignore_context_words = user_defined_stopwords.copy()
            # Convert words for each key into lower and put it in a list
            for key, value in ignore_context_words.items():
                # Make sure key is a string
                if not isinstance(key, str):
                    raise ValueError(
                        f'Expected "ignore_context_words" to have a key to be string. Got {type(key)}'
                    )

                # Lemmatize and convert key to lower
                key = _lemmatize_phrase(nlp, key.lower()) if lemmatize else key.lower()

                if key not in user_defined_stopwords:
                    raise ValueError(
                        f'Key "{key}" {"(lemmatized) " if lemmatize else ""}not found in "user_defined_stopwords"'
                    )
                else:
                    # Since this stop word exists as key in ignore_context_words, remove it from this list
                    stopwords_not_in_ignore_context_words.remove(key)

                if isinstance(value, list):
                    if lemmatize:
                        lemmatized_ignore_context_words[key] = [
                            _lemmatize_phrase(nlp, word.lower()) for word in value
                        ]
                    else:
                        lemmatized_ignore_context_words[key] = [word.lower() for word in value]
                elif isinstance(value, str):
                    if lemmatize:
                        lemmatized_ignore_context_words[key] = [
                            _lemmatize_phrase(nlp, value.lower())
                        ]
                    else:
                        lemmatized_ignore_context_words[key] = [value.lower()]
                else:
                    raise ValueError(
                        f'Expected values in "ignore_context_words" to be list or str, got {type(value)}'
                    )
            ignore_context_words = lemmatized_ignore_context_words
            del lemmatized_ignore_context_words

            # For all the stopwords not present in ignore_context_words, add empty list to dict
            for stopword in stopwords_not_in_ignore_context_words:
                ignore_context_words[stopword] = []

    act_obj_df[new_act_obj_col] = act_obj_df[act_obj_col].apply(
        _filter_action_object_pairs,
        user_defined_stopwords=user_defined_stopwords,
        custom_rules_stopwords=custom_rules_stopwords,
        ignore_context_words=ignore_context_words,
        stop_pairs=stop_pairs,
        return_pairs_only=False,  # We set it to False as this is just an intermediate step and we need a full dict.
        lemmatize=lemmatize,
        aopp_logger=aopp_logger,
    )

    act_obj_df, ao_pair_counts = _drop_less_frequent_pairs(
        act_obj_df=act_obj_df,
        act_obj_col=new_act_obj_col,
        id_col=id_col,
        based_on="pairs_lemma",
        occurrence_threshold=occurrence_threshold,
        return_pairs_only=return_pairs_only,
    )

    return act_obj_df, ao_pair_counts


def filter_ao_pair_by_freq(
    act_obj_df: pd.DataFrame,
    act_obj_col: str = "action_object_pairs",
    based_on: str = "pairs_lemma",
    occurrence_threshold: int = 1,
    return_pairs_only: bool = True,
) -> Tuple[pd.DataFrame, dict]:
    """This calculates term frequency of action object pair across the entire corpus. If a pair occurs less than ``occurrence_threshold`` in the given call corpus, then that particular pair is dropped. Before running this, ensure ``post_process_action_object_pairs`` is run with ``return_pairs_only=False`` parameter in that function if this function is called after running ``post_process_action_object_pairs`` function.

    Parameters
    ----------
    act_obj_df : pd.DataFrame
        Action object dataframe with processed text, action object pairs for each conversation block. Output of action object pair where each row contains action object pair for a conversation block. It is of the format::

        [
                {'pairs': ('ANNOUNCEMENT AAA of BBB', 'joins'),
                 'named_entities': [('ANNOUNCEMENT AAA', 'PERSON')],
                 'pairs_pos_lemma': [('ANNOUNCEMENT AAA', 'PROPN'), ('of', 'ADP'), ('BBB', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('CCC', 'joins'),
                'named_entities': [('CCC', 'GPE')],
                'pairs_pos_lemma': [('CCC', 'PROPN'), ('join', 'VERB')]},
                {'pairs': ('joins as', 'Advisory Board Member'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Advisory Board Member', 'PROPN')]},
                {'pairs': ('joins as', 'Investor'),
                'named_entities': [],
                'pairs_pos_lemma': [('join', 'VERB'), ('as', 'ADP'), ('Investor', 'PROPN')]}
        ]

    act_obj_col: str, optional
        Enter the column which has action object pair. by default it's action_object_pairs.

    based_on: str, optional
        Consider either the pairs or pairs_lemma to drop less frequent action object pair.

    occurrence_threshold : int, optional
        if occurrence count of each pair falls below the threshold, pair is dropped, by default 1

    return_pairs_only: Optional[bool], optional, by default True
        If True, each row will contain action object pair as list of tuples. Format::

            [
                ('ANNOUNCEMENT AAA of BBB', 'joins'),
                ('joins as', 'Advisory Board Member')
            ]

        else, format will be same as the input action object pair.

    Returns
    -------
    Tuple[pd.DataFrame, dict]

        pd.DataFrame
            Action object dataframe with filtered action object pairs.

        dict
            Dictionary with action object pair as key and their count at call level as value.

            For example::

                {
                    ("buy", "apple"): 10,
                    ("sell", "pizza"): 5
                }

    Raises
    ------
    ValueError
        If any of the argument is missing or invalid.

    Example
    -------
    >>> filtered_pairs, ao_pair_count = filter_ao_pair_by_freq(act_obj_df=data, act_obj_col="action_object_pairs", occurrence_threshold=5)
    """
    if act_obj_df is None or not isinstance(act_obj_df, pd.DataFrame):
        raise ValueError("action object should be entered as valid pandas dataframe.")
    elif act_obj_col not in act_obj_df.columns:
        raise ValueError(f"column {act_obj_col} is not present in the input dataframe")
    elif occurrence_threshold is None or not isinstance(occurrence_threshold, int):
        raise ValueError("occurrence_threshold must be of integer type.")
    else:
        sample_valid_data = act_obj_df.iloc[0]
        # Check the format is list of dicts
        if isinstance(sample_valid_data[act_obj_col], list):
            if not sample_valid_data[act_obj_col]:
                if not all(isinstance(item, dict) for item in sample_valid_data[act_obj_col]):
                    raise ValueError(
                        "Input must be list of dictionaries as given in the docstrings of filter_ao_pair_by_freq function."
                    )
        else:
            raise ValueError(
                "Input must be list of dictionaries as given in the docstrings of filter_ao_pair_by_freq function."
            )

    # Create a temp column based on "based_on"
    temp_col = "final_" + based_on
    frequent_act_obj_df = act_obj_df.copy(deep=True)
    # act_obj_df = act_obj_df.copy(deep=True)

    # Each row is list of dict
    # Each dict contains several keys. we are getting value of particular key either 'pairs' or 'pairs_lemma'
    # Value will be a tuple, We then sort the tuple so that pairs such as  (a, b) and (b, a) will be changed to (a,b).
    frequent_act_obj_df[temp_col] = frequent_act_obj_df[act_obj_col].apply(
        lambda x: [tuple(pair.get(based_on)) for pair in x]
    )

    # Set each pair as a row. This doesnt reset index.
    frequent_act_obj_df = frequent_act_obj_df.explode(column=temp_col)

    # Count occurrence of each ao pair
    # act_obj_pair_freq = {
    #     k: v
    #     for k, v in Counter(frequent_act_obj_df[temp_col]).items()
    #     if v >= occurrence_threshold and k is not np.nan
    # }
    act_obj_pair_freq = frequent_act_obj_df[temp_col].value_counts()
    act_obj_pair_freq = act_obj_pair_freq.loc[act_obj_pair_freq >= occurrence_threshold].to_dict()

    # Create a new column for the final pair.
    act_obj_df[temp_col] = act_obj_df[act_obj_col].apply(
        _remove_pairs_based_on_rules,
        ao_pair_freq=act_obj_pair_freq,
        based_on=based_on,
        return_pairs_only=return_pairs_only,
    )

    # Drop the previous act_obj_col and rename the new column to act_obj_col
    act_obj_df = act_obj_df.drop(columns=act_obj_col)
    act_obj_df = act_obj_df.rename(columns={temp_col: act_obj_col})

    return act_obj_df, act_obj_pair_freq

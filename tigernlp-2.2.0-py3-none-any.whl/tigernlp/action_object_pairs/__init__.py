"""This module contains code for identifying grammatical dependencies of words in a sentence
and identify action object pairs from a sentence
"""

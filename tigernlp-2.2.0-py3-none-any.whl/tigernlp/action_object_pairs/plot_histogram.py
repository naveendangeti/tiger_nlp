import numpy as np
import pandas as pd
import plotly.express as px
import spacy
from collections import Counter
from nltk.corpus import stopwords
from typing import List, Tuple

from ..core.api import MyLogger, spacy_download_validate
from tigernlp.action_object_pairs.utils import get_ao_frequency


class PlotHistogram:
    """This class Generates the frequency plot for the words present in the action object pairs."""

    def __init__(
        self,
        df: pd.DataFrame,
        col_name=None,
        log_level="WARNING",
        log_file_path=None,
        verbose=True,
    ) -> None:
        """Initialize the data and the required dependencies.

        Parameters
        ----------
        df: pd.DataFrame
            dataframe containing \"subject_verb_pairs\" column.
        col_name: str, optional
            name of the column in the dataframe containing subject verb pairs.

        log_level: str, optional
            Level or severity of the events needed to be tracked, by default "WARNING"

        log_file_path: str, optional
            File path to save the logs, by default None

        verbose: bool,
            If `True` logs will be printed to console, by default True
        """
        # TODO: Add en_core_web_sm path and better logging in case of ret False

        self.data = df
        self.col_name = col_name

        ret = spacy_download_validate("en_core_web_sm")
        if ret:
            self.nlp = spacy.load("en_core_web_sm")
        else:
            raise ValueError("Could not load en_core_web_sm")

        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

        if not isinstance(df, pd.DataFrame):
            self.logger.error(
                "Input data is of incorrect type - {}. Cannot proceed further, "
                "Requires a pandas DataFrame".format(type(df))
            )
            raise ValueError("Input dataframe is incorrect")

        if col_name:

            if not isinstance(col_name, str):
                self.logger.error(
                    "Input column name is of incorrect type - {}. Cannot proceed further, "
                    "Requires a valid string".format(type(col_name))
                )
                raise ValueError("Input dataframe is incorrect")

            if col_name not in list(df.columns):
                self.logger.error(
                    "Input column name  - {} is does not exist in provided dataframe.\n".format(
                        col_name
                    ),
                    "Expected any of the {}.".format(list(df.columns)),
                )
                raise ValueError("Incorrect column name provided.")

    def _label_values(self, data, top_n) -> Tuple[np.array, np.array]:
        """Generates arrays of labels and frequency for provided list of words.

        Parameters
        ----------
        data: list
            list of words.
        top_n: int
            number of most frequent words.

        Return
        ------
        Tuple[np.array, np.array]
            arrays of words and their frequencies in descending order.
        """

        counter = Counter(data)
        labels, values = zip(*counter.items())

        indSort = np.argsort(values)[::-1]

        labels = np.array(labels)[indSort][:top_n]
        values = np.array(values)[indSort][:top_n]

        return labels, values

    def _verb_noun_collector(
        self,
    ) -> Tuple[List[str], List[str], int, int]:
        """Generates the lists of all the nouns and verbs from the subject verb pairs.

        Parameters
        ----------
        None

        Returns
        -------
        Tuple[list[str], list[str], int, int]
            tuple containing the lists of all noun, all verbs, and size of each.


        """
        if self.col_name is None:
            self.col_name = "action_object_pairs"

        all_noun = []
        all_verb = []

        for i in range(self.data.shape[0]):
            if isinstance(self.data[self.col_name][i], str):
                data = eval(self.data[self.col_name][i])
            if isinstance(self.data[self.col_name][i], list):
                data = self.data[self.col_name][i]
            for conv_dic in data:
                noun = []
                verb = []
                for j in conv_dic["pairs_pos_lemma"]:
                    if j[1] in ["NOUN", "PROPN"]:
                        noun.append(j[0])
                    if j[1] == "VERB":
                        verb.append(j[0])
                all_noun.extend(noun)
                all_verb.extend(verb)

        all_noun = [word for line in all_noun for word in line.split()]
        all_verb = [word for line in all_verb for word in line.split()]

        return all_noun, all_verb, len(all_noun), len(all_verb)

    def plot_for_stopwords(
        self,
        pos_type,
        remove_stopwords=False,
        top_n=None,
    ) -> None:
        """Plots histogram with the words on horizontal axis and their frequency on Vertical axis.

        Parameters
        ----------
        pos_type: string
            Can be either noun or verb or combined
        remove_stopwords: bool, optional (default: False)
            Optional parameter to remove stopwords.
        top_n: int, optional
            n most frequent words. If nothing is passed the plot will contain all the words present in the data.

        Returns
        -------
        None

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.
        """

        if not isinstance(pos_type, str):
            self.logger.error(
                "Input pos_type is of incorrect type - {}. Cannot proceed further, "
                "Requires a valid string".format(type(pos_type))
            )
            raise ValueError("Input POS type is incorrect.")

        if pos_type not in ["noun", "verb", "combined"]:
            self.logger.error(
                "Invalid choice for pos_type - {}. Cannot proceed further, "
                'Expected: "noun" or "verb" or "combined"'.format(pos_type)
            )
            raise ValueError("Invalid choice for pos_type")

        if top_n:
            if not isinstance(top_n, int):
                self.logger.error(
                    "Input top_n is of incorrect type - {}. Cannot proceed further, "
                    "Requires a integer".format(type(top_n))
                )
                raise ValueError("Input top_n is incorrect.")
            if top_n > self.data.shape[0]:
                self.logger.error(
                    "Input top_n is incorrect - {}. Cannot proceed further, "
                    "Enter an integer less than size of data dictionary.".format(top_n)
                )
                raise ValueError(
                    "Input top_n is incorrect. Provide a value less than size of data dictionary."
                )

        if top_n is None:
            top_n = self.data.shape[0]

        noun, verb, noun_count, verb_count = self._verb_noun_collector()
        self.logger.info(
            "Unique nouns phrases before stopwords removal and lammatization: {}".format(len(set(noun)))
        )
        self.logger.info(
            "Unique verbs before stopwords removal and lammatization: {}".format(len(set(verb)))
        )

        # if lemmatize is True:

        #     noun_lemma = []
        #     verb_lemma = []

        #     for i in range(self.data.shape[0]):
        #         noun, verb = [], []

        #         if isinstance(self.data[self.col_name][i], str):
        #             data = eval(self.data[self.col_name][i])

        #         if isinstance(self.data[self.col_name][i], list):
        #             data = self.data[self.col_name][i]

        #         for conv_dic in data:
        #             verb_word = conv_dic['pairs_lemma'][0].split()
        #             verb.extend(verb_word)
        #             noun_word = conv_dic['pairs_lemma'][1].split()
        #             noun.extend(noun_word)
        #         noun_lemma.extend(noun)
        #         verb_lemma.extend(verb)

        #     noun = noun_lemma[:]
        #     verb = verb_lemma[:]
        #     noun_count = len(noun)
        #     verb_count = len(verb)

        #     self.logger.info("size of noun list after lemmatization: {}".format(len(noun)))
        #     self.logger.info("size of verb list after lemmatization: {}".format(len(verb)))

        if remove_stopwords is True:
            sw_list = stopwords.words("english")
            noun = [n for n in noun if not n.lower() in sw_list]
            verb = [v for v in verb if not v.lower() in sw_list]

            self.logger.info("size of noun list after removing stopwords: {}".format(len(noun)))
            self.logger.info("size of verb list after removing stopwords: {}".format(len(verb)))

        combined_verb_noun = noun[:]
        combined_verb_noun.extend(verb)

        self.logger.info("Original size of noun list: {}".format(noun_count))
        self.logger.info("Original size of verb list: {}".format(verb_count))
        self.logger.info("size of combined verbs and nouns: {}".format(len(combined_verb_noun)))

        self.logger.info("Unique nouns after cleaning: {}".format(len(set(noun))))
        self.logger.info("Unique verbs after cleaning: {}".format(len(set(verb))))
        self.logger.info("Size of unique words: {}".format(len(set(combined_verb_noun))))

        if pos_type == "noun":
            labels, values = self._label_values(noun, top_n)
            fig = px.bar(
                x=labels,
                y=values,
                labels={"x": "Noun Words", "y": "Frequency"},
                width=1000,
                height=600,
                title="Histogram for noun words",
            )
            fig.show()
        if pos_type == "verb":
            labels, values = self._label_values(verb, top_n)
            fig = px.bar(
                x=labels,
                y=values,
                labels={"x": "Verb Words", "y": "Frequency"},
                width=1000,
                height=600,
                title="Histogram for verb words",
            )
            fig.show()
        if pos_type == "combined":
            labels, values = self._label_values(combined_verb_noun, top_n)
            fig = px.bar(
                x=labels,
                y=values,
                labels={"x": " all Words", "y": "Frequency"},
                width=1000,
                height=600,
                title="Histogram for all words",
            )
            fig.show()

    def plot_AO_pairs(
        self,
        column: str,
        lemma: bool = True,
        top_n=None
    ) -> None:
        """Plots histogram for the action and object pairs.

        Parameters
        ----------
        column: str
            Name of the column having action object pairs in the dataframe.
        lemma: bool, optional (True)
            Whether to lemmatize the words or not. By default, True.
        top_n: int, optional
            n most frequent processed action object pairs. If nothing is passed the plot will contain all the action objects pairs present in the data.

        Returns
        -------
        None

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.
        """

        if not isinstance(column, str):
            self.logger.error(
                "Column name is of incorrect type- {}. Cannot proceed further, "
                "Requires a valid string".format(column)
            )
            raise ValueError("Input column name is of incorrect type.")

        if column not in list(self.data.columns):
            self.logger.error(
                "Column name provided is not present in dataframe - {}. Cannot proceed further, "
                "Provide correct column name".format(column)
            )
            raise ValueError("Column name provided is not present in dataframe.")

        if not isinstance(lemma, bool):
            self.logger.error(
                "Parameter lemma is of incorrect type- {}. Cannot proceed further, "
                "Requires a boolean parameter".format(lemma)
            )
            raise ValueError("Input column name is of incorrect type.")

        data = get_ao_frequency(data=self.data, column=column, lemma=lemma)

        pairs = list(data[column])
        freq = list(data["frequency"])

        if top_n:
            if not isinstance(top_n, int):
                self.logger.error(
                    "Input top_n is of incorrect type - {}. Cannot proceed further, "
                    "Requires a integer".format(type(top_n))
                )
                raise ValueError("Input top_n is of incorrect type.")
            if top_n > len(data):
                self.logger.error(
                    "Input top_n is incorrect - {}. Cannot proceed further, "
                    "Enter an integer less than size of data dictionary.".format(top_n)
                )
                raise ValueError(
                    "Input top_n is incorrect. Provide a value less than size of data dictionary."
                )

        if not top_n:
            top_n = len(data)

        pairs = pairs[:top_n]
        freq = freq[:top_n]

        for i in range(len(pairs)):
            pairs[i] = ", ".join(word for word in pairs[i])

        fig = px.bar(
            x=pairs,
            y=freq,
            labels={"x": "Action-object pairs", "y": "Frequency"},
            width=1000,
            height=600,
            title="Histogram for processed action-objects pairs",
        )
        fig.show()

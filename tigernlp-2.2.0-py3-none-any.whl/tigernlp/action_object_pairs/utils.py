import pandas as pd
import re
from typing import Tuple


def get_ao_frequency(data: pd.DataFrame, column: str, lemma: bool = True) -> pd.DataFrame:
    """
    Returns all action object pairs and their frequencies as a dataframe sorted in decreasing order.

    Parameters
    ----------
    data : pd.DataFrame
        Dataframe containing action object pairs
    column : str
        Column name of action object pairs for which frequency is required
    lemma : bool, optional
        Action object pairs column is a list of dictionaries where each dictionary has a key called 'pairs' and 'pairs_lemma'.
        If this parameter is set to False, 'pairs' will be used, otherwise 'pairs_lemma' will used, by default True

    Returns
    -------
    pd.DataFrame
        Dataframe containing 2 columns. Unique action object pairs will be in column parameter and their frequencies in 'frequency'.

    Examples
    --------
    >>> # Here "data" is the result of AOPGenerate class
    >>> freq_data = get_ao_frequency(data = data, column = "action_object_pairs", lemma = True)
    """
    lemma_key = "pairs_lemma" if lemma else "pairs"
    freq_data = (
        data[column]
        .apply(lambda x: [tuple(pair.get(lemma_key)) for pair in x])
        .explode()
        .to_frame()
        .groupby(column)
        .size()
        .to_frame(name="frequency")
        .sort_values(by="frequency", ascending=False)
    )
    freq_data.reset_index(inplace=True)
    return freq_data[[column, "frequency"]]


def get_count_word(
    word: str,
    data: pd.DataFrame = None,
    column: str = "action_object_pairs",
    lemma: bool = True,
    freq_data: pd.DataFrame = None,
) -> Tuple[int, pd.DataFrame]:
    """
    Given a word, return number of action object pairs in which this word is being used.
    Also return a dataframe containing action object pairs containing said word, along with frequency of action object pair.

    Parameters
    ----------
    word : str
        Word to get count for
    data : pd.DataFrame, optional
        Dataframe containing action object pairs. Can be None if "freq_data" is passed, by default None
    column : str, optional
        Column name of action object pairs to take from "data" parameter, by default "action_object_pairs"
    lemma : bool, optional
        Action object pairs column is a list of dictionaries where each dictionary has a key called 'pairs' and 'pairs_lemma'.
        If this parameter is set to False, 'pairs' will be used, otherwise 'pairs_lemma' will used
        Can be None if "freq_data" is passed, by default True
    freq_data : pd.DataFrame, optional
        Result of "get_ao_frequency" function can be passed here directly without recomputing it internally again, by default None

    Returns
    -------
    Tuple[int, pd.DataFrame]
        Number of action object pairs in which a given word is being used,
        dataframe containing action object pairs containing said word along with frequency of action object pair.

    Examples
    --------
    >>> # Option1
    >>> # Here "data" is the result of AOPGenerate class
    >>> word_count, word_count_df = get_count_word(
            word="have", data=data, column="action_object_pairs", lemma=True
        )

    >>> # Option2
    >>> # Here "data" is the result of AOPGenerate class
    >>> freq_data = get_ao_frequency(data = data, column = "action_object_pairs", lemma = True)
    >>> word_count, word_count_df = get_count_word(word = "have", freq_data = freq_data)
    """
    if freq_data is None:
        freq_data = get_ao_frequency(data, column, lemma)

    word = word.lower()
    word_freq = freq_data.loc[
        freq_data[column].apply(
            lambda x: bool(
                re.compile(r"\b({0})\b".format(word), flags=re.IGNORECASE).search(str(x).lower())
            )
        )
    ]
    word_freq.reset_index(drop=True, inplace=True)

    return word_freq.frequency.sum(), word_freq

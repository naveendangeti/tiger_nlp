import pandas as pd
from typing import Union

from tigernlp.core.utils import MyLogger
from tigernlp.text_matching.fuzzy_wuzzy_matching import FuzzyWuzzyMatching
from tigernlp.text_matching.semantic_matching import SemanticTextMatching
from tigernlp.text_matching.utils import EuclideanDistance, JaccardSimilarity
from tigernlp.text_matching.zero_shot_classification import ZeroShotClassification

"""Multi-inheritance will become difficult in the future when I have multiple types of algoriths.
Resolving method inheritance from multiple classes will be difficult"""


class Ensemble:

    """Ensemble text matching algorithm to find similarity between the text documents using fuzzy wuzzy matching, semantic sentence/word matching and zero shot classification

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True
    Examples
    --------
    >>> from tigernlp.text_matching.api import Ensemble
    >>> sequence = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> labels = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> model_object = Ensemble()
    >>> df_theme = (
    >>>     model_object
    >>>     .ensemble_similarity(text_doc1=sequence, text_doc2=labels)
    >>> )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """Ensemble class initialization"""

        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose

        self.logger = MyLogger(level=self.log_level, log_file_path=self.log_file_path, verbose=self.verbose).logger

    def ensemble_similarity(
        self,
        text_doc1: Union[str, list, pd.DataFrame] = list(),
        text_doc2: Union[str, list] = None,
        column_dict={"col_doc1": None, "col_doc2": None},
        exclude_algorithms={"fuzzywuzzy": 0, "semantic": 0, "zeroshot_classification": 0, "euclidean": 0, "jaccard": 0},
        model_parameters={
            "fuzzywuzzy": {"scorer_type": "partial_ratio"},
            "semantic": {"embeddings": "sentence_transformers", "embedding_model": "all-MiniLM-L6-v2"},
            "zeroshot_classification": {"embedding_model": "facebook/bart-large-mnli", "multi_label": True},
            "euclidean": {"vectorizer_type": "tfidf"},
        },
        cross_match=True,
        parallel_process=False,
        n_jobs=-1,
    ):
        """Generates final model output using an ensemble approach

        Parameters
        ----------
        text_doc1 : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to match with text_doc2, by default list()
        text_doc2 : Union[str, list], optional
            string or list of text documents to match with text_doc1, by default None
        column_dict : dict, optional
            col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
        exclude_algorithms : dict, optional
            option to exclude a particular text matching algorithm from the ensemble approach, 1 to exclude, else 0, by default {"fuzzywuzzy": 0, "semantic": 0, "zeroshot_classification": 0}
        model_parameters : dict, optional
            model parameters required across different algorithms, by default { "fuzzywuzzy": {"scorer_type": "partial_ratio"}, "semantic": {"embeddings":"sentence_transformers", "embedding_model": "all-MiniLM-L6-v2"}, "zeroshot_classification": {"embedding_model": "facebook/bart-large-mnli", "multi_label": True}}

            Refer to the API documentation of the other algorithms for additional details on model parameters
        cross_match : bool, optional
            if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

            if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
        parallel_process: False, optional (bool)
            Whether to use parallel processing, by default False.
        n_jobs : int, optional
            number of concurrent workers, by default -1 i.e., use all available workers
        Returns
        -------
        pd.DataFrame
            dataframe with sentence matching scores across multiple algorithms between sequence and label columns. Output dataframe shape will be equal to len(sequence) x len(labels)

        Raises
        ------
        Exception
            raise error if values for all exclude_algorithm keys is 1.
            You have excluded all text matching algorithms. Include one or more to run the ensemble text matching
        """

        """
        Example : sequence = ["dolphin safe", "grain free"], labels = ["Grain Free", "Made in the USA"]
        Output dataframe:

            sequence	 | labels	        |scores_fuzzywuzzy |scores_semantic_sentence |scores_semantic_word |scores_zeroshot_classification|predicted
            -------------|------------------|------------------|-------------------------|---------------------|------------------------------|------------
            dolphin safe | Grain Free	    |    56.0	       |        0.066746	     |          0.0	       |           0.047984	          |     0
            dolphin safe | Made in the USA	|    45.0	       |        0.076612	     |          0.0	       |           0.173909	          |     0
            grain free	 | Grain Free	    |    100.0	       |        1.000000	     |          1.0	       |           0.963931	          |     1
            grain free	 | Made in the USA	|    40.0	       |        0.148995	     |          0.0	       |           0.046205	          |     0

        """

        try:
            self.logger.info("Text matching using ensemble method started")
            self.sequence = text_doc1
            self.label = text_doc2
            self.exclude_algorithms = exclude_algorithms
            self.model_parameters = model_parameters
            return_df = True

            algo_to_model = {k: v for k, v in self.exclude_algorithms.items() if v == 0}.keys()

            df = pd.DataFrame()

            for algo in algo_to_model:
                if algo == "fuzzywuzzy":
                    model_object = FuzzyWuzzyMatching(log_file_path=self.log_file_path, verbose=self.verbose, log_level=self.log_level)
                    scorer = model_parameters["fuzzywuzzy"]["scorer_type"]
                    temp = model_object.fuzzywuzzy_similarity(
                        text_doc1=self.sequence,
                        text_doc2=self.label,
                        column_dict=column_dict,
                        scorer_type=scorer,
                        cross_match=cross_match,
                        return_df=return_df,
                    )
                elif algo == "semantic":
                    model_object = SemanticTextMatching(log_file_path=self.log_file_path, verbose=self.verbose, log_level=self.log_level)
                    embeddings = model_parameters["semantic"]["embeddings"]
                    embedding_model = model_parameters["semantic"]["embedding_model"]

                    temp = model_object.cosine_similarity(
                        text_doc1=self.sequence,
                        text_doc2=self.label,
                        column_dict=column_dict,
                        embeddings=embeddings,
                        embedding_model=embedding_model,
                        cross_match=cross_match,
                        return_df=return_df,
                    )

                elif algo == "zeroshot_classification":
                    model_object = ZeroShotClassification(log_file_path=self.log_file_path, verbose=self.verbose, log_level=self.log_level)
                    embedding_model = model_parameters["zeroshot_classification"]["embedding_model"]
                    multi_label = model_parameters["zeroshot_classification"]["multi_label"]

                    temp = model_object.get_model_output(
                        text_doc1=self.sequence,
                        text_doc2=self.label,
                        column_dict=column_dict,
                        multi_label=multi_label,
                        embedding_model=embedding_model,
                        cross_match=cross_match,
                        return_df=return_df,
                        parallel_process=parallel_process,
                        n_jobs=n_jobs,
                    )
                elif algo == "euclidean":

                    vectorizer_type = model_parameters["euclidean"]["vectorizer_type"]

                    temp = EuclideanDistance(
                        text_doc1=self.sequence,
                        text_doc2=self.label,
                        column_dict=column_dict,
                        vectorizer_type=vectorizer_type,
                        cross_match=cross_match,
                        return_df=return_df,
                        log_file_path=self.log_file_path,
                        verbose=self.verbose,
                        log_level=self.log_level,
                    )
                elif algo == "jaccard":

                    temp = JaccardSimilarity(
                        text_doc1=self.sequence,
                        text_doc2=self.label,
                        column_dict=column_dict,
                        cross_match=cross_match,
                        return_df=return_df,
                        log_file_path=self.log_file_path,
                        verbose=self.verbose,
                        log_level=self.log_level,
                    )
                else:
                    raise Exception("You have excluded all text matching algorithms. Include one or more to run the ensemble text matching")

                cols_to_rename = ["scores"]
                cols_with_rename = [c + "_" + algo for c in cols_to_rename]

                dict_cols = dict(zip(cols_to_rename, cols_with_rename))
                temp.rename(columns=dict_cols, inplace=True)
                if df.shape[0] > 0:
                    df = pd.merge(df, temp, how="outer")
                else:
                    df = pd.concat([df, temp])

            df.reset_index(inplace=True, drop=True)
            df.reset_index(inplace=True, drop=True)
            self.logger.info("Text matching using ensemble method completed")
            return df

        except Exception as e:
            self.logger.error(f"Error occurred during ensemble text matching {e}")

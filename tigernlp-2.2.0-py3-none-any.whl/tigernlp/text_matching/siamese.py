import numpy as np
import os
import pandas as pd
from typing import Tuple, Union

from tigernlp.core.api import MyLogger
from tigernlp.text_matching.semantic_matching import SemanticTextMatching


def find_top_n_closest(
    X: Union[pd.DataFrame, np.ndarray],
    y: Union[pd.Series, np.ndarray, list],
    out_of_scope_threshold: float,
    embedding_model: str = "all-mpnet-base-v2",
    rank_logic: Tuple = ("max", "freq", "mean"),
    text_col: str = None,
    id_col: str = None,
    N: int = 5,
    logging_level: str = "WARNING",
    log_file_path=None,
    verbose=True,
) -> pd.DataFrame:
    """For the given ``X``, find top ``N`` closest matching items in ``y`` based on cosine similarity and frequency.

    Parameters
    ----------
    X : Union[pd.DataFrame, np.ndarray]
        Input. It can be either a dataframe with id column or just a numpy array with text alone.

    y : Union[pd.Series, np.ndarray, list]
        Input we match to ``X``. It has to be 1D.

    out_of_scope_threshold : float
        Minimum cosine similarity score to consider two texts as "close" match.

    embedding_model : str
        Huggingface supported Sentence transformers that will be used for embeddings. Supported models are "all-mpnet-base-v2", "all-distilroberta-v1" and "all-MiniLM-L12-v2". Path to models can also be used if model is saved locally, by default "all-mpnet-base-v2".

    rank_logic : Tuple
        Rank logic for sorting the labels using cosine similarity scores and label frequency in descending order. It has to be tuple of three elements and should contain "max", "freq" and "mean" in any order without repetition. by default, it's ("max", "freq", "mean").

    text_col : str, optional
        Column name in ``X`` that contains the text if it is passed as dataframe, by default None but internally it will be defaulted to "text".

    id_col : str, optional
        Column name in ``X`` that contains either call or conversation id, by default None

    N : int, optional
        Top N matches from y., by default 5

    logging_level : str, optional
        Enter the level of logging. by default, its "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Returns
    -------
    pd.DataFrame
        Depending on whether ``X`` is dataframe or array, output will contain top n closest matches in ``y`` either at ``id_col`` level or ``text_col`` respectively.

    Raises
    ------
    ValueError
        if any of the argument is missing or invalid.
    """
    # Logger
    logger = MyLogger(level=logging_level, log_file_path=log_file_path, verbose=verbose).logger
    # Error handling
    if not isinstance(X, pd.DataFrame) and not isinstance(X, np.ndarray):
        raise ValueError("Input must be either a dataframe or numpy array.")
    elif isinstance(X, pd.DataFrame):
        if text_col is not None and text_col not in X.columns:
            raise ValueError(f"{text_col} is not a valid column in X.")
        elif id_col is not None and id_col not in X.columns:
            raise ValueError(f"{id_col} is not a valid column in X.")
        elif text_col is None:
            raise ValueError(
                "id_col and text_col must be passed if X is passed as pandas dataframe."
            )
    elif (
        not isinstance(y, pd.Series) and not isinstance(y, np.ndarray) and not isinstance(y, list)
    ):
        raise ValueError("y must be either a pandas series object or 1d numpy array or 1d list.")
    elif (isinstance(y, np.ndarray) and y.ndim != 1) or (
        isinstance(y, list) and isinstance(y[0], list)
    ):
        raise ValueError("y must be 1d.")
    elif out_of_scope_threshold is None:
        raise ValueError("out of scope threshold must be valued between -1 and 1.")
    elif not isinstance(N, int):
        raise ValueError("N must be an integer.")
    elif len(set(rank_logic)) != 3 and set(rank_logic) != set(("max", "freq", "mean")):
        raise ValueError("rank_logic contains invalid values.")
    elif embedding_model not in [
        "all-mpnet-base-v2",
        "all-distilroberta-v1",
        "all-MiniLM-L12-v2",
    ] and not os.path.exists(embedding_model):
        raise ValueError(
            "embedding_model is incorrect or not supported or not a valid path. Supported models are 'all-mpnet-base-v2', 'all-distilroberta-v1', 'all-MiniLM-L12-v2'"
        )

    # IF X is dataframe, X should be only passed as dataframe if it has ID column which needs to be aggregated
    if isinstance(X, pd.DataFrame):
        logger.debug("X is passed as a dataframe.")
    else:
        logger.debug(
            "There is no ID column, hence each utterance/row is considered to be independent."
        )
        if text_col is None:
            text_col = "text"

        X = pd.DataFrame(X, columns=[text_col])

    # Call Sentence Match to get the scores
    logger.debug("initialized Semantic Text Matching")
    stm = SemanticTextMatching(
        log_level=logging_level, log_file_path=log_file_path, verbose=verbose
    )

    # convert y to list
    if isinstance(y, pd.Series):
        y = y.to_list()
    elif isinstance(y, np.ndarray):
        y = y.tolist()

    logger.debug("Cosine similarity calculation of X and y started.")
    scores_df = stm.cosine_similarity(
        text_doc1=X,
        text_doc2=y,
        column_dict={"col_doc1": text_col, "col_doc2": None},
        embeddings="sentence_transformers",
        embedding_model=embedding_model,
        cross_match=True,
        return_df=False,
    )

    logger.debug("Cosine similarity calculation of X and y completed.")

    scores_df = scores_df.rename(columns={"text_doc2": "labels"})

    logger.debug("Dropping rows which doesn't meet the threshold criteria.")
    out_of_scope_idx = scores_df.loc[scores_df["scores"] < out_of_scope_threshold].index
    scores_df = scores_df.drop(index=out_of_scope_idx)

    if id_col is not None:
        logger.debug("Grouping similarity scores of Conversation data started.")
        scores_df = (
            scores_df.groupby([id_col, "labels"])
            .agg(
                min_sim_score=pd.NamedAgg(column="scores", aggfunc="min"),
                max_sim_score=pd.NamedAgg(column="scores", aggfunc="max"),
                mean_sim_score=pd.NamedAgg(column="scores", aggfunc="mean"),
                label_frequency=pd.NamedAgg(column="labels", aggfunc="count"),
            )
            .reset_index()
        )
        # Decode rank logic as per column names
        rank_logic_translate = {
            "max": "max_sim_score",
            "mean": "mean_sim_score",
            "freq": "label_frequency",
        }
        rank = tuple([rank_logic_translate[c] for c in rank_logic])
        # Unpack tuple below. Order is maintained.
        scores_df = scores_df.sort_values(
            by=[id_col, *rank],
            ascending=[True, False, False, False],
        )
        logger.debug("Grouping similarity scores of Conversation data completed.")
        logger.debug(f"Taking top {N} labels.")
        scores_df = scores_df.groupby([id_col]).head(N)
    else:
        scores_df = scores_df.sort_values(by=[text_col, "scores"], ascending=[True, False])
        logger.debug(f"Taking top {N} labels.")
        scores_df = scores_df.groupby([text_col]).head(N)

    return scores_df.reset_index(drop=True)

import numpy as np
import pandas as pd
import warnings
from fuzzywuzzy import fuzz, process
from typing import Union

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")


class FuzzyWuzzyMatching:

    """Fuzzy-wuzzy text matching algorithm to find similarity between the text documents by computing fuzz ratio.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True
    Examples
    --------
    >>> from tigernlp.text_matching.api import FuzzyWuzzyMatching
    >>> sequence = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> labels = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> model_object = FuzzyWuzzyMatching()
    >>> df_theme = (
    >>>     model_object
    >>>     .fuzzywuzzy_similarity(text_doc1=sequence, text_doc2=labels, scorer_type="ratio")
    >>> )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """FuzzyWuzzyMatching class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _direct_match(self, sequence, label):
        """Computes the direct similarity between the text documents.

        Example : "apple" and "apple" or "Apple" is a direct match whereas "apple" and "aplle" is not a direct match

        Returns
        -------
        list
            list of sentences and labels with a direct match flag in the list
            1 if the label is a direct match with the sentence, 0 otherwise
        """

        out = []
        if not self.cross_match:
            for x, y in zip(sequence, label):
                str1 = x.lower()
                str2 = y.lower()
                val = [1 if str1 == str2 else 0][0]
                out.append([x, y, val])
        else:
            for x, y in [(x, y) for x in sequence for y in label]:
                str1 = x.lower()
                str2 = y.lower()
                val = [1 if str1 == str2 else 0][0]
                out.append([x, y, val])

        return out

    def _fuzzywuzzy_match(self, sequence, label):
        """Computes fuzz ratio between the text documents based on the selected scorer type

        Returns
        -------
        list
            list of sentences and labels with fuzz ratio in the list
        """

        scorer = eval("fuzz." + self.scorer_type)

        out = []
        if not self.cross_match:
            for x, y in zip(sequence, label):
                val = process.extract(x, [y], scorer=scorer, limit=len([y]))[0][1]
                out.append([x, y, val])
        else:
            # for x in sequence:
            #     val = process.extract(x, label, scorer=scorer, limit=len(label))
            #     temp = list(zip(*val))
            #     temp = list(zip([x] * len(temp[0]), temp[0], temp[1]))
            #     out = out + temp

            out = []
            for x, y in [(x, y) for x in sequence for y in label]:
                val = process.extract(x, [y], scorer=scorer, limit=len([y]))[0][1]
                out.append([x, y, val])

        return out

    def _get_score(self, sequence, label):
        """Function to get direct match or fuzzy wuzzy score"""
        if self.scorer_type == "direct":
            score = self._direct_match(sequence, label)

        elif self.scorer_type in [
            "ratio",
            "partial_ratio",
            "token_set_ratio",
            "token_sort_ratio",
            "partial_token_set_ratio",
            "partial_token_sort_ratio",
        ]:
            score = self._fuzzywuzzy_match(sequence, label)

        else:
            raise Exception(
                """
            Invalid embedding type parameter.
            Please pass scorer type as
            direct/ratio/partial_ratio/token_set_ratio/token_sort_ratio/partial_token_set_ratio/partial_token_sort_ratio"""
            )
        return score

    def fuzzywuzzy_similarity(
        self,
        text_doc1: Union[str, list, pd.DataFrame] = list(),
        text_doc2: Union[str, list] = None,
        column_dict={"col_doc1": None, "col_doc2": None},
        scorer_type="partial_ratio",
        cross_match=True,
        return_df=True,
    ):
        """Generates final model output using fuzzy-wuzzy ratio and direct match

        Parameters
        ----------
        text_doc1 : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to match with text_doc2, by default list()
        text_doc2 : Union[str, list], optional
            string or list of text documents to match with text_doc1, by default None
        column_dict : dict, optional
            col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
        scorer_type : str, optional
            type of fuzzywuzzy matching scorer, by default "partial_ratio"

            Options - direct/ratio/partial_ratio/token_set_ratio/token_sort_ratio/partial_token_set_ratio/partial_token_sort_ratio
        score_threshold : int, optional
            minimum score threshold value required to match two text documents, by default 80

            Example: if score_threshold=80, then all the text documents with a matching score value>=80 will be marked as matching documents i.e. 1, else 0
        cross_match : bool, optional
            if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

            if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
        return_df : bool, optional
            if True, return output of text matching as dataframe else return list of lists of scores

        Returns
        -------
        pd.DataFrame or list of lists
            if return_df is True, dataframe with fuzz ratio/direct match flag as column "scores" between text_doc1 and text_doc2. Output dataframe shape will be equal to len(text_doc1) x len(text_doc2)

            if return_df is False, list of lists with fuzz ratio/direct match score between text_doc1 and text_doc2 where list[0][1] is the score between text_doc1[0] and text_doc2[1]
            Example - [[0, 1.3651, 1.3632], [1.3651, 0, 1.3862]]

        Raises
        ------
        Exception
            raise error if match type is not provided as
            "direct/ratio/partial_ratio/token_set_ratio/token_sort_ratio/partial_token_set_ratio/partial_token_sort_ratio"
        """

        """
        Example : sequence = ["dolphin safe", "grain free"], labels = ["Grain Free", "Made in the USA"]
        Output dataframe:

            sequence	    |   labels	           | scores	  | predicted
            ----------------|----------------------|----------|-----------
            dolphin safe	|   Made in the USA	   |    45    |	    0
            dolphin safe	|   Grain Free	       |    56    |	    0
            grain free	    |   Grain Free	       |    100   |	    1
            grain free	    |   Made in the USA	   |    40    |	    0
        """
        try:
            self.logger.info(f"Text matching using {scorer_type} fuzzywuzzy started")
            self.scorer_type = scorer_type
            self.cross_match = cross_match

            if not isinstance(text_doc1, pd.DataFrame) and not isinstance(text_doc1, str) and not isinstance(text_doc1, list):
                self.logger.error("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")
                raise ValueError("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")

            if isinstance(text_doc1, pd.DataFrame):

                if "scores" in text_doc1.columns:
                    del text_doc1["scores"]

                if not column_dict["col_doc1"]:
                    self.logger.error(
                        "Input column name is not provided, " "set parameter column_dict['col_doc1'] for the input column name."
                    )
                    raise ValueError("Set input column name to parameter: column_dict['col_doc1']")

                if column_dict["col_doc1"] not in text_doc1.columns:
                    self.logger.error("Input column name column_dict['col_doc1'] is either incorrect or not present in the dataframe.")
                    raise ValueError("Provide correct input column name column_dict['col_doc1'].")

                col_doc1 = column_dict["col_doc1"]

                if isinstance(text_doc2, str):
                    self.cross_match = False
                    text_doc1["text_doc2"] = text_doc2
                    score = self._get_score(text_doc1[col_doc1], text_doc1["text_doc2"])
                    score = [el[2] for el in score]
                    text_doc1["scores"] = score

                elif isinstance(text_doc2, list):

                    if len(text_doc2) == 0:
                        self.logger.error("Empty list can not be used for matching documents")
                        raise ValueError("Provide list with text documents")

                    if not cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in number of rows of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Number of rows of text_doc1 and lenght of text_doc2 is different")

                        else:
                            text_doc1["text_doc2"] = text_doc2
                            score = self._get_score(text_doc1[col_doc1], text_doc1["text_doc2"])
                            score = [el[2] for el in score]
                            text_doc1["scores"] = score

                    else:

                        score = self._get_score(text_doc2, text_doc1[col_doc1])
                        score = [el[2] for el in score]
                        count = 0
                        out = pd.DataFrame()
                        for text in text_doc2:
                            temp = text_doc1.copy()
                            temp["text_doc2"] = text
                            temp["scores"] = score[(len(temp) * count) : (len(temp) * (count + 1))]
                            out = pd.concat([out, temp], ignore_index=True)
                            count += 1

                        text_doc1 = out.copy()

                else:
                    if not column_dict["col_doc2"]:
                        self.logger.error(
                            "Input column name is not provided, " "set parameter column_dict['col_doc2'] for the input column name."
                        )
                        raise ValueError("Set input column name to parameter: column_dict['col_doc2']")

                    if column_dict["col_doc2"] not in text_doc1.columns:
                        self.logger.error("Input column name column_dict['col_doc2'] is either incorrect or not present in the dataframe.")
                        raise ValueError("Provide correct input column name column_dict['col_doc2'].")

                    if cross_match:
                        self.logger.error(
                            "Cross matching is not possible within dataframe. Provide text documents as a list for cross match option."
                        )
                        raise ValueError("Provide text documents as a list for cross match option.")

                    else:
                        col_doc2 = column_dict["col_doc2"]
                        score = self._get_score(text_doc1[col_doc1], text_doc1[col_doc2])
                        score = [el[2] for el in score]
                        text_doc1["scores"] = score

                self.logger.info(f"Text matching using {scorer_type} fuzzywuzzy completed")
                return text_doc1

            else:

                if not isinstance(text_doc2, str) and not isinstance(text_doc2, list):
                    self.logger.error("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")
                    raise ValueError("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")

                if (len(text_doc1) != len(np.unique(text_doc1)) and isinstance(text_doc1, list)) or (
                    len(text_doc2) != len(np.unique(text_doc2)) and isinstance(text_doc2, list)
                ):
                    self.logger.error(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )
                    raise ValueError(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )

                if len(text_doc1) == 0 or len(text_doc2) == 0:
                    self.logger.error("Empty list/string can not be used for matching documents")
                    raise ValueError("Provide list/string with text documents")

                if isinstance(text_doc1, str) and isinstance(text_doc2, str):
                    text_doc1 = [text_doc1]
                    text_doc2 = [text_doc2]

                elif isinstance(text_doc1, str) and isinstance(text_doc2, list):
                    self.cross_match = True
                    text_doc1 = [text_doc1]

                elif isinstance(text_doc1, list) and isinstance(text_doc2, str):
                    self.cross_match = True
                    text_doc2 = [text_doc2]

                elif isinstance(text_doc1, list) and isinstance(text_doc2, list):
                    if not self.cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in length of text_doc1 {len(text_doc1)} against length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Length of text_doc1 and text_doc2 is different")

                score = self._get_score(text_doc1, text_doc2)

                df = pd.DataFrame(score)
                df.columns = ["text_doc1", "text_doc2", "scores"]
                df.reset_index(inplace=True, drop=True)
                df["scores"] = df["scores"].astype(float)
                df["scores"] = np.round(df["scores"], 5)

                if return_df:
                    df.reset_index(inplace=True, drop=True)
                    df.reset_index(inplace=True, drop=True)
                    df.rename(columns={"sequence": "text_doc1", "labels": "text_doc2"}, inplace=True)

                    self.logger.info(f"Text matching using {scorer_type} fuzzywuzzy completed")
                    return df
                else:
                    original_cols_order = df.text_doc2.unique().tolist()
                    original_index_original = df.text_doc1.unique()
                    check = pd.pivot(df, index="text_doc1", columns="text_doc2", values="scores")[original_cols_order]
                    score = np.array(check.reindex(original_index_original))
                    if not self.cross_match:
                        score = np.diag(score)
                    self.logger.info(f"Text matching using {scorer_type} fuzzywuzzy completed")
                    return score

        except Exception as e:
            self.logger.error(f"Error occurred during fuzzywuzzy text matching {e}")

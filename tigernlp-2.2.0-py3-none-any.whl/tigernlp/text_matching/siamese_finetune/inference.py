import numpy as np
import pandas as pd
import warnings

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")


class SiameseInference:
    """This class generates dataframe for evaluation process.

    Parameters
    -----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True


    Example
    ---------
    >>> from tigernlp.text_matching.api import SiameseInference
    >>> df = pd.read_csv ('data/validation_massive2.csv.csv')
    >>> inference = Inference()
    >>> result = inference.build_result(
    >>>        df=valid,
    >>>        top_scores_df=top_intents,
    >>>        column_to_group="text"
    >>>    )
    """

    def __init__(self, log_level="WARNING", log_file_path=None, verbose=True):
        """
        Siamese model inference class initialization
        """
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def build_result(self, df: pd.DataFrame, top_scores_df: pd.DataFrame, column_to_group: str) -> pd.DataFrame:
        """For the given dataframe, build result dataframe that contains atleast text, y_pred and result.
        result is list of [y_pred, cosine scores].

        Parameters
        ----------
        df : pd.DataFrame
            Original dataframe which was fed as input to `find_top_n_closest` from text matching module.

        top_scores_df : pd.DataFrame
            output of `find_top_n_closest` from text matching module.

        column_to_group : str
            Column name to group. It is either call id for conversation data or text for individual utterances.

        """
        if not isinstance(df, pd.DataFrame):
            self.logger.error(
                "Incorrect type for 'df', provided: {}, expected: 'DataFrame'.".format(
                    type(df)
                )
            )
            raise ValueError("Incorrect type for 'df', provide a valid DataFrame.")

        if not isinstance(top_scores_df, pd.DataFrame):
            self.logger.error(
                "Incorrect type for 'top_scores_df', provided: {}, expected: 'DataFrame'.".format(
                    type(top_scores_df)
                )
            )
            raise ValueError("Incorrect type for 'top_scores_df', provide a valid DataFrame.")

        if not isinstance(column_to_group, str):
            self.logger.error(
                "Incorrect type for 'column_to_group', provided: {}, expected: 'str'.".format(
                    type(column_to_group)
                )
            )
            raise ValueError("Incorrect type for 'column_to_group', provide a valid str.")

        if column_to_group not in top_scores_df.columns:
            self.logger.error(
                "column_to_group column not found in top_scores_df"
            )
            raise ValueError("column_to_group column not found in top_scores_df")

        if column_to_group not in df.columns:
            self.logger.error(
                "column_to_group column not found in df"
            )
            raise ValueError("column_to_group column not found in df")

        # grouping labels and scores and having list of [label,score] in single column
        grouped_intents_op = top_scores_df.groupby(column_to_group)[["labels", "scores"]].apply(lambda x: x.values.tolist()).reset_index(name="result")

        # grouping only labels in top_scores_df by column_to_group
        grouped_intents = top_scores_df.groupby(column_to_group)["labels"].apply(list).reset_index(name="y_pred")

        # merging grouped_intents and grouped_intents_op
        final_grouped_intent = pd.merge(left=grouped_intents, right=grouped_intents_op, how="inner", on=column_to_group)

        # merging final_grouped_intent with original dataframe
        complete_intents = pd.merge(
            left=df[[column_to_group]],
            right=final_grouped_intent,
            how="left",
            on=column_to_group
        )

        # checking the null values
        missing_intents_null = complete_intents.query("y_pred.isnull()", engine="python")[[column_to_group, "y_pred", "result"]]

        # converting null values to empty list
        missing_intents_null["y_pred"] = np.empty((missing_intents_null.shape[0], 0)).tolist()

        # checking the values which are not null
        have_intents = complete_intents.query("not y_pred.isnull()", engine="python")[[column_to_group, "y_pred", "result"]]

        # concating missing_intents_null and have_intents
        final_intent_pred = pd.concat([missing_intents_null, have_intents], axis=0, ignore_index=True).sort_values(by=column_to_group).reset_index(drop=True)

        return final_intent_pred

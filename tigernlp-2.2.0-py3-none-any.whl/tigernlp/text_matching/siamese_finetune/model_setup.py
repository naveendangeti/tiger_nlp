import torch
from sentence_transformers import SentenceTransformer, losses, models
from sentence_transformers.evaluation import BinaryClassificationEvaluator

from tigernlp.core.utils import MyLogger

# TODO: add evaluation to model training.
# TODO: Move semantic grouping notebooks as scripts to NLP Library - Text matching and clustering.


class SiameseModelSetup:
    """Wrapper class for setting up model config and training setup. Training is for sentence embeddings alone, not intent classification.
    For intent classification, refer documentation of siamese pre-trained.

    Parameters
    ----------
    model_name : str
            Name of the SBERT model as given in Hugging face hub. For example, "sentence-transformers/all-mpnet-base-v2". Only sentence-transformers/all-MiniLM-L12-v2 and sentence-transformers/all-mpnet-base-v2 are supported.

    batchsize : int
        Batch size for training

    epochs : int
        Number of epochs to train

    warmup_percent : float
        percentage between 0 and 1 for learning rate scheduler.

    logging_level: str
        Level or severity of the events they are used to track. Acceptable values are ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], by default "WARNING"
    """

    def __init__(
        self,
        model_name,
        batchsize,
        epochs,
        warmup_percent,
        logging_level: str = "WARNING",
        log_file_path: str = None,
        verbose: bool = True,
    ) -> None:
        if model_name not in [
            "sentence-transformers/all-mpnet-base-v2",
            "sentence-transformers/all-MiniLM-L12-v2",
        ]:
            raise ValueError(
                "Incorrect model name specified. Check docstrings of this class for supported models."
            )

        self.MODEL_NAME = model_name
        self.BATCH_SIZE = batchsize
        self.EPOCHS = epochs
        self.WARMUP_PERCENT = warmup_percent
        self.logger = MyLogger(
            level=logging_level, log_file_path=log_file_path, verbose=verbose
        ).logger
        self.DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._model = None

    def __repr__(self) -> str:
        if self._model is None:
            raise ValueError("Model hasn't been initialized.")

        pytorch_total_params = sum(p.numel() for p in self._model.parameters())
        pytorch_trainable_params = sum(
            p.numel() for p in self._model.parameters() if p.requires_grad
        )

        return f"Total parameters = {pytorch_total_params}; Trainable parameters = {pytorch_trainable_params}"

    @property
    def model(self):
        if self._model is None:
            raise ValueError("Model hasn't been initialized.")
        else:
            return self._model

    def initiate_model(self) -> None:
        """Initializes SBERT models by downloading pretrained weights from sentence transformers.
        Only accepts all-minilm and all-mpnet models."""
        # Step 1: use an existing language model
        word_embedding_model = models.Transformer(self.MODEL_NAME)

        # Step 2: use a pool function over the token embeddings
        pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension())

        # Join steps 1 and 2 using the modules argument
        self._model = SentenceTransformer(modules=[word_embedding_model, pooling_model])

        self.logger.info("Siamese model has been initialized.")

        return

    def setup_training_config(
        self, train_dl: torch.utils.data.DataLoader,
        evaluator : BinaryClassificationEvaluator,
        model_save_path : str,
        loss: str = "MultipleNegatives",
    ):
        """Setups the loss function and warmup steps for training

        Parameters
        ----------
        train_dl : torch.utils.data.DataLoader
            Training dataloader that will be used for training.

        evaluator : BinaryClassificationEvaluator
            Evaluates a model based on the similarity of the embeddings by calculating the accuracy of identifying similar and dissimilar sentences.

        model_save_path : str
            Path for saving model results

        loss: str, optional
            Specify the loss to choose based on type of data in dataloader. Available options are MultipleNegatives and Contrastive. MultipleNegatives should be passed if dataloder only contains positive pairs of sentences without gold labels. Else it should be Contrastive.
        """
        if loss not in ["MultipleNegatives", "Contrastive"]:
            raise ValueError(f"Wrong loss function passed in {loss}")

        number_of_batches = len(train_dl)
        self.warmup_steps = int(number_of_batches * self.EPOCHS * self.WARMUP_PERCENT)
        if loss == "MultipleNegatives":
            self.loss_func = losses.MultipleNegativesRankingLoss(model=self._model)
        else:
            self.loss_func = losses.ContrastiveLoss(model=self._model)

        self.train_dl = train_dl
        self.evaluator = evaluator
        self.model_save_path = model_save_path
        return

    def __train_callback(self, scores, epoch, steps):
        """

        Parameters
        ----------
        scores : float
            Validation score
        epoch : int
            Number of epochs given training
        steps : int
            Training steps
        """
        self.logger.info(f"For the epoch {epoch} and training steps {steps},validation score is{scores}")

    def train(self, show_progress_bar: bool):
        """Trains the given SBERT model

        Parameters
        ----------
        show_progress_bar : bool
            If True it shows progress whether the code is completing and give the user an indication of how long an operation will take to complete.
        """
        self.logger.info("Training started.")

        self._model.fit(
            train_objectives=[(self.train_dl, self.loss_func)],
            evaluator=self.evaluator,
            epochs=self.EPOCHS,
            warmup_steps=self.warmup_steps,
            show_progress_bar=show_progress_bar,
            output_path=self.model_save_path,
            save_best_model=True,
            use_amp=True,
            callback=self.__train_callback,

        )
        self.logger.info("Training completed.")
        return

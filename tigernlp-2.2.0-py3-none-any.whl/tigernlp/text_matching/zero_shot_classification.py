import numpy as np
import pandas as pd
import transformers
from joblib import Parallel, delayed, effective_n_jobs
from typing import Union

from tigernlp.core.utils import MyLogger

"""
TODO
1. Check for parallel processing in Zero Shot Classification
"""


class ZeroShotClassification:

    r"""Zero shot text classification algorithm to classify text documents without using training dataset.

    Performs zero-shot text classification using hugging face transformers models.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True
    Examples
    --------
    >>> from tigernlp.text_matching.api import ZeroShotClassification
    >>> sequence = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> labels = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> model_object = ZeroShotClassification()
    >>> df_theme = df_theme = (
    >>>     model_object
    >>>     .get_model_output(text_doc1=sequence, text_doc2=labels, multi_label=True)
    >>> )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """ZeroShotClassification class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _classifier(self):
        """Zero shot classification model using hugging face transformers pipeline

        Returns
        -------
        model object
            zero shot classification model using transformers pipeline
        """
        if self.embedding_model is None:
            default_model = "facebook/bart-large-mnli"
            self.logger.info(f"Loading default sentence embedding model: {default_model}")
            self.embedding_model = default_model

        self.classifier_model = transformers.pipeline("zero-shot-classification", multi_label=self.multi_label, model=self.embedding_model)

    def _predict(self, x, y):
        """Function to predict probabilities for text documents"""
        df = self.classifier_model(x, y)
        return df

    def _get_input_chunk(self, sequence, label):
        """Function to create the input chunks for parallel processing"""

        if self.n_jobs > 2:
            n1 = 2
            n2 = self.n_jobs / 2
        else:
            n1 = 1
            n2 = 2

        split_size = int(len(sequence) / n2)
        input_seq = []
        for x in range(0, len(sequence), split_size):
            input_seq.append(sequence[x : (x + split_size)])

        split_size = int(len(label) / n1)
        input_lab = []
        for x in range(0, len(label), split_size):
            input_lab.append(label[x : (x + split_size)])

        input_params = []
        for x, y in [(x, y) for x in input_seq for y in input_lab]:
            input_params.append([x, y])

        return input_params

    def get_model_output(
        self,
        text_doc1: Union[str, list, pd.DataFrame] = list(),
        text_doc2: Union[str, list] = None,
        column_dict={"col_doc1": None, "col_doc2": None},
        cross_match=True,
        return_df=True,
        multi_label=True,
        embedding_model=None,
        keywords_to_check=list(),
        parallel_process=False,
        n_jobs=-1,
    ):
        """Classify text documents using the zero-shot classification algorithm

        Parameters
        ----------
        text_doc1 : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to predict probability with text_doc2, by default list()
        text_doc2 : Union[str, list], optional
            string or list of text documents to get probabilities for against text_doc1, by default None
        column_dict : dict, optional
            col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
        cross_match : bool, optional
            if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

            if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
        return_df : bool, optional
            if True, return output of text matching as dataframe else return list of scores
        multi_label : True, optional
            whether or not multiple candidate text_doc2 can be true, by default True

            if False - the sum of the probability across all sentences in text_doc2=1, if True - the probability of each text_doc2 lies between 0-1

            The value should be True if you want to do multilabel classification whereas False for multiclass classification
        embedding_model : str, optional
            the model that will be used by the pipeline to make predictions, by default "facebook/bart-large-mnli"
        keywords_to_check : str, optional
            The keywords to check to be present in the sequence. It will check for any keyword present in the list, by default list()
        parallel_process: False, optional (bool)
            Whether to use parallel processing, by default False.
        n_jobs : int, optional
            number of concurrent workers, by default -1 i.e., use all available workers


        Returns
        -------
        pd.DataFrame
            if return_df is True, dataframe with probability score as column "scores" between text_doc1 and text_doc2. Output dataframe shape will be equal to len(text_doc1) x len(text_doc2)

            if return_df is False, list of lists with probability score between text_doc1 and text_doc2 where list[0][1] is the score between text_doc1[0] and text_doc2[1]
            Example - [[0, 0.95, 0.5], [0.45, 1, 0.78]]

        """
        """
        Example : sequence = ["dolphin safe", "grain free"], labels = ["Grain Free", "Made in the USA"]
        Output dataframe:

            sequence	    |   labels	           | scores	  | predicted
            ----------------|----------------------|----------|-----------
            dolphin safe	|   Made in the USA	   | 0.173909 |	    0
            dolphin safe	|   Grain Free	       | 0.047984 |	    0
            grain free	    |   Grain Free	       | 0.963931 |	    1
            grain free	    |   Made in the USA	   | 0.046205 |	    0
        """
        try:
            self.logger.info("Zero-shot classification started")

            self.embedding_model = embedding_model
            self.multi_label = multi_label
            self.keywords_to_check = keywords_to_check
            self.n_jobs = effective_n_jobs(n_jobs)
            self.cross_match = cross_match

            if not isinstance(text_doc1, pd.DataFrame) and not isinstance(text_doc1, str) and not isinstance(text_doc1, list):
                self.logger.error("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")
                raise ValueError("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")

            self._classifier()

            if isinstance(text_doc1, pd.DataFrame):

                if "scores" in text_doc1.columns:
                    del text_doc1["scores"]

                if not column_dict["col_doc1"]:
                    self.logger.error(
                        "Input column name is not provided, " "set parameter column_dict['col_doc1'] for the input column name."
                    )
                    raise ValueError("Set input column name to parameter: column_dict['col_doc1']")

                if column_dict["col_doc1"] not in text_doc1.columns:
                    self.logger.error("Input column name column_dict['col_doc1'] is either incorrect or not present in the dataframe.")
                    raise ValueError("Provide correct input column name column_dict['col_doc1'].")

                col_doc1 = column_dict["col_doc1"]

                if isinstance(text_doc2, str):
                    text_doc1["text_doc2"] = text_doc2
                    text_doc1["scores"] = text_doc1.apply(lambda x: self._predict(x[col_doc1], x["text_doc2"])["scores"][0], axis=1)

                elif isinstance(text_doc2, list):

                    if len(text_doc2) == 0:
                        self.logger.error("Empty list can not be used for matching documents")
                        raise ValueError("Provide list with text documents")

                    if not cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in number of rows of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Number of rows of text_doc1 and lenght of text_doc2 is different")

                        else:
                            text_doc1["text_doc2"] = text_doc2
                            text_doc1["scores"] = text_doc1.apply(lambda x: self._predict(x[col_doc1], x["text_doc2"])["scores"][0], axis=1)

                    else:
                        score = self._predict(text_doc1[col_doc1].tolist(), text_doc2)
                        score = pd.DataFrame(score).explode(["labels", "scores"])
                        score.rename(columns={"sequence": col_doc1, "labels": "text_doc2"}, inplace=True)
                        score.drop_duplicates(inplace=True)

                        out = pd.DataFrame()
                        for text in text_doc2:
                            temp = text_doc1.copy()
                            temp["text_doc2"] = text
                            temp = pd.merge(temp, score, on=[col_doc1, "text_doc2"], how="left")
                            out = pd.concat([out, temp], ignore_index=True)

                        text_doc1 = out.copy()

                else:
                    if not column_dict["col_doc2"]:
                        self.logger.error(
                            "Input column name is not provided, " "set parameter column_dict['col_doc2'] for the input column name."
                        )
                        raise ValueError("Set input column name to parameter: column_dict['col_doc2']")

                    if column_dict["col_doc2"] not in text_doc1.columns:
                        self.logger.error("Input column name column_dict['col_doc2'] is either incorrect or not present in the dataframe.")
                        raise ValueError("Provide correct input column name column_dict['col_doc2'].")

                    if cross_match:
                        self.logger.error(
                            "Cross matching is not possible within dataframe. Provide text documents as a list for cross match option."
                        )
                        raise ValueError("Provide text documents as a list for cross match option.")

                    else:
                        col_doc2 = column_dict["col_doc2"]
                        text_doc1["scores"] = text_doc1.apply(lambda x: self._predict(x[col_doc1], x[col_doc2])["scores"][0], axis=1)

                text_doc1["scores"] = text_doc1["scores"].astype(float)
                text_doc1["scores"] = np.round(text_doc1["scores"], 5)
                self.logger.info("Zero-shot classification completed")
                return text_doc1

            else:

                if not isinstance(text_doc2, str) and not isinstance(text_doc2, list):
                    self.logger.error("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")
                    raise ValueError("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")

                if (len(text_doc1) != len(np.unique(text_doc1)) and isinstance(text_doc1, list)) or (
                    len(text_doc2) != len(np.unique(text_doc2)) and isinstance(text_doc2, list)
                ):
                    self.logger.error(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )
                    raise ValueError(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )

                if len(text_doc1) == 0 or len(text_doc2) == 0:
                    self.logger.error("Empty list/string can not be used for matching documents")
                    raise ValueError("Provide list/string with text documents")

                if isinstance(text_doc1, str) and isinstance(text_doc2, str):
                    score = self._predict(text_doc1, text_doc2)
                    df = pd.DataFrame(score).explode(["labels", "scores"])

                elif isinstance(text_doc1, str) and isinstance(text_doc2, list):
                    score = self._predict(text_doc1, text_doc2)
                    df = pd.DataFrame(score).explode(["labels", "scores"])

                elif isinstance(text_doc1, list) and isinstance(text_doc2, str):
                    score = self._predict(text_doc1, text_doc2)
                    df = pd.DataFrame(score).explode(["labels", "scores"])

                elif isinstance(text_doc1, list) and isinstance(text_doc2, list):

                    if not cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in length of text_doc1 {len(text_doc1)} against length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Length of text_doc1 and text_doc2 is different")

                        if parallel_process:
                            self.logger.error("Parallel processing not available for one to one matching")
                            raise ValueError("Parallel processing not available for one to one matching")

                        out = []
                        for x, y in zip(text_doc1, text_doc2):
                            val = self._predict(x, y)["scores"][0]
                            out.append([x, y, val])

                        df = pd.DataFrame(out)
                        df.columns = ["sequence", "labels", "scores"]

                    else:

                        if parallel_process:

                            self.logger.info(
                                f"[Parallel(n_jobs={self.n_jobs})]: Using backend LokyBackend with {self.n_jobs} concurrent workers."
                            )
                            input_params = self._get_input_chunk()

                            df_parallel = Parallel(n_jobs=self.n_jobs, verbose=50, backend="loky")(
                                delayed(self._predict)(x, y) for x, y in input_params
                            )

                            df = pd.DataFrame()
                            for x in df_parallel:
                                df = pd.concat([pd.DataFrame(x).explode(["labels", "scores"]), df], ignore_index=True)
                        else:
                            df = self._predict(text_doc1, text_doc2)
                            df = pd.DataFrame(df).explode(["labels", "scores"])

                df["scores"] = df["scores"].astype(float)
                df["scores"] = np.round(df["scores"], 5)
                df.rename(columns={"sequence": "text_doc1", "labels": "text_doc2"}, inplace=True)

                if return_df:
                    if len(self.keywords_to_check) > 0:
                        self.keywords_to_check = "|".join(self.keywords_to_check).lower()
                        df["keyword_present_flag"] = np.where(df["text_doc1"].str.contains(self.keywords_to_check), 1, 0)

                    df.reset_index(inplace=True, drop=True)
                    df.reset_index(inplace=True, drop=True)

                    self.logger.info("Zero-shot classification completed")
                    return df
                else:
                    original_cols_order = df.text_doc2.unique().tolist()
                    original_index_original = df.text_doc1.unique()
                    check = pd.pivot(df, index="text_doc1", columns="text_doc2", values="scores")[original_cols_order]
                    score = np.array(check.reindex(original_index_original))
                    if not self.cross_match:
                        score = np.diag(score)
                    self.logger.info("Zero-shot classification completed")
                    return score

        except Exception as e:
            self.logger.error(f"Error occurred during zero-shot classification {e}")

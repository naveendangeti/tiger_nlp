import numpy as np
import pandas as pd
from scipy.spatial import distance
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from typing import Union

from tigernlp.core.utils import MyLogger


def EuclideanDistance(
    text_doc1: Union[str, list, pd.DataFrame] = list(),
    text_doc2: Union[str, list] = None,
    column_dict={"col_doc1": None, "col_doc2": None},
    vectorizer_type="tfidf",
    cross_match=True,
    return_df=True,
    log_level="INFO",
    log_file_path=None,
    verbose=True,
):
    """Computes euclidean distance between the list of two text documents.

    According to the Euclidian distance, the shorter the distance between the two texts is, the more similar they are.
    The length of the text is a factor that affects the result. Long sentences tends to have higher Euclidian score than the short ones.
    Euclidian scores does not consider the meaning of the words.

    Example -
    text_1 = "I love playing football with my friends"
    text_2 = "I hate watching and playing basketball"
    text_3 = "When I was a kid I was playing football with my friends every day all the evening"

    Euclidean score between text_1 vs text3 is 3 and text_1 vs text_3 is 3.46 which does not capture the meaning of the complete sentence.
    Cosine Similarity should be used to overcome the length issue and ensure more conteztually accurate results.

    Parameters
    ----------
    text_doc1 : Union[str, list, pd.DataFrame], optional
        string or list of text documents or dataframe to match with text_doc2, by default list()
    text_doc2 : Union[str, list], optional
        string or list of text documents to match with text_doc1, by default None
    column_dict : dict, optional
        col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
    vectorizer_type : str, optional
        Vectorizer type tfidf or count to compute feature vectors for text similarity, by default `tfidf`

        For Example - tfidf will transform the text to its tfidf score and will compute euclidean distance on the transformed text. Similarly, count will transform the text to its count frequency
    cross_match : bool, optional
        if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

        if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
    return_df : bool, optional
        if True, return output of text matching as dataframe else return list of scores
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Returns
    -------
    pd.DataFrame or list
        if return is True, dataframe with euclidean distance score as column "scores" between two text documents. Output dataframe shape will be equal to len(text_doc1) x len(text_doc2)

        if return_df is False, list of lists with euclidean distance score between text_doc1 and text_doc2 where list[0][1] is the score between text_doc1[0] and text_doc2[1]
        Example - [[1.0000, 0.3651, 0.3632], [0.3651, 1.0000, 0.3862]]

    Examples
    --------
    >>> from tigernlp.text_matching.api import EuclideanDistance
    >>> text_doc1 = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> text_doc2 = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> df = EuclideanDistance(text_doc1, text_doc2)
    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    try:

        logger.info("Text matching using euclidean distance started")

        if not isinstance(text_doc1, pd.DataFrame) and not isinstance(text_doc1, str) and not isinstance(text_doc1, list):
            logger.error("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")
            raise ValueError("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")

        if vectorizer_type == "tfidf":
            vectorizer = TfidfVectorizer()
        elif vectorizer_type == "count":
            vectorizer = CountVectorizer()
        else:
            raise Exception("""Invalid vectorizer type parameter provided. Please pass vectorizer type as count/tfidf""")

        def dist(x, y):
            vectorizer.fit([x, y])
            vectors_x = vectorizer.transform([x])
            vectors_y = vectorizer.transform([y])
            val = np.round(distance.cdist(vectors_x.todense(), vectors_y.todense(), "euclidean")[0][0], 5)
            return val

        if isinstance(text_doc1, pd.DataFrame):

            if "scores" in text_doc1.columns:
                del text_doc1["scores"]

            if not column_dict["col_doc1"]:
                logger.error("Input column name is not provided, " "set parameter column_dict['col_doc1'] for the input column name.")
                raise ValueError("Set input column name to parameter: column_dict['col_doc1']")

            if column_dict["col_doc1"] not in text_doc1.columns:
                logger.error("Input column name column_dict['col_doc1'] is either incorrect or not present in the dataframe.")
                raise ValueError("Provide correct input column name column_dict['col_doc1'].")

            col_doc1 = column_dict["col_doc1"]

            if isinstance(text_doc2, str):

                text_doc1["text_doc2"] = text_doc2
                text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)

            elif isinstance(text_doc2, list):

                if len(text_doc2) == 0:
                    logger.error("Empty list can not be used for matching documents")
                    raise ValueError("Provide list with text documents")

                if not cross_match:
                    if len(text_doc1) != len(text_doc2):
                        logger.error(
                            f"Mismatch found in number of rows of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}"
                        )
                        raise ValueError("Number of rows of text_doc1 and lenght of text_doc2 is different")

                    else:
                        text_doc1["text_doc2"] = text_doc2
                        text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)

                else:

                    out = pd.DataFrame()
                    for text in text_doc2:
                        temp = text_doc1.copy()
                        temp["text_doc2"] = text
                        temp["scores"] = temp.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)
                        out = pd.concat([out, temp], ignore_index=True)

                    text_doc1 = out.copy()

            else:
                if not column_dict["col_doc2"]:
                    logger.error("Input column name is not provided, " "set parameter column_dict['col_doc2'] for the input column name.")
                    raise ValueError("Set input column name to parameter: column_dict['col_doc2']")

                if column_dict["col_doc2"] not in text_doc1.columns:
                    logger.error("Input column name column_dict['col_doc2'] is either incorrect or not present in the dataframe.")
                    raise ValueError("Provide correct input column name column_dict['col_doc2'].")

                if cross_match:
                    logger.error(
                        "Cross matching is not possible within dataframe. Provide text documents as a list for cross match option."
                    )
                    raise ValueError("Provide text documents as a list for cross match option.")

                col_doc2 = column_dict["col_doc2"]
                text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x[col_doc2]), axis=1)

            logger.info("Text matching using euclidean score completed")
            return text_doc1

        else:

            if not isinstance(text_doc2, str) and not isinstance(text_doc2, list):
                logger.error("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")
                raise ValueError("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")

            if (len(text_doc1) != len(np.unique(text_doc1)) and isinstance(text_doc1, list)) or (
                len(text_doc2) != len(np.unique(text_doc2)) and isinstance(text_doc2, list)
            ):
                logger.error("Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity")
                raise ValueError(
                    "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                )

            if len(text_doc1) == 0 or len(text_doc2) == 0:
                logger.error("Empty list can not be used for matching documents")
                raise ValueError("Provide list with text documents")

            out = []
            if isinstance(text_doc1, str) and isinstance(text_doc2, str):
                out.append([text_doc1, text_doc2, dist(text_doc1, text_doc2)])

            elif isinstance(text_doc1, str) and isinstance(text_doc2, list):
                cross_match = True
                out = []
                for text in text_doc2:
                    val = dist(text_doc1, text)
                    out.append([text_doc1, text, val])

            elif isinstance(text_doc1, list) and isinstance(text_doc2, str):
                cross_match = True
                out = []
                for text in text_doc1:
                    val = dist(text, text_doc2)
                    out.append([text, text_doc2, val])

            elif isinstance(text_doc1, list) and isinstance(text_doc2, list):
                out = []
                if not cross_match:
                    if len(text_doc1) != len(text_doc2):
                        logger.error(f"Mismatch found in length of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}")
                        raise ValueError("Length of text_doc1 and text_doc2 is different")

                    else:
                        for text1, text2 in zip(text_doc1, text_doc2):
                            val = dist(text1, text2)
                            out.append([text1, text2, val])

                else:
                    for text1, text2 in [(x, y) for x in text_doc1 for y in text_doc2]:
                        val = dist(text1, text2)
                        out.append([text1, text2, val])

            df = pd.DataFrame(out)
            df.columns = ["text_doc1", "text_doc2", "scores"]

            if return_df:
                df.reset_index(inplace=True, drop=True)
                df.reset_index(inplace=True, drop=True)
                logger.info("Text matching using euclidean score completed")
                return df
            else:
                original_cols_order = df.text_doc2.unique().tolist()
                original_index_original = df.text_doc1.unique()
                check = pd.pivot(df, index="text_doc1", columns="text_doc2", values="scores")[original_cols_order]
                score = np.array(check.reindex(original_index_original))
                if not cross_match:
                    score = np.diag(score)
                logger.info("Text matching using euclidean score completed")
                return score

    except Exception as e:
        logger.error(f"Error occurred during euclidean score computation {e}")


def JaccardSimilarity(
    text_doc1: Union[str, list, pd.DataFrame] = list(),
    text_doc2: Union[str, list] = None,
    column_dict={"col_doc1": None, "col_doc2": None},
    cross_match=True,
    return_df=True,
    log_level="INFO",
    log_file_path=None,
    verbose=True,
):
    """Computes jaccard similarity between the list of two text documents.

    Text documents should not contain any special characters.

    Parameters
    ----------
    text_doc1 : Union[str, list, pd.DataFrame], optional
        string or list of text documents or dataframe to match with text_doc2, by default list()
    text_doc2 : Union[str, list], optional
        string or list of text documents to match with text_doc1, by default None
    column_dict : dict, optional
        col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
    cross_match : bool, optional
        if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

        if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
    return_df : bool, optional
        if True, return output of text matching as dataframe else return list of scores
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Returns
    -------
    pd.DataFrame or list
        if return_df is True, dataframe with jaccard similarity score as column "scores" between two text documents. Output dataframe shape will be equal to len(text_doc1) x len(text_doc2)

        if return_df is False, list of lists with jaccard similarity score between text_doc1 and text_doc2 where list[0][1] is the score between text_doc1[0] and text_doc2[1]
        Example - [[1.0000, 0.3651, 0.3632], [0.3651, 1.0000, 0.3862]]

    Examples
    --------
    >>> from tigernlp.text_matching.api import JaccardSimilarity
    >>> text_doc1 = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> text_doc2 = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> df = JaccardSimilarity(text_doc1, text_doc2)

    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    try:

        logger.info("Text matching using jaccard similarity started")

        if not isinstance(text_doc1, pd.DataFrame) and not isinstance(text_doc1, str) and not isinstance(text_doc1, list):
            logger.error("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")
            raise ValueError("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")

        def dist(x, y):
            str1 = set(x.lower().split())
            str2 = set(y.lower().split())
            val = np.round(float(len(str1 & str2)) / len(str1 | str2), 5)
            return val

        if isinstance(text_doc1, pd.DataFrame):

            if "scores" in text_doc1.columns:
                del text_doc1["scores"]

            if not column_dict["col_doc1"]:
                logger.error("Input column name is not provided, " "set parameter column_dict['col_doc1'] for the input column name.")
                raise ValueError("Set input column name to parameter: column_dict['col_doc1']")

            if column_dict["col_doc1"] not in text_doc1.columns:
                logger.error("Input column name column_dict['col_doc1'] is either incorrect or not present in the dataframe.")
                raise ValueError("Provide correct input column name column_dict['col_doc1'].")

            col_doc1 = column_dict["col_doc1"]

            if isinstance(text_doc2, str):

                text_doc1["text_doc2"] = text_doc2
                text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)

            elif isinstance(text_doc2, list):

                if len(text_doc2) == 0:
                    logger.error("Empty list can not be used for matching documents")
                    raise ValueError("Provide list with text documents")

                if not cross_match:
                    if len(text_doc1) != len(text_doc2):
                        logger.error(
                            f"Mismatch found in number of rows of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}"
                        )
                        raise ValueError("Number of rows of text_doc1 and lenght of text_doc2 is different")

                    else:
                        text_doc1["text_doc2"] = text_doc2
                        text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)

                else:

                    out = pd.DataFrame()
                    for text in text_doc2:
                        temp = text_doc1.copy()
                        temp["text_doc2"] = text
                        temp["scores"] = temp.apply(lambda x: dist(x[col_doc1], x["text_doc2"]), axis=1)
                        out = pd.concat([out, temp], ignore_index=True)

                    text_doc1 = out.copy()

            else:
                if not column_dict["col_doc2"]:
                    logger.error("Input column name is not provided, " "set parameter column_dict['col_doc2'] for the input column name.")
                    raise ValueError("Set input column name to parameter: column_dict['col_doc2']")

                if column_dict["col_doc2"] not in text_doc1.columns:
                    logger.error("Input column name column_dict['col_doc2'] is either incorrect or not present in the dataframe.")
                    raise ValueError("Provide correct input column name column_dict['col_doc2'].")

                if cross_match:
                    logger.error(
                        "Cross matching is not possible within dataframe. Provide text documents as a list for cross match option."
                    )
                    raise ValueError("Provide text documents as a list for cross match option.")

                col_doc2 = column_dict["col_doc2"]
                text_doc1["scores"] = text_doc1.apply(lambda x: dist(x[col_doc1], x[col_doc2]), axis=1)

            logger.info("Text matching using jaccard similarity completed")
            return text_doc1

        else:

            if not isinstance(text_doc2, str) and not isinstance(text_doc2, list):
                logger.error("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")
                raise ValueError("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")

            if (len(text_doc1) != len(np.unique(text_doc1)) and isinstance(text_doc1, list)) or (
                len(text_doc2) != len(np.unique(text_doc2)) and isinstance(text_doc2, list)
            ):
                logger.error("Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity")
                raise ValueError(
                    "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                )

            if len(text_doc1) == 0 or len(text_doc2) == 0:
                logger.error("Empty list can not be used for matching documents")
                raise ValueError("Provide list with text documents")

            out = []
            if isinstance(text_doc1, str) and isinstance(text_doc2, str):
                out.append([text_doc1, text_doc2, dist(text_doc1, text_doc2)])

            elif isinstance(text_doc1, str) and isinstance(text_doc2, list):
                cross_match = True
                out = []
                for text in text_doc2:
                    val = dist(text_doc1, text)
                    out.append([text_doc1, text, val])

            elif isinstance(text_doc1, list) and isinstance(text_doc2, str):
                cross_match = True
                out = []
                for text in text_doc1:
                    val = dist(text, text_doc2)
                    out.append([text, text_doc2, val])

            elif isinstance(text_doc1, list) and isinstance(text_doc2, list):
                out = []
                if not cross_match:
                    if len(text_doc1) != len(text_doc2):
                        logger.error(f"Mismatch found in length of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}")
                        raise ValueError("Length of text_doc1 and text_doc2 is different")

                    else:
                        for text1, text2 in zip(text_doc1, text_doc2):
                            val = dist(text1, text2)
                            out.append([text1, text2, val])

                else:
                    for text1, text2 in [(x, y) for x in text_doc1 for y in text_doc2]:
                        val = dist(text1, text2)
                        out.append([text1, text2, val])

            df = pd.DataFrame(out)
            df.columns = ["text_doc1", "text_doc2", "scores"]
            if return_df:

                df.reset_index(inplace=True, drop=True)
                df.reset_index(inplace=True, drop=True)
                logger.info("Text matching using jaccard similarity completed")
                return df
            else:
                original_cols_order = df.text_doc2.unique().tolist()
                original_index_original = df.text_doc1.unique()
                check = pd.pivot(df, index="text_doc1", columns="text_doc2", values="scores")[original_cols_order]
                score = np.array(check.reindex(original_index_original))
                if not cross_match:
                    score = np.diag(score)
                logger.info("Text matching using jaccard similarity completed")
                return score

    except Exception as e:
        logger.error(f"Error occurred during jaccard similarity score computation {e}")

"""
    This module provides functions to generate questions from given text.
"""

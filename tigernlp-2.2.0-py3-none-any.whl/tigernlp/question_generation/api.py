"""
    Utilities around Question Generation
    This module provides functions to generate questions from given text.
"""

from .question_generator import QuestionGenerator

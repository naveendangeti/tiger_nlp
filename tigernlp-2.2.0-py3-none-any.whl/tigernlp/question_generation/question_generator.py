import re
import warnings
from tqdm import tqdm
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
from typing import Optional

from tigernlp.core.api import Paraphraser
from tigernlp.core.utils import MyLogger

from ..action_object_pairs.api import AOPGenerate


class QuestionGenerator:
    """Question generator class generates question from given text.

    Parameters
    -----------
    tokenizer : str
        A parameter that specifies the name or path of hugging face tokeniser used to preprocess input text. If not provided, the default tokenizer is used. Options: "mrm8488/t5-base-finetuned-question-generation-ap" (default)
    model : str
        An optional parameter that specifies the name or path of hugging face model used to generate questions. If not provided, the default model is used. Options:"mrm8488/t5-base-finetuned-question-generation-ap" (default)
    explode : bool
        A boolean parameter that specifies whether to generate multiple variations of each question or not. If set to True, the generate method will return a list of questions instead of a single question. default = False
    paraphraser_model : union[str, paraphraser model]
        A parameter that specifies the name or path of hugging face parpaphraser or the model instance its self used for paraphrasing. This is used to generate variations of questions if the explode parameter is set to True. Options for path: "prithivida/parrot_paraphraser_on_T5" (default), "ramsrigouthamg/t5_sentence_paraphraser"
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True


    Example
    -------
    >>> # If you want to generate question for one string input.
    >>> from tigernlp.question_generation.api import QuestionGenerator
    >>> QG = QuestionGenerator()
    >>> QG.generate(
    >>>     text="Harry Potter is a series of seven fantasy novels written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry. The main story arc concerns Harry's struggle against Lord Voldemort, a dark wizard who intends to become immortal, overthrow the wizard governing body known as the Ministry of Magic and subjugate all wizards and Muggles",
    >>>         )
    >>> ['What is the main character of Lord Voldemort?',
    >>> "What is Voldemort's goal?",
    >>> "What is Harry Potter's role in the series?",
    >>> 'What does the main story of Harry Potter relate to?',
    >>> 'What does Voldemort want to do to overthrow the Ministry of Magic?',
    >>> "What is the main focus of Harry Potter's novels?",
    >>> 'What is the main plot of Harry Potter?',
    >>> 'What is the main story arc of Harry Potter?',
    >>> 'What does Lord Voldemort want to do to wizards and Muggles?',
    >>> 'What do the novels do?']
    >>>
    >>> # If you want to generate questions for list of string input
    >>> QG.generate(
    >>>             text = ["I want to add my kids to my insurance policy.",
    >>>                     'Rahul wants to go to chennai.']
    >>>             )
    >>> [['What do I want to do with my insurance policy?','What do I want to do with my kids?'],
    >>> ['What does Rahul want to do?', 'What does Rahul want to do?']]
    >>>
    >>> # If dealing with bigger document(string), splitting of document can be a done as shown:
    >>>
    >>> QG.generate(
    >>>         text = ["Harry Potter is a series of seven fantasy novels. Harry potter written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley. All of whom are students at Hogwarts School of Witchcraft and Wizardry. The main story arc concerns Harry's struggle against Lord Voldemort, a dark wizard who intends to become immortal, overthrow the wizard governing body known as the Ministry of Magic and subjugate all wizards and Muggles", 'The series was originally published in English by Bloomsbury in the United Kingdom and Scholastic Press in the United States. All versions around the world are printed by Grafica Veneta in Italy.[1] A series of many genres, including fantasy, drama, coming-of-age fiction, and the British school story (which includes elements of mystery, thriller, adventure, horror, and romance), the world of Harry Potter explores numerous themes and includes many cultural meanings and references.[2] According to Rowling, the main theme is death.[3] Other major themes in the series include prejudice, corruption, and madness.'],
    >>>         split_by='.', # split by sentence
    >>>         stride=2, # taking two sentence at a time
    >>>         overlap=0,
    >>>         )
    >>> [['What do Harry Potter novels chronicle?',
    >>> 'What is the main plot of the book?',
    >>> 'What does Lord Voldemort want to do to wizards and Muggles?',
    >>> 'What do the novels do?',
    >>> 'What do the novels chronicle?',
    >>> 'What is the main story arc?',
    >>> 'What is the main character of the story?',
    >>> 'What does Voldemort want to overthrow?',
    >>> "What is Voldemort's plan to do?"],
    >>> ['What does Harry Potter do?',
    >>> 'What is one of the major themes in the series?',
    >>> 'What other major themes are in the series?',
    >>> 'What elements of the British school story are included in the Harry Potter series?',
    >>> 'What is the name of the cultural meaning of Harry Potter?',
    >>> 'What is one of the major themes of the series?',
    >>> 'What does Harry Potter do with its themes?',
    >>> "What is Grafica Veneta's job?",
    >>> 'What is the main theme of Harry Potter?',
    >>> 'What was the original purpose of Bloomsbury?',
    >>> 'What is one of the themes of Harry Potter?',
    >>> 'What does Harry Potter include cultural meanings and references?']]

    """

    def __init__(
        self,
        tokenizer: Optional[str] = "mrm8488/t5-base-finetuned-question-generation-ap",
        model: Optional[str] = "mrm8488/t5-base-finetuned-question-generation-ap",
        explode: bool = False,
        paraphraser_model: str = "prithivida/parrot_paraphraser_on_T5",
        log_level: str = "INFO",
        log_file_path: str = None,
        verbose: Optional[bool] = False,
    ):
        """Question Generator class initialization

        Parameters
        ----------
        tokenizer : str
            A parameter that specifies the name or path of hugging face tokeniser used to preprocess input text. If not provided, the default tokenizer is used. Options: "mrm8488/t5-base-finetuned-question-generation-ap" (default)
        model : str
            An optional parameter that specifies the name or path of hugging face model used to generate questions. If not provided, the default model is used. Options: "mrm8488/t5-base-finetuned-question-generation-ap" (default)
        explode : bool
            A boolean parameter that specifies whether to generate multiple variations of each question or not. If set to True, the generate method will return a list of questions instead of a single question. default = False
        paraphraser_model : union[str, paraphraser model]
            A parameter that specifies the name or path of hugging face parpaphraser or the model instance its self used for paraphrasing. This is used to generate variations of questions if the explode parameter is set to True. Options for path: "prithivida/parrot_paraphraser_on_T5" (default), "ramsrigouthamg/t5_sentence_paraphraser"
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True

        Raises
        ------
        Exception
            raises exception when tokenizer or the model is name is wrong

        """
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

        try:
            if isinstance(tokenizer, str):
                self.tokenizer = AutoTokenizer.from_pretrained(tokenizer)
            else:
                self.tokenizer = tokenizer
                self.logger.info("Using given tokenizer")

            if isinstance(model, str):
                self.model = AutoModelForSeq2SeqLM.from_pretrained(model)
            else:
                self.model = model
                self.logger.info("Using given model")

            self.explode = explode
            if explode:

                if isinstance(paraphraser_model, str):
                    self.parrot = Paraphraser(paraphraser_model=paraphraser_model)
                else:
                    self.parrot = paraphraser_model
                    self.logger.info("Using given paraphraser model")
        except Exception as e:
            self.logger.error(f"Error while loading model  {e}.")
            raise OSError(f"Error while loading model  {e}.")

    def generate(
        self,
        text: str,
        intent: str = None,
        split_by: str = None,
        stride: int = 1,
        overlap: int = 0,
        diversity_ranker: str = "levenshtein",
        do_diverse: bool = False,
        max_return_phrases: int = 10,
        max_length: int = 32,
        adequacy_threshold: float = 0.80,
        fluency_threshold: float = 0.80,
        use_gpu: bool = False,
    ):
        r"""This function is used to generate question using model and controls the flow of code for different types of inputs

        Parameters
        ----------
        text : union[str, List[str,str]]
            input string or list of strings.
        intent : union[str, List[str,str], List[List[str,str],List[str,str]]]
            It is described as the answer to the input text which the question generator model should focus.
            Default is None. Corresponding to text input intent can be string list of string or list of list of strings.
            If None, the intents are generated using tigernlp AOP library
        split_by : str
            This parameter is used to split the input text into segments. It takes a string as input, and the text is split into segments wherever the string occurs. For example, if split_by is set to '\\n\\n' , the text will be split into segments wherever there are two newline characters in a row. None if no splitby operation is needed. Options : split by words - " ", split by comma - ",", split by sentence - ".", default = None
        stride : int
            integer input for number of splitted segments to take as one. default = 1
        overlap : int
            integer input for number of segments to be common between two stride. default = 0
        diversity_ranker : str
            The parameter specifies the method to use for ranking the diversity of generated questions. Options - "levenshtein" (default), "euclidean", "diff"
        do_diverse : bool
            True if Lexical, Phrasal, Syntactical changes are allowed while paraphrasing. default False
        max_return_phrases : int
            maximum number of paraphrased sentences to return. default 10
        max_length : int
            maximum length of each paraphrased sentece. default 32
        adequacy_threshold : float
            float number ranging from 0 - 1 , 1 being the meaning or sentenct is preserved adequately. default 0.8
        fluency_threshold : float
            float number ranging from 0 - 1 , 1 being the paraphrase is fluent English default 0.8
        use_gpu : bool
            True if one wants to use gpu. default False

        Returns
        -------
        que_list : union[List[str,str], List[List[str,str], List[str,str]]]
            list of strings of question per input string.

        Raises
        ------
        TypeError :
            raises typeerror when text is not in desired format
        Exception :
            raises exception if error occurs while generating question

        Example
        -------
        >>> from tigernlp.question_generation.api import QuestionGenerator
        >>> QG = QuestionGenerator()
        >>> QG.generate(
        >>>     text="Harry Potter is a series of seven fantasy novels written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry. The main story arc concerns Harry's struggle against Lord Voldemort, a dark wizard who intends to become immortal, overthrow the wizard governing body known as the Ministry of Magic and subjugate all wizards and Muggles",
        >>>         )
        >>> ['What is the main character of Lord Voldemort?',
        >>> "What is Voldemort's goal?",
        >>> "What is Harry Potter's role in the series?",
        >>> 'What does the main story of Harry Potter relate to?',
        >>> 'What does Voldemort want to do to overthrow the Ministry of Magic?',
        >>> "What is the main focus of Harry Potter's novels?",
        >>> 'What is the main plot of Harry Potter?',
        >>> 'What is the main story arc of Harry Potter?',
        >>> 'What does Lord Voldemort want to do to wizards and Muggles?',
        >>> 'What do the novels do?']

        """
        try:
            if split_by == " ":
                splitter = " "
                joiner = " "
            elif split_by is not None:
                splitter = split_by
                joiner = splitter + " "

            if isinstance(text, str) and split_by is not None:
                token_list = text.split(splitter)
                text = []
                start_idx = 0
                end_idx = start_idx + stride
                while end_idx < len(token_list):
                    text.append(joiner.join(token_list[start_idx:end_idx]))
                    start_idx = start_idx + stride - overlap
                    end_idx = start_idx + stride
                text.append(joiner.join(token_list[start_idx : len(token_list)]))
                que_list = []
                for t in tqdm(text):
                    if isinstance(intent, list):
                        intent_list = intent
                    elif isinstance(intent, str):
                        intent_list = [intent]
                    else:
                        intent_list = self.__get_intent(t)
                    que = self.__get_question(
                        answer=intent_list,
                        context=t,
                    )
                    if self.explode:
                        que = self.parrot.paraphrase(
                            text=que,
                            use_gpu=use_gpu,
                            diversity_ranker=diversity_ranker,
                            do_diverse=do_diverse,
                            max_return_phrases=max_return_phrases,
                            max_length=max_length,
                            adequacy_threshold=adequacy_threshold,
                            fluency_threshold=fluency_threshold,
                        )

                    que_list = list(set(que_list + que))

            elif isinstance(text, list) and split_by is not None:

                que_list = []
                if intent is None:
                    intent = [None] * len(text)
                if len(text) == len(intent):
                    pass
                else:
                    self.logger.error(
                        "Length of text input and intent not matching : Recommended to pass None as intent"
                    )
                    raise Exception(
                        "Length of text input and intent not matching : Recommended to pass None as intent"
                    )

                new_list = text

                for t, i in tqdm(zip(new_list, intent)):
                    text = []
                    token_list = t.split(splitter)
                    start_idx = 0
                    end_idx = start_idx + stride
                    while end_idx < len(token_list):
                        text.append(joiner.join(token_list[start_idx:end_idx]))
                        start_idx = start_idx + stride - overlap
                        end_idx = start_idx + stride
                    text.append(joiner.join(token_list[start_idx : len(token_list)]))

                    que_list_inter = []
                    if i is None:
                        i = [None] * len(text)
                    if len(text) == len(i):
                        pass
                    else:
                        self.logger.error(
                            "Length of text input and intent not matching : Recommended to pass None as intent"
                        )
                        raise Exception(
                            "Length of text input and intent not matching : Recommended to pass None as intent"
                        )

                    for tt, ii in zip(text, i):
                        if isinstance(ii, list):
                            intent_list = ii
                        elif isinstance(ii, str):
                            intent_list = [ii]
                        else:
                            intent_list = self.__get_intent(tt)
                        que = self.__get_question(
                            answer=intent_list,
                            context=tt,
                        )
                        if self.explode:
                            que = self.parrot.paraphrase(
                                text=que,
                                use_gpu=use_gpu,
                                diversity_ranker=diversity_ranker,
                                do_diverse=do_diverse,
                                max_return_phrases=max_return_phrases,
                                max_length=max_length,
                                adequacy_threshold=adequacy_threshold,
                                fluency_threshold=fluency_threshold,
                            )
                        que_list_inter = list(set(que_list_inter + que))
                    que_list.append(que_list_inter)

            elif isinstance(text, str) and split_by is None:
                if isinstance(intent, list):
                    intent_list = intent
                elif isinstance(intent, str):
                    intent_list = [intent]
                else:
                    intent_list = self.__get_intent(text)

                que_list = self.__get_question(
                    answer=intent_list,
                    context=text,
                )

                if self.explode:
                    que_list = self.parrot.paraphrase(
                        text=que_list,
                        use_gpu=use_gpu,
                        diversity_ranker=diversity_ranker,
                        do_diverse=do_diverse,
                        max_return_phrases=max_return_phrases,
                        max_length=max_length,
                        adequacy_threshold=adequacy_threshold,
                        fluency_threshold=fluency_threshold,
                    )

            elif isinstance(text, list) and split_by is None:
                que_list = []
                if intent is None:
                    intent = [None] * len(text)
                if len(text) == len(intent):
                    for t, i in tqdm(zip(text, intent)):
                        if isinstance(i, list):
                            intent_list = i
                        elif isinstance(i, str):
                            intent_list = [i]
                        else:
                            intent_list = self.__get_intent(t)
                        que = self.__get_question(
                            answer=intent_list,
                            context=t,
                        )
                        que = list(set(que))
                        if self.explode:
                            que = self.parrot.paraphrase(
                                text=que,
                                use_gpu=use_gpu,
                                diversity_ranker=diversity_ranker,
                                do_diverse=do_diverse,
                                max_return_phrases=max_return_phrases,
                                max_length=max_length,
                                adequacy_threshold=adequacy_threshold,
                                fluency_threshold=fluency_threshold,
                            )
                        que_list.append(que)
                else:
                    self.logger.error("Length of text input and intent not matching")
                    raise Exception("Length of text input and intent not matching")

            else:
                self.logger.error("Invalid format")
                raise TypeError("Invalid format")
        except Exception as e:
            self.logger.error("Error while generating question :", e)
            raise Exception("Error while generating question :", e)

        return que_list

    def __get_intent(self, text: str):
        """This is an internal function. Given a string input, it generates AOP and creates intent.

        Parameters
        ----------
        text : str
            string input to generate intent

        Returns
        -------
        intent_list : List[str,str]
            list of intent as string

        """
        try:
            aopGenerate = AOPGenerate(merge_compound_nouns=True)
            outpt = aopGenerate.process(
                text,
                include_core_dependencies=True,
                include_adjectives=True,
                include_verb_adpositions=True,
                include_noun_adpositions=True,
                include_noun_conjunctions=True,
                additional_noun_verb_deps=None,
            )
            intent_list = []
            for k in outpt:
                action = None
                obj = None
                for p in k["pairs_pos_lemma"]:
                    if p[1] == "VERB":
                        action = p[0]
                    if p[1] == "NOUN":
                        obj = p[0]
                if action is not None and obj is not None:
                    intent = action + " " + obj
                    intent_list.append(intent)
            return list(set(intent_list))
        except Exception as e:
            self.logger.error(f"Error occurred during intent creation.\n {e}")
            raise Exception(f"Error occurred intent creation.\n {e}")

    def __get_question(self, answer="", context: str = "", max_length: int = 64):
        """This is an internal function. Generates guestion using answer and context

        Parameters
        ----------
        answer : str
            string contating answer or action object pairs or intent
        context : str
            string contating the context or story
        tokenizer : tokenizer instance
            hugging face tokenizer object
        model : model instance
            hugging face model object
        max_length : int, optional
            length of question to generate, default = 64

        Returns
        -------
        question : str
            generated question output

        Raises
        ------
        Exception
            raise error if provided path/name of model or the tokenizer from hugging face is incorrect.

        """
        if isinstance(context, str):

            if isinstance(answer, str):
                input_text = "answer: %s  context: %s </s>" % (answer, context)
                features = self.tokenizer([input_text], return_tensors="pt")
                output = self.model.generate(
                    input_ids=features["input_ids"],
                    attention_mask=features["attention_mask"],
                    max_length=max_length,
                )
                question = self.tokenizer.decode(output[0])
                question = re.search("<pad> question:(.*)</s>", question).group(1).strip()

            elif isinstance(answer, list):

                question = []
                for ans in tqdm(answer):
                    input_text = "answer: %s  context: %s </s>" % (
                        ans,
                        context,
                    )
                    features = self.tokenizer([input_text], return_tensors="pt")
                    output = self.model.generate(
                        input_ids=features["input_ids"],
                        attention_mask=features["attention_mask"],
                        max_length=max_length,
                    )
                    que = self.tokenizer.decode(output[0])
                    que = re.search("<pad> question:(.*)</s>", que).group(1).strip()
                    question.append(que)
            else:
                warnings.warn("answer vairable must be string or list of strings")
                self.logger.warning("answer vairable must be string or list of strings")
                return
        else:
            warnings.warn("context vairable must be string")
            self.logger.warning("context vairable must be string")
            return

        return question
